# Yantra — native Android assistant

A real Android app, built from the ground up. Kotlin, Jetpack Compose, no web view, no browser sandbox, no language model. It talks to the actual system APIs: Wi-Fi panels, Bluetooth, brightness, volume, Do Not Disturb, the torch, your contacts, SMS, the calendar, alarms, notifications.

About 190 command patterns wired to roughly 45 native actions.

```
"turn on the flashlight"          -> CameraManager.setTorchMode
"set brightness to 50%"           -> Settings.System.SCREEN_BRIGHTNESS
"turn on do not disturb"          -> NotificationManager.setInterruptionFilter
"call mom"                        -> ContactsContract + ACTION_CALL
"text 9876543210 saying I'm late" -> SmsManager.sendMultipartTextMessage
"add event dentist tomorrow 5pm"  -> CalendarContract.Events insert
"set an alarm for 6:30 am"        -> AlarmManager.setAlarmClock
"read my notifications"           -> NotificationListenerService
"open swiggy"                     -> PackageManager launch intent
"what's on my calendar"           -> CalendarContract query
```

---

## Get the APK without Android Studio

The repository builds itself.

1. Push this folder to a GitHub repo.
2. Open the **Actions** tab. The `Build APK` workflow runs on the first push.
3. When it goes green, open the run and download the **yantra-debug-apk** artifact.
4. Unzip it, copy `app-debug.apk` to your phone, tap it, allow "install from unknown sources".

That is a signed debug APK — installable, no Play Store, no developer account.

To cut a versioned release instead: `git tag v1.0.0 && git push --tags`. The `release` job attaches the APK to a GitHub Release automatically.

## Or build it locally

```bash
# needs JDK 17 and the Android SDK (Android Studio installs both)
gradle test          # 40+ router assertions on the JVM
gradle assembleDebug # app/build/outputs/apk/debug/app-debug.apk
```

`./gradlew` works too if you run `gradle wrapper` once to generate the wrapper jar.

---

## First run

The app asks for permissions in one batch: microphone, camera, contacts, phone, SMS, calendar, location, notifications, nearby devices. Grant what you want — every action degrades gracefully if you refuse, telling you which permission it needed.

Three permissions are **not** runtime prompts and need a settings screen:

| Permission | Where | What it unlocks |
|---|---|---|
| Modify system settings | Settings → Apps → Yantra → Modify system settings | brightness |
| Do Not Disturb access | Settings → Notifications → DND access | Do Not Disturb |
| Notification access | Settings → Notifications → Device & app notifications | "read my notifications" |

The app opens the right screen the first time you ask for one of those and tells you why.

---

## Architecture

```
app/src/main/java/in/yantra/assistant/
├── MainActivity.kt          permissions, mic, Compose host
├── AssistantViewModel.kt    state, timers, speech, command pipeline
├── YantraApp.kt             notification channels
├── router/
│   └── Router.kt            PURE Kotlin. 190 patterns -> Parsed(action, args)
├── actions/
│   ├── ActionExecutor.kt    the switch: every action -> a real system call
│   ├── Contacts.kt          ContactsContract queries
│   ├── CalTools.kt          calendar read + write
│   └── Weather.kt           Open-Meteo over HTTPS, keyless
├── speech/
│   └── Speech.kt            SpeechRecognizer in, TextToSpeech out
├── service/
│   ├── AlarmReceiver.kt     AlarmManager target + notification
│   └── NotificationListener.kt
├── ui/
│   ├── ChatScreen.kt        Compose UI
│   └── Theme.kt
└── util/Prefs.kt            preferences and named lists
```

**The router is deliberately free of Android imports.** You give it a string and a `Ctx`, it gives you back a `Parsed`. That is why `gradle test` can fire dozens of assertions at it in milliseconds on the JVM, with no emulator.

```kotlin
val p = Router.route("set brightness to 50%")
// Parsed(action="brightness", pct=50)
```

The executor is the only place that touches the platform. Adding a command means adding one pattern in `Router.kt` and one branch in `ActionExecutor.kt`.

---

## What is genuinely possible, and what is not

Android's permission model decides this, not the code. Some things you might expect are blocked for every app that is not a system app:

| Command | Result |
|---|---|
| Turn Wi-Fi on/off | **Opens the Wi-Fi panel.** Android 10+ forbids silent toggling for normal apps. |
| Aeroplane mode, mobile data, battery saver | **Opens the panel.** Same reason. |
| Bluetooth on/off | Works below Android 13; from 13 it shows the confirm dialog. |
| Brightness, volume, DND, torch | **Works.** Needs the three settings grants above. |
| Open apps, call, SMS, calendar, alarms, notifications | **Works** with runtime permissions. |
| Launch apps silently, read other apps' screens | Not possible. Accessibility services can, but Play Store policy restricts them heavily. |
| Control a smart-home device | Needs a hub (Matter/Home Assistant) or vendor SDK — not in this build. |

Where it cannot act, it says exactly why instead of pretending.

---

## Tests

```bash
gradle test
```

`app/src/test/java/in/yantra/assistant/RouterTest.kt` covers device toggles, screen and volume maths, alarms and timers, unit conversion, lists, calendar, contacts and the memory commands. CI runs it before every APK build and refuses to publish on failure.

---

## Honest status

The router and every action are written, but this project has **not been compiled** — the environment I built it in has no JDK or Android SDK. The first CI run is the real compile. If anything breaks, the workflow log names the file and line, and the fix is usually a one-liner.

What I did verify here: all 34 of the highest-risk regex patterns, against the exact test inputs, with a Node harness that mirrors the router's `normalize()` and match semantics. Those all behave as the tests expect. Kotlin syntax and Android API signatures are reviewed by hand, not by a compiler.

---

## Design

The visual language is lifted from **Valley** ([getvalley.github.io/TheIndusValley](https://getvalley.github.io/TheIndusValley)) — a warm, editorial look rather than the usual dark-tech palette.

| Token | Light | Dark |
|---|---|---|
| Paper (background) | `#F5F2EC` | `#0A0807` |
| Surface | `#FFFFFF` | `#161412` |
| Ink (text) | `#1B1815` | `#F6F0E8` |
| Ink, secondary | `#6B625A` | `#B3A89C` |
| Ember (accent) | `#E8622A` | `#E8622A` |
| Amber · Clay · Plum | `#F6B955` · `#D4622B` · `#5C2A22` | same |

Type is **Bricolage Grotesque** throughout, with the reference's tight negative tracking on display sizes and very large corner radii (24–50dp) on every surface. The header is a floating translucent pill, the composer is a pill, the suggestion chips are pills with an amber-to-clay gradient dot — all straight from the source.

There is a sun/moon toggle in the header that flips the whole app, matching the reference's theme button. The launcher icon was redrawn in the same palette: paper ground, ember orb, amber-to-clay orbit.

**Font credit:** Bricolage Grotesque by Mathieu Triay, licensed under the SIL Open Font License 1.1. The four static weights in `res/font/` were instantiated from the variable font shipped with the Valley site.

---

## The orb

The voice blob is a custom `View` (`ui/BlobView.kt`) — four colour clouds orbiting inside a circular clip, each drawn as a radial gradient that fades to fully transparent at its rim. That gradient falloff is what gives the soft liquid edge without a blur pass, so it stays cheap on older hardware. It runs on a `ValueAnimator` at 7s per revolution, speeds up and grows while the mic is open, and stops itself in `onDetachedFromWindow`.

It appears in three places: 26dp in the header, 52dp as the microphone button, and 168dp full-screen while listening.

The palette is the Assistant four — `#4285F4`, `#EA4335`, `#FBBC05`, `#34A853` — deliberately louder than the warm UI, because it marks the one moment the app is actively listening. Swap `BlobView.palette` for the warm set (`#E8622A`, `#F6B955`, `#8FB0C4`, `#5C2A22`) if you would rather it stay in the Valley palette; the floating bubble already uses the warm set.

## Floating over other apps

Tap **float** in the header. A 64dp orb appears in an application-overlay window and stays above every other app — the same mechanism as Gemini's floating button and chat heads.

- Drag it anywhere on screen.
- Tap it to open a panel: type or speak, get the answer, close.
- The panel runs the same `Router` and `ActionExecutor` as the main app, so every command works.

Two things you have to grant:

1. **Display over other apps** — tapping *float* the first time opens the right settings screen. This is a special permission Android never grants in a normal runtime prompt.
2. A **persistent notification** — Android requires any overlay to run under a foreground service, so "Yantra is floating" stays in your shade while it is active.

**What it cannot do.** It will not draw over secure surfaces (banking apps, some streaming apps) or the notification shade — that is enforced by the system. On MIUI, ColorOS and similar you may also need to enable "display pop-up windows" in the app's own permission page.

**To get the power-button gesture:** the manifest already declares `ACTION_ASSIST`, so Yantra appears under **Settings → Apps → Default apps → Digital assistant**. Set it there and the system assistant gesture opens Yantra instead of Google. That part is a role the user assigns; an app cannot claim it silently.

---

## Sending messages

The parser splits the recipient from the body on the first connector, so all of these work:

```
send a message to X to come to the party at 3 o'clock
text mom saying I am late
message dad that I'll be late
send a message to 9876543210 saying I am late
text rahul about the invoice
whatsapp priya saying running late
```

A name goes through `ContactsContract`; a number dials straight through. If you give no recipient it asks who. If you give no body it opens the composer instead of firing off an empty SMS.

---

## License

MIT.
