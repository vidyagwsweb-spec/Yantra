# Yantra — native Android assistant

A real Android app, built from the ground up. Kotlin, Jetpack Compose, no web view, no browser sandbox. A small on-device brain handles chat, odd phrasing and shortcuts you teach it, and an optional on-device language model (see [The thinking layer](#the-thinking-layer)) handles everything else. It talks to the actual system APIs: Wi-Fi panels, Bluetooth, brightness, volume, Do Not Disturb, the torch, your contacts, SMS, the calendar, alarms, notifications.

About 190 command patterns wired to roughly 45 native actions.

```
"turn on the flashlight"          -> CameraManager.setTorchMode
"set brightness to 50%"           -> Settings.System.SCREEN_BRIGHTNESS
"turn on do not disturb"          -> NotificationManager.setInterruptionFilter
"call mom"                        -> ContactsContract + ACTION_CALL
"text 9876543210 saying I'm late" -> SmsManager.sendMultipartTextMessage
"add event dentist tomorrow 5pm"  -> CalendarContract.Events insert
"set an alarm for 6:30 am"        -> AlarmManager.setAlarmClock
"read my notifications"           -> NotificationListenerService
"open swiggy"                     -> PackageManager launch intent
"what's on my calendar"           -> CalendarContract query
```

---

## Get the APK without Android Studio

The repository builds itself.

1. Push this folder to a GitHub repo.
2. Open the **Actions** tab. The `Build APK` workflow runs on the first push.
3. When it goes green, open the run and download the **yantra-debug-apk** artifact.
4. Unzip it, copy `app-debug.apk` to your phone, tap it, allow "install from unknown sources".

That is a signed debug APK — installable, no Play Store, no developer account.

To cut a versioned release instead: `git tag v1.0.0 && git push --tags`. The `release` job attaches the APK to a GitHub Release automatically.

## Or build it locally

```bash
# needs JDK 17 and the Android SDK (Android Studio installs both)
gradle test          # 40+ router assertions on the JVM
gradle assembleDebug # app/build/outputs/apk/debug/app-debug.apk
```

`./gradlew` works too if you run `gradle wrapper` once to generate the wrapper jar.

---

## First run

The app asks for permissions in one batch: microphone, camera, contacts, phone, SMS, calendar, location, notifications, nearby devices. Grant what you want — every action degrades gracefully if you refuse, telling you which permission it needed.

Three permissions are **not** runtime prompts and need a settings screen:

| Permission | Where | What it unlocks |
|---|---|---|
| Modify system settings | Settings → Apps → Yantra → Modify system settings | brightness |
| Do Not Disturb access | Settings → Notifications → DND access | Do Not Disturb |
| Notification access | Settings → Notifications → Device & app notifications | "read my notifications" |

The app opens the right screen the first time you ask for one of those and tells you why.

---

## Architecture

```
app/src/main/java/in/yantra/assistant/
├── MainActivity.kt          permissions, mic, Compose host
├── AssistantViewModel.kt    state, timers, speech, command pipeline
├── YantraApp.kt             notification channels
├── brain/
│   ├── Brain.kt             PURE Kotlin. Fuzzy matching, small talk, facts, "did you mean", teachable shortcuts
│   └── BrainData.kt         the phrases and replies it knows, as plain data
├── router/
│   ├── Router.kt            PURE Kotlin. Patterns -> Parsed(action, args); chains; reminders
│   ├── Translator.kt        PURE Kotlin. Typos, numbers, times, "too loud", follow-ups -> canonical commands
│   └── Rewriter.kt          politeness, word order, synonyms (used by the Translator)
├── actions/
│   ├── ActionExecutor.kt    the switch: every action -> a real system call
│   ├── Contacts.kt          ContactsContract queries
│   ├── CalTools.kt          calendar read + write
│   └── Weather.kt           Open-Meteo over HTTPS, keyless
├── speech/
│   ├── Speech.kt            SpeechRecognizer in, TextToSpeech out, voice choice
│   └── SpeechText.kt        PURE Kotlin. Makes replies read aloud like a person
├── service/
│   ├── AlarmReceiver.kt     AlarmManager target + notification
│   └── NotificationListener.kt
├── ui/
│   ├── ChatScreen.kt        Compose UI
│   └── Theme.kt
├── util/
│   ├── Prefs.kt             preferences and named lists
│   ├── AppSettings.kt       theme, language, spoken replies, smart replies
│   └── Languages.kt         the English accents offered in Settings
└── ui/SettingsScreen.kt     voice blobs, accent, speed, pitch, theme, name, brain
```

**Understanding how people actually talk.** The router is a bank of patterns, so
`turn on the flashlight` matches and `turn the flashlight on` does not, and
`set brightness to 30%` matches while `increase the brightness by 50%` used to
fall through. `Translator.kt` sits in front of the router and converts the way
people phrase things into the canonical form the patterns expect:

| You say | Translated to |
|---|---|
| increase the brightness by fifty percent | increase brightness by 50% |
| make the screen a bit dimmer | decrease brightness by 10% |
| make it 30 percent louder | increase volume by 30% |
| turn the volume up to forty | set volume to 40% |
| bring the volume down by half | decrease volume by 50% |
| turn the sound down by 2 notches | decrease volume by 14% |
| set the brightness to half | set brightness to 50% |
| flashlight on / disable the wi-fi | turn on flashlight / turn off wi-fi |
| hey yantra, can you turn the torch on please | turn on flashlight |
| set an alarm for six in the morning | set an alarm for 6 am |

How it works, in order: tidy the text; turn number words into digits
(`twenty five`, `a hundred`) and `percent` into `%`; strip politeness and fix
word order (`Rewriter`); expand aliases (`dnd`, `bt`); then, for brightness and
volume, decide whether the request is **absolute** ("to 40") or **relative**
("by 40", "40% louder", "a bit dimmer") and emit one of three shapes:

```
set <brightness|volume> to N%
increase|decrease <brightness|volume> by N%
increase|decrease <brightness|volume>        (router applies its default step)
```

"by 50%" means fifty percentage points added to the current level, not fifty
percent of it. "A bit" is 10, "a lot" is 30, a "notch" is 7 on volume and 10 on
brightness. Questions ("how do I make the screen brighter") and commands about
something else ("remind me to turn the volume down") are left alone by the level
logic.

**What else the translator does**

| Feature | Example | Becomes |
|---|---|---|
| Typo repair (command words only) | brigtness to 40 | set brightness to 40% |
| Indirect asks | it's a bit too loud | decrease volume by 10% |
| | I can't see anything | increase brightness |
| Follow-ups (remembers what you last changed) | *a bit more* / *20 more* / *set it to 40* | adjusts the same thing |
| Repeat | *again* | re-runs your last command |
| Spoken times | alarm at quarter to seven | alarm at 6:45 |
| Spoken addresses | email priya at example dot com | priya@example.com |
| Spoken sites | go to youtube dot com | go to youtube.com |
| Spoken arithmetic | what is 12 times 7 | 12 * 7 |
| Spoken units | how many minutes in 3 hours | 3 hours to minutes |
| Verb synonyms | launch / fire up / ring / ping / snap a selfie | open / call / message / take a photo |
| Chains | turn on wifi and bluetooth, then open maps | three commands, run in order |
| Questions nothing else claims | who is the prime minister of india | a web search |

Typo repair only touches words from a vocabulary of about fifty command words,
only when a word is five letters or more, shares its first letter with exactly
one keyword, and is within one edit (two for long words). Names and everyday
English are never in that vocabulary, so `text priyanka hello` is left alone
and `12 times 7` is not turned into `12 timer 7`.

A chain is only split when **every** part is understood, so `add milk and eggs
to shopping` stays one command and `turn on wifi and fly to the moon` runs
nothing rather than half of it. Later parts borrow the first part's verb:
`turn on wifi and bluetooth`, `open youtube and whatsapp`.

`Router.route` tries the text as given first and only consults the translator
when that produced nothing, so a translation can add coverage but can never
take away a command that already worked. The replies now say what changed:
`Brightness 30% → 80%.`, or `Brightness is already at 100%.`

**The router is deliberately free of Android imports.** You give it a string and a `Ctx`, it gives you back a `Parsed`. That is why `gradle test` can fire dozens of assertions at it in milliseconds on the JVM, with no emulator.

```kotlin
val p = Router.route("set brightness to 50%")
// Parsed(action="brightness", pct=50)
```

The executor is the only place that touches the platform. Adding a command means adding one pattern in `Router.kt` and one branch in `ActionExecutor.kt`.

---

## What is genuinely possible, and what is not

Android's permission model decides this, not the code. Some things you might expect are blocked for every app that is not a system app:

| Command | Result |
|---|---|
| Turn Wi-Fi on/off | **Opens the Wi-Fi panel.** Android 10+ forbids silent toggling for normal apps. |
| Aeroplane mode, mobile data, battery saver | **Opens the panel.** Same reason. |
| Bluetooth on/off | Works below Android 13; from 13 it shows the confirm dialog. |
| Brightness, volume, DND, torch | **Works.** Needs the three settings grants above. |
| Auto-rotate, auto-brightness, screen timeout | **Works** once "modify system settings" is granted (same grant as brightness). |
| Silent mode | **Works** once Do Not Disturb access is granted; vibrate and ring mode need nothing. |
| Play, pause, next, previous | **Works** by sending media keys to whatever player is active. If nothing is playing, "play" cannot start a player for you. |
| Hotspot, location, NFC, VPN, cast | **Opens the right settings page.** Android does not let apps flip these. |
| Uninstall an app | **Shows Android's confirm dialog.** An app cannot remove another silently. |
| Clear notifications | **Works** once notification access is granted. |
| Clipboard | Copy works. Reading only works while Yantra is in the foreground (Android 10+). |
| Reminders ("remind me to call mom at 5 pm") | **Works.** Set with `setAlarmClock`, so it fires on time even in Doze. |
| Open apps, call, SMS, calendar, alarms, notifications | **Works** with runtime permissions. |
| Launch apps silently, read other apps' screens | Not possible. Accessibility services can, but Play Store policy restricts them heavily. |
| Control a smart-home device | Needs a hub (Matter/Home Assistant) or vendor SDK — not in this build. |

Where it cannot act, it says exactly why instead of pretending.

---

## Tests

```bash
gradle test
node tools/verify-translator.js   # no JDK needed: replays the Translator's regexes from the Kotlin source
```

`app/src/test/java/in/yantra/assistant/RouterTest.kt` (41 tests) covers device toggles, screen and volume maths, media keys, settings pages, reminders against a fixed clock, date and money maths, typo repair, follow-ups, chains, alarms and timers, unit conversion, lists, calendar, contacts and the memory commands. CI runs it before every APK build and refuses to publish on failure.

---

## Honest status

The router, the brain, the settings screen and every action are written, but this project has **not been compiled** — the environment I built it in has no JDK or Android SDK. The first CI run is the real compile. If anything breaks, the workflow log names the file and line, and the fix is usually a one-liner.

What I did verify here, with a Node harness (`tools/verify-translator.js`) that extracts every regex straight from the Kotlin source and replays the router's patterns in file order:

* **200 checks pass**: the translator's output for each feature above, which router pattern wins for each new command, reminder times against a fixed clock, chains, and the voice commands (including that "make you sound more human" does not become a volume change).
* **No existing command was hijacked.** I replayed every phrase from the original test suite against the original router's pattern list and the new one. Of 85 phrases, none now resolves to a different pattern except the brightness, volume and arithmetic patterns that were deliberately extended.
* **Every action the router can emit has a handler** (77 of 77, after the fix below).
* No pathological input (4,000 characters, 1,500 repeated words) takes more than a few milliseconds.

The checks found real bugs before shipping: the typo fixer turned "12 times 7" into "12 timer 7"; "open youtube and whatsapp" was read as one app called "youtube and whatsapp"; and a trailing "please" stopped "turn the flashlight on please" from matching.

The check also surfaced a bug that was in the project before this round: `call me Vidya`, `speak slowly`, `speak faster` and `use metric units` were emitted by the router but had no handler, so they answered "wired in the parser but not the executor yet". Name and speech rate now work. The units preference is stored but nothing reads it yet, and the reply says so.

Brackets are balanced in every file. Kotlin types, Compose APIs and Android signatures are reviewed by hand, not by a compiler.

---

## The thinking layer

Yantra now has three tiers of understanding, cheapest and most certain first. Each one only sees what the tier above could not handle, so a smarter tier can add coverage but can never take a working command away.

```
what you say -> crisis check -> yes/no -> taught shortcuts -> memory ("remember that ...")
             -> Router (patterns)
                  nothing matched? -> Reasoner (exact maths)
                                   -> Brain (small talk, "did you mean")
                                   -> language model (if installed)
                                   -> web search
```

**1. Memory** (`mind/Memory.kt`, works without a model). Say *remember that I am vegetarian*, *my birthday is 3 March*, *my mom's name is Sunita*, *I live in Pune*. Ask *when is my birthday*, *who is my mom*, *what do you know about me*. Say *forget my birthday*, *forget that I am vegetarian* or *forget everything about me*. Only explicit statements are stored, on the phone. Passwords, PINs and card or ID numbers are refused. The facts are also given to the language model, so its answers fit you.

**2. Reasoner** (`mind/Reasoner.kt`, works without a model). A real expression parser, not `eval`: `(12+8)*3/4`, `15% of 2400`, `2500 + 18%`, `square root of 144 times 3`, `2 to the power of 10`, `half of 90`, `7 mod 3`. Anything that is not clearly a calculation is left alone, so phone numbers, dates and ordinary sentences are never hijacked.

**3. Language model** (`mind/LocalModel.kt`, optional). Google's MediaPipe LLM Inference runs a Gemma or Qwen model on the phone. No account, no API key, no network, nothing leaves the device. It does two jobs:

* **Planning.** Free-form speech becomes router commands plus a reply. *it is way too dark in here* becomes `increase brightness by 30%`. *bhai wifi band kar do* becomes `turn off wifi`. *going to sleep, wake me at 6:30 and keep the phone quiet* becomes an alarm and silent mode. It sees the last few turns, so *call her* and *make it louder* have something to refer to.
* **Answering.** For questions (*why*, *how many*, *explain*, *should I*...) Yantra first looks the topic up (Wikipedia, as before) and has the model answer from that text, so it is grounded in a source instead of in a small model's memory. If nothing is found it answers from what it knows and says so when unsure.

The model cannot do anything the router cannot. It is taught the router's command forms (`mind/Prompts.kt`); every command it writes is run back through `Router.routeAll` and dropped if the router does not understand it. Anything that messages, calls, emails, uninstalls or clears something waits for an explicit *yes*. Reference text from the web is marked as untrusted data in the prompt.

### Installing a model

The model file is not bundled: it is hundreds of megabytes and Gemma's licence has to be accepted by whoever downloads it.

1. Download a MediaPipe `.task` model from the **LiteRT Community** page on Hugging Face. Good starting points: *Gemma 3 1B IT* (int4, about 550 MB) or *Qwen 2.5 0.5B Instruct*. A phone with 6 GB RAM or more is comfortable.
2. In Yantra, open **Settings, Thinking, Choose model file**, and pick it. It is copied into the app's private storage (progress shown) and loaded.
3. Ask something it could not do before, such as *it is too dark in here*.

Turn **Use the language model** off to free its memory, or **Remove** to delete the file. Qwen files get the ChatML prompt format and everything else gets Gemma's, chosen from the file name (`PromptStyle.forFile`).

Expect a few seconds per reply on a mid-range phone. Generation is capped at 90 seconds. Only `.task` and `.bin` files are accepted; newer `.litertlm` files need a different runtime.

### Testing it

```bash
gradle test                       # MindTest.kt: parser, memory, maths, risk rules, planning with a fake model
node tools/verify-mind.js         # no JDK: replays the Kotlin regexes, and checks that every command the model is taught
                                  # (and every DO line in the prompt examples) is understood by the router
```

### Honest status of this round

* `tools/verify-mind.js` passes (127 checks) and `tools/verify-translator.js` still passes (200). They replay the Kotlin regexes and a hand port of the parsers.
* **None of the new Kotlin has been compiled.** The environment this was written in has a JDK but no Kotlin compiler or Android SDK. The first CI run is the real compile. The most likely friction is the MediaPipe calls in `LocalModel.kt` (`LlmInferenceSession` and its options, from `tasks-genai:0.10.24`); the fix there is usually a method name.
* **The language model itself has not been run**, so prompt quality with a real Gemma or Qwen file is untested. The prompt, the output parser and the safety rules are designed for small, sloppy models, but expect to tune `Prompts.kt` after the first real run. The examples there are the lever that matters most.
* The build is limited to `arm64-v8a` to keep the APK small (see `app/build.gradle.kts`).

---

## Design

The visual language is lifted from **Valley** ([getvalley.github.io/TheIndusValley](https://getvalley.github.io/TheIndusValley)) — a warm, editorial look rather than the usual dark-tech palette.

| Token | Light | Dark |
|---|---|---|
| Paper (background) | `#F5F2EC` | `#0A0807` |
| Surface | `#FFFFFF` | `#161412` |
| Ink (text) | `#1B1815` | `#F6F0E8` |
| Ink, secondary | `#6B625A` | `#B3A89C` |
| Ember (accent) | `#E8622A` | `#E8622A` |
| Amber · Clay · Plum | `#F6B955` · `#D4622B` · `#5C2A22` | same |

Type is **Bricolage Grotesque** throughout, with the reference's tight negative tracking on display sizes and very large corner radii (24–50dp) on every surface. The header is a floating translucent pill, the composer is a pill, the suggestion chips are pills with an amber-to-clay gradient dot — all straight from the source.

There is a sun/moon toggle in the header that flips the whole app, matching the reference's theme button. The launcher icon was redrawn in the same palette: paper ground, ember orb, amber-to-clay orbit.

**Font credit:** Bricolage Grotesque by Mathieu Triay, licensed under the SIL Open Font License 1.1. The four static weights in `res/font/` were instantiated from the variable font shipped with the Valley site.

---

## The orb

The voice blob is a custom `View` (`ui/BlobView.kt`) — four colour clouds orbiting inside a circular clip, each drawn as a radial gradient that fades to fully transparent at its rim. That gradient falloff is what gives the soft liquid edge without a blur pass, so it stays cheap on older hardware. It runs on a `ValueAnimator` at 7s per revolution, speeds up and grows while the mic is open, and stops itself in `onDetachedFromWindow`.

It appears in three places: 26dp in the header, 52dp as the microphone button, and 168dp full-screen while listening.

The palette is the Assistant four — `#4285F4`, `#EA4335`, `#FBBC05`, `#34A853` — deliberately louder than the warm UI, because it marks the one moment the app is actively listening. The summon sheet already uses the warm set (`#E8622A`, `#F6B955`, `#8FB0C4`, `#5C2A22`) so it matches the rest of the UI; set `BlobView.palette` to it elsewhere if you want the whole app warm.

## Summoning it over other apps

Not a bubble that sits there forever. You summon it, it opens over whatever you
were doing, you ask, it closes.

Two ways in:

1. **Quick Settings tile** — pull the shade down twice, tap the pencil, drag
   **Ask Yantra** into the panel. Tap it from any app.
2. **Assistant gesture** — Yantra declares `ACTION_ASSIST`, so it appears under
   Settings → Apps → Default apps → Digital assistant. Set it there and the
   power-button / corner-swipe gesture opens Yantra instead of Google.

Either path launches `AssistActivity`: the app you were in dims behind a warm
glow, and a floating sheet rises from the bottom. It shows one thing at a time:

| State | What the sheet shows |
|---|---|
| Listening | your words as you say them, orb rippling |
| Working | the command it heard |
| Answer | the command, and the reply |
| Idle | a prompt, any error ("I heard nothing"), and a few things to try |

The mic is already listening when it opens. Tap the orb to stop or start
listening, type in the pill beside it (focusing the field stops the mic), tap
`×` or the dimmed area to dismiss. If the microphone permission is off it says
so instead of sitting there silently.

Ask *"how do I float over apps"* and it explains the same thing.

## The voice

If the voice sounds robotic, it is usually one of three things, and the app now
deals with each:

1. **The engine picked the smallest installed voice.** On startup Yantra now
   chooses the best English voice that is actually installed: voices that work
   offline first, then highest quality, then Indian English. Your choice is
   remembered.
2. **The text was read verbatim.** "Brightness 30% → 80%" used to be read with
   the symbols; `SpeechText` now turns `%`, `→`, `•`, dashes, `&`, degrees and
   line breaks into words and pauses before anything is spoken.
3. **A better voice is not installed.** That one only you can fix, and Yantra
   can take you to it.

| Say | What happens |
|---|---|
| change your voice / try another voice / next voice | cycles through the installed English voices and says "This is how I sound now" in the new one |
| you sound robotic / make you sound more human | same as "change your voice" |
| what voices do you have | says how many are installed and which is in use |
| install a voice / get more voices | opens Android's voice downloads (or the text-to-speech settings) |
| speak deeper / use a higher voice | shifts the pitch a notch, remembered |
| speak slowly / speak faster | speaking speed |
| reset your voice | automatic voice, normal pitch and speed |

**The honest part.** The natural-sounding voices (Google's "high" and "very high"
quality ones) are downloads, and an app cannot install them for you. Say
"install a voice", pick an English voice in the screen that opens, then say
"change your voice". Without one downloaded, Yantra can only choose among what
the phone already has. Quality labels come from Android itself.

If even the best Android voice is not good enough, the next step is bundling an
on-device neural voice (for example Piper through sherpa-onnx). That adds tens
of megabytes and a native library, so it is not in this build.

---

## The mini brain

Yantra is still not a language model. The brain is a few hundred hand-written
phrasings plus a small matcher, which means it is predictable, tiny, works
offline, and never sends anything anywhere. It only speaks up when the router
found nothing, so it can add coverage but cannot take a command away.

```
what you say  ->  crisis check  ->  waiting yes/no  ->  your taught shortcuts  ->  Router
                                                                                      |
                                                              nothing matched?  ->  Brain  ->  web search / "I did not catch that"
```

**What it does**

| You say | Yantra does |
|---|---|
| tell me a joke, then *another one* | a joke, then a different one |
| tell me a fun fact / motivate me / I am bored | a reply from that topic |
| who made you / are you alive / what does yantra mean | an honest answer about itself |
| what is the capital of karnataka | answers from a built-in table, countries and Indian states |
| how many planets are there / national bird of india | a handful of fixed facts |
| it's dark in here | "Taking that as \"turn on flashlight\"." and does it |
| I'm in a meeting | asks "Turn on Do Not Disturb?"; *yes* does it |
| I feel lonely | a short, kind reply, and offers a five minute timer |
| when I say movie time, open netflix | saves the shortcut for good |
| when I say good vibes, say thank you | saves a reply |
| what have I taught you / forget all shortcuts | lists or clears them |

**How the matching works.** Your sentence is cut down to its meaningful words
(filler dropped, plurals and endings trimmed, `torch` and `flashlight` treated
as one word, one-letter slips forgiven). Each word is weighted by how rare it
is, so `flashlight` counts for more than `turn`. The sentence is then scored
against every stored phrasing in both directions: how much of what you said
the phrasing explains, and how much of the phrasing you said. Extra unknown
words and missing words both lower the score, which is why *how old is the
eiffel tower* does not get the "how old are you" reply.

* Above 0.86, a command phrasing runs straight away (and says what it took you to mean).
* Between 0.58 and 0.86, it asks first. Anything with a side effect, such as Do Not Disturb or mute, always asks.
* If a third or more of your words are ones it has never seen, it stays out and the normal web search runs.
* If two topics score nearly the same, it stays out.

**Safety.** Messages about wanting to die or hurting yourself are checked first,
before any other logic, and get a plain, caring reply that points to a person
and a crisis line (Tele-MANAS, 14416, in India) rather than a joke or a search.
Please check the number against current official sources before you ship; helplines change.

**Adding to it.** A topic is one `Intent(...)` block in `brain/BrainData.kt`:
a few example phrasings and one or more replies. A command is one
`CommandEntry(...)` with the exact router command it maps to. No other code changes.

```bash
python3 tools/tune-brain.py        # replays the matcher in Python against 70+ sentences, no JDK needed
python3 tools/tune-brain.py -v     # shows every score
python3 tools/tune-brain.py "its pitch dark"
```

The Python harness reads the phrase data and thresholds straight from the Kotlin
files, so it stays honest when you edit them. `BrainTest.kt` covers the same
behaviour on the JVM under `gradle test`.

---

## Settings

Tap the gear in the header.

| Setting | What it does |
|---|---|
| **Voice** | A swipeable row of blobs, one per installed voice, each painted in its own colours. Tap one to hear it. The chosen blob grows, gets a ring and swirls faster. |
| Speed, pitch | Sliders. Releasing one plays a sample. Remembered. |
| **Language** | English (India), (UK), (US), (Australia), (Canada), (Ireland), (South Africa). Changes the accent Yantra listens for and speaks in, and filters the voice list to that accent when the phone has voices for it. |
| Theme | System, light or dark. Shared with the summon panel. |
| Speak replies aloud | Off keeps replies on screen only. Previews in Settings still play. |
| Your name | Used in greetings. Same value as *call me ...*. |
| Smart replies | Switches the mini brain off if you want strict commands only. |
| Shortcuts | Shows how many you have taught, with Forget all. |

Voices come from Android's text-to-speech engine, so what appears depends on
what is installed. If an accent has no voice yet, the list falls back to every
English voice and says so; **Get more voices** opens Android's downloads.
Commands are understood in English only, so the language setting is about
accent, not translation. Adding Hindi would need Hindi patterns in the router.

---

## Sending messages

The parser splits the recipient from the body on the first connector, so all of these work:

```
send a message to X to come to the party at 3 o'clock
text mom saying I am late
message dad that I'll be late
send a message to 9876543210 saying I am late
text rahul about the invoice
whatsapp priya saying running late
```

A name goes through `ContactsContract`; a number dials straight through. If you give no recipient it asks who. If you give no body it opens the composer instead of firing off an empty SMS.

---

## License

MIT.


---

## Latest changes

**Answers in place.** "Who is...", "what is...", "where is...", "define...", "explain..." and "search for / look up..." are now answered on screen and read aloud, from Wikipedia, a free dictionary and (for "who is the prime minister of india") Wikidata's current office holder. `Answers.kt` does the network calls; `AnswerText.kt` is pure Kotlin and decides what is worth looking up, rejects pages that are not really about the question, and trims the text. Anything it cannot answer honestly ("how do I...", "population of...", "train timings") still opens Google, and "google X" always does. Switch it off in Settings, Answers.

**Wake-up screen.** The app behind is blurred (Android 12+, darkened instead when the system cannot blur), fading to black at the bottom, with one bar: `+` (type), the gold orb (microphone), `x` (close).

**Breathing orb.** `BlobView` swells and settles on a slow sine (about 4.8 s idle, 2.2 s listening). State changes ease instead of snapping, and it holds still when system animations are off.

**Launcher icon.** Adaptive icon with a light and a dark background (`values-night`), plus an Android 13 themed (monochrome) layer. `python3 tools/build-icon.py` regenerates the drawables and preview PNGs.

**App UI.** The main screen and Settings now share the wake-up screen's look: the icon-coloured breathing orb as the microphone (`Orb.kt`), a big orb and greeting when empty, replies as large plain text instead of boxed bubbles, a typing pill, and the same dark fade while listening. Settings cards are softer and borderless, with accent-coloured switches and sliders, and the chosen voice glows and breathes instead of getting a ring.


---

## Valley integration

Yantra and the Valley browser talk to each other through two small public contracts.

**Yantra -> Valley.** Valley accepts `ai.valley.browser.action.SMART_SEARCH` (extras `ai.valley.browser.extra.QUERY`, `...PRIVATE`), the link form `valley://open?q=...`, and `WEB_SEARCH`. The text goes through Valley's own smart search, so `open maharashtraboardsolutions on Valley` opens that site directly, and `search iphone 15 flipkart in Valley` searches Flipkart. With "Open the web in Valley" on (Settings), Yantra's web searches, `go to` links and unknown app names such as `open somesite` use it too. Without Valley, Yantra falls back to the default browser.

**Valley -> Yantra.** In Valley's voice search, saying `Yantra, <command>` opens Yantra's panel over Valley running that command (`in.yantra.assistant.action.COMMAND`, extra `in.yantra.assistant.extra.TEXT`).

`router/WebRoute.kt` mirrors Valley's smart search only so Yantra can say where a request is going and keep working without Valley. Valley stays the source of truth.

## Memory

Yantra now remembers plain statements ("I am in 9th grade. I love chess.") as well as `remember that ...`. A message is only stored when every sentence in it is a fact about you, so commands are never swallowed. `show my memories` lists them numbered; `forget memory 2`, `forget my birthday` and `forget everything about me` remove them; Settings shows the same list with a Remove button per line.
