# Keep the router's data classes intact; reflection is not used, but this keeps
# the debug output readable.
-keep class in.yantra.assistant.router.** { *; }
