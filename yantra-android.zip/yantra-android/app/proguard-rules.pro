# Keep the router's data classes intact; reflection is not used, but this keeps
# the debug output readable.
-keep class in.yantra.assistant.router.** { *; }

# MediaPipe LLM inference loads its protobuf and JNI classes by name.
-keep class com.google.mediapipe.** { *; }
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.mediapipe.proto.**
-dontwarn com.google.protobuf.**
