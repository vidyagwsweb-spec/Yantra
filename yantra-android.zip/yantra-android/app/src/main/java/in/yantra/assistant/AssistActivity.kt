package `in`.yantra.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.AssistPanel
import `in`.yantra.assistant.ui.YantraTheme
import `in`.yantra.assistant.util.AppSettings
import java.util.function.Consumer

/**
 * The wake-up screen: opens on top of whatever app you were in, blurs it,
 * fades to black at the bottom, starts listening immediately, and disappears
 * when dismissed.
 *
 * Summoned from the Quick Settings tile, or by the system assistant gesture
 * once Yantra is set as the default assistant app (this activity declares
 * ACTION_ASSIST for exactly that).
 */
class AssistActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null

    /** True while the system is actually blurring what is behind this window. */
    private var blurred by mutableStateOf(false)
    private var blurWatcher: Consumer<Boolean>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // draw under the status and navigation bars: the scrim reaches every edge
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setUpBlur()

        listener = Listener(
            this,
            onPartial = { vm.markListening(true) },
            onResult = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.send(it)
            },
            onError = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.showNotice(it)
            },
            onTranscript = { vm.updateTranscript(it) }
        )

        setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            YantraTheme(darkTheme = dark) {
                AssistPanel(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    transcript = vm.transcript,
                    notice = vm.notice,
                    blurred = blurred,
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { startListening() },
                    onOpenLink = { openLink(it) },
                    onClose = { dismiss() }
                )
            }
        }

        // open listening straight away
        startListening()
    }

    /**
     * Blur the app behind us (Android 12+, when the device allows it). The
     * system can turn this off at any time, for example in battery saver, so
     * the panel is told and darkens the top of its scrim to compensate.
     */
    private fun setUpBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        window.attributes = window.attributes.apply { blurBehindRadius = 48 }

        val watcher = Consumer<Boolean> { enabled -> blurred = enabled }
        blurWatcher = watcher
        windowManager.addCrossWindowBlurEnabledListener(mainExecutor, watcher)
        blurred = windowManager.isCrossWindowBlurEnabled
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            vm.showNotice("Microphone permission is off. Open Yantra once to allow it, or type below.")
            return
        }
        if (vm.listening) {
            listener?.stop()
            vm.markListening(false)
            vm.updateTranscript("")
            return
        }
        // don't let our own voice reply leak into the recogniser
        vm.speaker.stop()
        vm.updateTranscript("")
        vm.markListening(true)
        listener?.start()
    }

    private fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            dismiss()
        } catch (e: Exception) {
            // no browser installed: stay where we are
        }
    }

    private fun dismiss() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= 31) {
            blurWatcher?.let { windowManager.removeCrossWindowBlurEnabledListener(it) }
        }
        listener?.stop()
    }
}
