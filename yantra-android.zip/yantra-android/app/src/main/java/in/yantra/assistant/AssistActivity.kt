package `in`.yantra.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.AssistPanel
import `in`.yantra.assistant.ui.YantraTheme
import `in`.yantra.assistant.util.AppSettings

/**
 * The Gemini-style panel: a translucent window that opens on top of whatever
 * app you were in, starts listening immediately, and disappears when dismissed.
 *
 * Summoned from the Quick Settings tile, or by the system assistant gesture
 * once Yantra is set as the default assistant app (this activity declares
 * ACTION_ASSIST for exactly that).
 */
class AssistActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // tapping the dimmed area behind the panel dismisses it
        setFinishOnTouchOutside(true)

        listener = Listener(
            this,
            onPartial = { vm.markListening(true) },
            onResult = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.send(it)
            },
            onError = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.showNotice(it)
            },
            onTranscript = { vm.updateTranscript(it) }
        )

        setContent {
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            YantraTheme(darkTheme = dark) {
                AssistPanel(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    transcript = vm.transcript,
                    notice = vm.notice,
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { startListening() },
                    onClose = { dismiss() }
                )
            }
        }

        // open listening straight away, like Gemini
        startListening()
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            vm.showNotice("Microphone permission is off. Open Yantra once to allow it, or type below.")
            return
        }
        if (vm.listening) {
            listener?.stop()
            vm.markListening(false)
            vm.updateTranscript("")
            return
        }
        // don't let our own voice reply leak into the recogniser
        vm.speaker.stop()
        vm.updateTranscript("")
        vm.markListening(true)
        listener?.start()
    }

    private fun dismiss() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.stop()
    }
}
