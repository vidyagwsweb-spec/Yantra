package `in`.yantra.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import `in`.yantra.assistant.actions.ActionExecutor
import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.speech.Speaker
import `in`.yantra.assistant.util.Prefs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMsg(val fromUser: Boolean, val text: String, val stamp: Long = System.nanoTime())

class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val executor = ActionExecutor(app)
    private val prefs = Prefs(app)
    val speaker = Speaker(app)

    val messages = mutableStateListOf(
        ChatMsg(
            false,
            "Yantra here. Native Android, no language model — say \"help\" for the full list."
        )
    )

    var listening by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var timerLeft by mutableStateOf("")
        private set
    var lastSpoken by mutableStateOf("")
        private set

    private var lastUser: String? = null
    private var lastBot: String? = null

    // timer state
    private var timerJob: Job? = null
    private var timerEndsAt = 0L
    private var timerRemaining = 0L
    private var timerPaused = false
    private var timerLabel = ""

    init {
        speaker.init()
    }

    /** Not `setListening`: the `listening` property already claims that JVM signature. */
    fun markListening(value: Boolean) { listening = value }

    /** Runs one command end to end. */
    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        messages.add(ChatMsg(true, text))

        viewModelScope.launch {
            busy = true
            try {
                val parsed = Router.route(
                    text,
                    Ctx(
                        now = System.currentTimeMillis(),
                        lastUser = lastUser,
                        lastBot = lastBot
                    )
                )

                // timer actions live in the view model, not the executor
                val handledInVm = handleTimerAction(parsed)
                if (handledInVm != null) {
                    reply(handledInVm)
                } else {
                    val result = executor.run(parsed)
                    if (result.text.isNotEmpty()) reply(result.text, result.speak)
                }

                lastUser = text
            } catch (e: Exception) {
                reply("Something went wrong: ${e.message ?: "unknown error"}.")
            } finally {
                busy = false
            }
        }
    }

    private fun reply(text: String, speak: String = text) {
        messages.add(ChatMsg(false, text))
        lastBot = text
        lastSpoken = speak
        speaker.say(speak)
    }

    // ------------------------------------------------------------- timers

    private fun handleTimerAction(p: Parsed): String? = when (p.action) {
        "timer" -> {
            startTimer(p.num, p.a.ifEmpty { "timer" })
            "Timer set for ${human(p.num)}."
        }
        "timer-pause" -> {
            if (timerJob == null) "No timer is running."
            else {
                timerRemaining = (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                timerPaused = true
                timerJob?.cancel()
                timerJob = null
                "Paused with ${human(timerRemaining)} left."
            }
        }
        "timer-resume" -> {
            if (!timerPaused || timerRemaining <= 0) "There is no paused timer."
            else {
                timerPaused = false
                runTimer(timerRemaining)
                "Resumed, ${human(timerRemaining)} left."
            }
        }
        "timer-cancel" -> {
            if (timerJob == null && !timerPaused) "No timer is running."
            else {
                timerJob?.cancel()
                timerJob = null
                timerPaused = false
                timerLeft = ""
                "Timer cancelled."
            }
        }
        "timer-status" -> {
            val left = when {
                timerPaused -> timerRemaining
                timerJob != null -> (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                else -> 0
            }
            if (left <= 0) "No timer is running."
            else "${human(left)} left on the $timerLabel" + if (timerPaused) " (paused)." else "."
        }
        else -> null
    }

    private fun startTimer(ms: Long, label: String) {
        timerJob?.cancel()
        timerLabel = label
        timerPaused = false
        timerRemaining = 0
        runTimer(ms)
    }

    private fun runTimer(ms: Long) {
        timerEndsAt = System.currentTimeMillis() + ms
        timerJob = viewModelScope.launch {
            while (true) {
                val left = timerEndsAt - System.currentTimeMillis()
                timerLeft = if (left <= 0) "" else human(left)
                if (left <= 0) break
                delay(250)
            }
            timerJob = null
            reply("Your $timerLabel is done.", "Your $timerLabel is done.")
        }
    }

    private fun human(ms: Long): String {
        val s = (ms / 1000).toInt()
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return buildString {
            if (h > 0) append("${h}h ")
            append("${m}m ")
            append(if (sec < 10) "0$sec" else "$sec")
            append("s")
        }
    }

    fun userName(): String = prefs.name()

    override fun onCleared() {
        super.onCleared()
        speaker.shutdown()
        timerJob?.cancel()
    }
}
