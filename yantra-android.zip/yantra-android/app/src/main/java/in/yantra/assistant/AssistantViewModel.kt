package `in`.yantra.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import `in`.yantra.assistant.actions.ActionExecutor
import `in`.yantra.assistant.brain.Brain
import `in`.yantra.assistant.brain.Thought
import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.speech.Speaker
import `in`.yantra.assistant.speech.VoiceChoice
import `in`.yantra.assistant.util.AppSettings
import `in`.yantra.assistant.util.Prefs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMsg(
    val fromUser: Boolean,
    val text: String,
    val stamp: Long = System.nanoTime(),
    /** Set on looked-up answers: where they came from, and the page to read more. */
    val source: String = "",
    val link: String = ""
)

class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val executor = ActionExecutor(app)
    private val prefs = Prefs(app)
    private val settings = AppSettings(prefs)
    private val brain = Brain()
    val speaker = Speaker(app)

    val messages = mutableStateListOf(
        ChatMsg(
            false,
            "Yantra here. A small brain that lives on your phone, no cloud — say \"help\" for the full list."
        )
    )

    // ------------------------------------------------ what Settings shows

    var language by mutableStateOf(settings.language)
        private set
    var themeMode by mutableStateOf(settings.theme)
        private set
    var speakReplies by mutableStateOf(settings.speakReplies)
        private set
    var smartReplies by mutableStateOf(settings.smartReplies)
        private set
    var lookupAnswers by mutableStateOf(settings.lookupAnswers)
        private set
    var speechRate by mutableStateOf(speaker.rate)
        private set
    var speechPitch by mutableStateOf(speaker.pitch)
        private set
    var voiceChoices by mutableStateOf<List<VoiceChoice>>(emptyList())
        private set
    var selectedVoice by mutableStateOf("")
        private set
    var languageHasVoices by mutableStateOf(true)
        private set
    var shortcutCount by mutableStateOf(0)
        private set
    var displayName by mutableStateOf(prefs.name())
        private set

    var listening by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var timerLeft by mutableStateOf("")
        private set
    var lastSpoken by mutableStateOf("")
        private set

    /** Live words from the recogniser while the mic is open. */
    var transcript by mutableStateOf("")
        private set

    /** A short, non-conversational message: "I heard nothing", "mic permission missing". */
    var notice by mutableStateOf("")
        private set

    private var lastUser: String? = null
    private var lastBot: String? = null
    private var lastTarget: String? = null

    // timer state
    private var timerJob: Job? = null
    private var timerEndsAt = 0L
    private var timerRemaining = 0L
    private var timerPaused = false
    private var timerLabel = ""

    init {
        brain.loadTaught(prefs.list("taught"))
        shortcutCount = brain.taughtCount()
        brain.onTaughtChanged = {
            prefs.saveList("taught", brain.taughtItems())
            shortcutCount = brain.taughtCount()
        }
        // voices are only known once the engine has started
        speaker.init { refreshVoices() }
    }

    // ------------------------------------------------------------ settings
    // Named chooseX/changeX/toggleX rather than setX: the properties above
    // already claim the setX JVM signatures.

    fun refreshVoices() {
        voiceChoices = speaker.voiceChoices()
        selectedVoice = speaker.currentVoiceName() ?: ""
        languageHasVoices = speaker.hasVoicesForLanguage()
        speechRate = speaker.rate
        speechPitch = speaker.pitch
        shortcutCount = brain.taughtCount()
        displayName = prefs.name()
    }

    fun chooseLanguage(tag: String) {
        val ok = speaker.setLanguage(tag)
        settings.language = speaker.languageTag
        language = speaker.languageTag
        refreshVoices()
        if (ok) speaker.preview("Hello, this is how I sound now.")
    }

    fun chooseVoice(name: String) {
        if (speaker.chooseVoice(name)) selectedVoice = name
    }

    fun changeRate(value: Float) {
        speaker.rate = value
        speechRate = speaker.rate
    }

    fun changePitch(value: Float) {
        speaker.pitch = value
        speechPitch = speaker.pitch
    }

    /** Plays a sample at the current speed and pitch, e.g. when a slider is released. */
    fun previewSpeech() = speaker.preview("This is how I sound.")

    fun chooseTheme(mode: String) {
        settings.theme = mode
        themeMode = mode
    }

    fun toggleSpeak(on: Boolean) {
        settings.speakReplies = on
        speaker.enabled = on
        speakReplies = on
        if (!on) speaker.stop()
    }

    fun toggleSmart(on: Boolean) {
        settings.smartReplies = on
        smartReplies = on
    }

    fun toggleLookup(on: Boolean) {
        settings.lookupAnswers = on
        lookupAnswers = on
    }

    fun saveName(value: String) {
        prefs.set("name", value.trim())
        displayName = value
    }

    fun forgetShortcuts() {
        brain.clearTaught()
    }

    fun installVoices(): Boolean = speaker.openVoiceInstall()

    /** Not `setListening`: the `listening` property already claims that JVM signature. */
    fun markListening(value: Boolean) {
        listening = value
        if (value) notice = ""
    }

    // Not `setTranscript` / `setNotice`: the properties above already claim those signatures.
    fun updateTranscript(text: String) { transcript = text }
    fun showNotice(text: String) { notice = text }

    /** A line from Yantra that is not a reply to anything the person said. */
    fun addNote(text: String) {
        if (text.isNotBlank()) messages.add(ChatMsg(false, text))
    }

    /** Runs one command end to end. */
    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        notice = ""
        transcript = ""
        messages.add(ChatMsg(true, text))

        viewModelScope.launch {
            busy = true
            try {
                process(text)
            } catch (e: Exception) {
                reply("Something went wrong: ${e.message ?: "unknown error"}.")
            } finally {
                busy = false
            }
        }
    }

    private fun ctx() = Ctx(
        now = System.currentTimeMillis(),
        lastUser = lastUser,
        lastBot = lastBot,
        lastTarget = lastTarget
    )

    /** Does the router understand this as a command? Used before saving a taught shortcut. */
    private fun understood(command: String): Boolean = Router.routeAll(command, Ctx()).all {
        it.action != "unknown" && it.action != "ask" && it.action != "empty"
    }

    /**
     * True when the router had nothing real: no command matched, or the text only
     * fell through to the catch-all web search for a question. An explicit
     * "search for ..." is a command and is left alone.
     */
    private fun fellThrough(commands: List<Parsed>, text: String): Boolean {
        if (commands.size != 1) return false
        val p = commands[0]
        if (p.action == "unknown") return true
        return p.action == "search" && !EXPLICIT_SEARCH.containsMatchIn(Router.normalize(text))
    }

    private suspend fun process(text: String) {
        // someone who is struggling comes before everything else
        Brain.crisis(text)?.let { reply(it.text); return }

        if (smartReplies) {
            brain.userName = prefs.name()

            // a waiting "did you mean ...?" gets the first word, since "yes" and "ok" mean other things to the router
            brain.answerPending(text)?.let { if (act(it)) return }
            // teaching, listing and forgetting shortcuts
            brain.learn(text) { understood(it) }?.let { if (act(it)) return }
            // shortcuts you taught, which may override a built-in phrase
            brain.recall(text)?.let { if (act(it)) return }
            // "another one"
            brain.more(text)?.let { if (act(it)) return }
        }

        val commands = Router.routeAll(text, ctx())

        if (smartReplies && fellThrough(commands, text)) {
            if (act(brain.think(text))) return
        } else {
            brain.forgetTopic()
        }

        runCommands(text, commands)
    }

    /** Shows what the brain decided. False means it had nothing, so the normal path continues. */
    private suspend fun act(t: Thought): Boolean {
        when (t) {
            is Thought.Reply -> reply(t.text)
            is Thought.Confirm -> reply(t.prompt)
            is Thought.Run -> {
                val commands = Router.routeAll(t.command, ctx())
                runCommands(t.command, commands, prefix = "Taking that as \"${t.command}\".\n")
            }
            Thought.Pass -> return false
        }
        return true
    }

    private suspend fun runCommands(text: String, commands: List<Parsed>, prefix: String = "") {
        val shown = ArrayList<String>()
        val spoken = ArrayList<String>()
        var link = ""
        var source = ""
        for (parsed in commands) {
            // timer actions live in the view model, not the executor
            val handledInVm = handleTimerAction(parsed)
            if (handledInVm != null) {
                shown.add(handledInVm)
                spoken.add(handledInVm)
            } else {
                val result = executor.run(parsed)
                if (result.text.isNotEmpty()) {
                    shown.add(result.text)
                    spoken.add(result.speak)
                    if (result.link.isNotEmpty()) {
                        link = result.link
                        source = result.source
                    }
                }
            }
        }
        if (shown.isNotEmpty()) reply(prefix + shown.joinToString("\n"), spoken.joinToString(" "), source, link)

        // what "a bit more" or "turn it up" should act on next
        lastTarget = when {
            commands.lastOrNull()?.action?.startsWith("brightness") == true -> "brightness"
            commands.lastOrNull()?.action?.startsWith("volume") == true -> "volume"
            else -> null
        }
        lastUser = text
    }

    private fun reply(text: String, speak: String = text, source: String = "", link: String = "") {
        messages.add(ChatMsg(false, text, source = source, link = link))
        lastBot = text
        lastSpoken = speak
        speaker.say(speak)
    }

    // ------------------------------------------------------------- timers

    private fun handleTimerAction(p: Parsed): String? = when (p.action) {
        "timer" -> {
            startTimer(p.num, p.a.ifEmpty { "timer" })
            "Timer set for ${human(p.num)}."
        }
        // the speaker belongs to the view model, so voice commands live here
        "voice" -> when (p.a) {
            "next" -> when (speaker.voiceCount()) {
                0 -> "My voice is still starting up, or this phone has no English voices yet. Say \"install a voice\"."
                1 -> "Only one English voice is installed. Say \"install a voice\" to get more natural ones."
                else -> (speaker.nextVoice() ?: "I could not switch voices.") + " This is how I sound now."
            }
            "list" -> speaker.voiceSummary()
            "install" ->
                if (speaker.openVoiceInstall())
                    "Opening the voice downloads. Pick an English voice, then say \"change your voice\"."
                else
                    "I could not open them. Try Settings, System, Languages, Text-to-speech output."
            "deeper" -> { speaker.shiftPitch(-0.1f); "Okay, a little deeper." }
            "higher" -> { speaker.shiftPitch(0.1f); "Okay, a little higher." }
            "reset" -> { speaker.resetVoice(); "Voice reset to automatic." }
            else -> null
        }
        // speaking speed lives with the speaker, which the view model owns
        "pref" -> if (p.a == "rate") {
            speaker.rate = if (p.b == "slow") 0.8f else 1.3f
            if (p.b == "slow") "Okay, I will speak more slowly." else "Okay, I will speak faster."
        } else null
        "timer-pause" -> {
            if (timerJob == null) "No timer is running."
            else {
                timerRemaining = (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                timerPaused = true
                timerJob?.cancel()
                timerJob = null
                "Paused with ${human(timerRemaining)} left."
            }
        }
        "timer-resume" -> {
            if (!timerPaused || timerRemaining <= 0) "There is no paused timer."
            else {
                timerPaused = false
                runTimer(timerRemaining)
                "Resumed, ${human(timerRemaining)} left."
            }
        }
        "timer-cancel" -> {
            if (timerJob == null && !timerPaused) "No timer is running."
            else {
                timerJob?.cancel()
                timerJob = null
                timerPaused = false
                timerLeft = ""
                "Timer cancelled."
            }
        }
        "timer-status" -> {
            val left = when {
                timerPaused -> timerRemaining
                timerJob != null -> (timerEndsAt - System.currentTimeMillis()).coerceAtLeast(0)
                else -> 0
            }
            if (left <= 0) "No timer is running."
            else "${human(left)} left on the $timerLabel" + if (timerPaused) " (paused)." else "."
        }
        else -> null
    }

    private fun startTimer(ms: Long, label: String) {
        timerJob?.cancel()
        timerLabel = label
        timerPaused = false
        timerRemaining = 0
        runTimer(ms)
    }

    private fun runTimer(ms: Long) {
        timerEndsAt = System.currentTimeMillis() + ms
        timerJob = viewModelScope.launch {
            while (true) {
                val left = timerEndsAt - System.currentTimeMillis()
                timerLeft = if (left <= 0) "" else human(left)
                if (left <= 0) break
                delay(250)
            }
            timerJob = null
            reply("Your $timerLabel is done.", "Your $timerLabel is done.")
        }
    }

    private fun human(ms: Long): String {
        val s = (ms / 1000).toInt()
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return buildString {
            if (h > 0) append("${h}h ")
            append("${m}m ")
            append(if (sec < 10) "0$sec" else "$sec")
            append("s")
        }
    }

    fun userName(): String = prefs.name()

    private companion object {
        val EXPLICIT_SEARCH = Regex("^(?:search|google|look up|lookup|find|define|meaning of|translate)\\b")
    }

    override fun onCleared() {
        super.onCleared()
        speaker.shutdown()
        timerJob?.cancel()
    }
}
