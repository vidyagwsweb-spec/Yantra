package `in`.yantra.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.ChatScreen
import `in`.yantra.assistant.ui.SettingsScreen
import `in`.yantra.assistant.util.AppSettings
import `in`.yantra.assistant.ui.YantraTheme

class MainActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null
    private var pendingSpeech by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) {
            if (pendingSpeech) {
                pendingSpeech = false
                startListening()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        listener = Listener(
            this,
            onPartial = { vm.markListening(true) },
            onResult = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.send(it)
            },
            onError = {
                vm.markListening(false)
                vm.updateTranscript("")
                vm.addNote(it)
            },
            onTranscript = { vm.updateTranscript(it) }
        )

        requestStartupPermissions()

        setContent {
            // isSystemInDarkTheme() is @Composable, so it has to be called in the
            // composable scope — not inside the mutableStateOf lambda.
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                AppSettings.THEME_DARK -> true
                AppSettings.THEME_LIGHT -> false
                else -> systemDark
            }
            var showSettings by rememberSaveable { mutableStateOf(false) }

            // back closes Settings first, then leaves the app
            BackHandler(enabled = showSettings) { showSettings = false }

            // keep the system bars in step with the app palette
            LaunchedEffect(dark) {
                val paper = if (dark) 0xFF0A0807.toInt() else 0xFFF5F2EC.toInt()
                window.statusBarColor = paper
                window.navigationBarColor = paper
                window.decorView.setBackgroundColor(paper)
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightStatusBars = !dark
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightNavigationBars = !dark
            }

            YantraTheme(darkTheme = dark) {
              Box(modifier = Modifier.fillMaxSize()) {
                ChatScreen(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    timerLeft = vm.timerLeft,
                    transcript = vm.transcript,
                    dark = dark,
                    onToggleTheme = {
                        vm.chooseTheme(if (dark) AppSettings.THEME_LIGHT else AppSettings.THEME_DARK)
                    },
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { toggleMic() },
                    onOpenSettings = {
                        vm.refreshVoices()
                        showSettings = true
                    }
                )
                if (showSettings) {
                    SettingsScreen(
                        language = vm.language,
                        themeMode = vm.themeMode,
                        speakReplies = vm.speakReplies,
                        smartReplies = vm.smartReplies,
                        lookupAnswers = vm.lookupAnswers,
                        rate = vm.speechRate,
                        pitch = vm.speechPitch,
                        voices = vm.voiceChoices,
                        selectedVoice = vm.selectedVoice,
                        languageHasVoices = vm.languageHasVoices,
                        shortcutCount = vm.shortcutCount,
                        name = vm.displayName,
                        onBack = { showSettings = false },
                        onLanguage = { vm.chooseLanguage(it) },
                        onTheme = { vm.chooseTheme(it) },
                        onSpeak = { vm.toggleSpeak(it) },
                        onSmart = { vm.toggleSmart(it) },
                        onLookup = { vm.toggleLookup(it) },
                        onRate = { vm.changeRate(it) },
                        onPitch = { vm.changePitch(it) },
                        onPreviewSpeech = { vm.previewSpeech() },
                        onVoice = { vm.chooseVoice(it) },
                        onInstallVoices = { vm.installVoices() },
                        onName = { vm.saveName(it) },
                        onForgetShortcuts = { vm.forgetShortcuts() }
                    )
                }
              }
            }
        }
    }

    private fun toggleMic() {
        if (vm.listening) {
            listener?.stop()
            vm.markListening(false)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSpeech = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        startListening()
    }

    private fun startListening() {
        vm.markListening(true)
        listener?.start()
    }

    private fun requestStartupPermissions() {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) wanted.add(Manifest.permission.BLUETOOTH_CONNECT)

        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.stop()
    }
}
