package `in`.yantra.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import `in`.yantra.assistant.service.OverlayService
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.ui.ChatScreen
import `in`.yantra.assistant.ui.YantraTheme

class MainActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var listener: Listener? = null
    private var pendingSpeech by mutableStateOf(false)
    private var overlayOn by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) {
            if (pendingSpeech) {
                pendingSpeech = false
                startListening()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        listener = Listener(
            this,
            onPartial = { vm.setListening(true) },
            onResult = {
                vm.setListening(false)
                vm.send(it)
            },
            onError = {
                vm.setListening(false)
                if (it.isNotBlank()) vm.send("__error__ $it")
            }
        )

        requestStartupPermissions()

        setContent {
            // isSystemInDarkTheme() is @Composable, so it has to be called in the
            // composable scope — not inside the mutableStateOf lambda.
            val systemDark = isSystemInDarkTheme()
            var dark by rememberSaveable { mutableStateOf(systemDark) }

            // keep the system bars in step with the app palette
            LaunchedEffect(dark) {
                val paper = if (dark) 0xFF0A0807.toInt() else 0xFFF5F2EC.toInt()
                window.statusBarColor = paper
                window.navigationBarColor = paper
                window.decorView.setBackgroundColor(paper)
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightStatusBars = !dark
                WindowCompat.getInsetsController(window, window.decorView)
                    .isAppearanceLightNavigationBars = !dark
            }

            YantraTheme(darkTheme = dark) {
                ChatScreen(
                    messages = vm.messages,
                    listening = vm.listening,
                    busy = vm.busy,
                    timerLeft = vm.timerLeft,
                    dark = dark,
                    overlayOn = overlayOn,
                    onToggleTheme = { dark = !dark },
                    onToggleOverlay = { toggleOverlay() },
                    onSend = { text -> if (text.isNotBlank()) vm.send(text) },
                    onMic = { toggleMic() }
                )
            }
        }
    }

    private fun toggleMic() {
        if (vm.listening) {
            listener?.stop()
            vm.setListening(false)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSpeech = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        startListening()
    }

    private fun startListening() {
        vm.setListening(true)
        listener?.start()
    }

    /**
     * The floating orb lives in an application-overlay window, so it stays on
     * screen above every other app. Android requires the user to grant "display
     * over other apps" first, which we can only ask for via a settings screen.
     */
    private fun toggleOverlay() {
        if (overlayOn) {
            OverlayService.stop(this)
            overlayOn = false
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + packageName)
                )
            )
            return
        }
        OverlayService.start(this)
        overlayOn = true
    }

    override fun onResume() {
        super.onResume()
        // the overlay dies with its permission, so keep the flag honest
        if (overlayOn && !Settings.canDrawOverlays(this)) overlayOn = false
    }

    private fun requestStartupPermissions() {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) wanted.add(Manifest.permission.BLUETOOTH_CONNECT)

        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.stop()
    }
}
