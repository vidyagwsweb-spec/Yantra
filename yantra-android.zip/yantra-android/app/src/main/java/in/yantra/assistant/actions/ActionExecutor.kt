package `in`.yantra.assistant.actions

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.UiModeManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.util.Prefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class ActResult(
    val text: String,
    val speak: String = text
)

/**
 * Every action here is a real Android API call. Nothing is faked — where the
 * platform forbids a silent change (Wi-Fi, aeroplane mode, battery saver) the
 * app opens the system panel instead and says so.
 */
class ActionExecutor(private val ctx: Context) {

    private val prefs = Prefs(ctx)

    private fun has(perm: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    suspend fun run(p: Parsed): ActResult = when (p.action) {
        "say" -> ActResult(p.say)
        "stop" -> ActResult("Stopped.")
        "empty" -> ActResult("")
        "unknown" -> ActResult(
            "I did not catch a command in that. Say \"help\" to hear what I can do."
        )
        "help" -> ActResult(HELP)

        // ---------------------------------------------------------- system
        "wifi" -> wifi(p.on)
        "bluetooth" -> bluetooth(p.on)
        "airplane" -> panel(
            Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS),
            "Aeroplane mode is a protected system switch. Here is the panel."
        )
        "mobile-data" -> panel(
            Intent(
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                else Settings.ACTION_DATA_ROAMING_SETTINGS
            ),
            "Mobile data is a protected system switch. Here is the panel."
        )
        "battery-saver" -> panel(
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            "Battery saver cannot be toggled by an app on this version. Here is the panel."
        )
        "brightness" -> brightness(p.pct)
        "brightness-delta" -> {
            val from = currentBrightness()
            brightness(from + p.num.toInt(), from)
        }
        "volume" -> volume(p.pct)
        "volume-delta" -> {
            val from = currentVolumePercent()
            volume(from + p.num.toInt(), from)
        }
        "flashlight" -> flashlight(p.on)
        "dnd" -> dnd(p.on)
        "dark-mode" -> darkMode(p.on)
        "battery" -> battery()
        "storage" -> storage()
        "network" -> network()
        "device" -> device()
        "location" -> location()

        // ------------------------------------------------------------ apps
        "open-app" -> openApp(p.a)
        "home" -> home()
        "list-apps" -> listApps()

        // ---------------------------------------------------------- people
        "call" -> call(p.a)
        "call-contact" -> callContact(p.a)
        "sms" -> sms(p.a, p.b)
        "sms-contact" -> smsContact(p.a, p.b)
        "whatsapp" -> whatsapp(p.a, p.b)
        "whatsapp-contact" -> whatsappContact(p.a, p.b)
        "find-contact" -> findContact(p.a)
        "read-notifications" -> readNotifications()

        // ---------------------------------------------------------- alarms
        "alarm" -> setAlarm(p.num.toInt(), p.pct)
        "alarm-list" -> alarmList()
        "alarm-cancel" -> alarmCancel()
        "remind" -> remind(p.a, p.at)
        "ask" -> ActResult(p.say)

        // ------------------------------------------------------ media, sound
        "media" -> media(p.a)
        "play" -> playQuery(p.a, p.b)
        "ringer" -> ringer(p.a)

        // ----------------------------------------------------------- screen
        "auto-brightness" -> autoBrightness(p.on)
        "rotate" -> rotate(p.on)
        "screen-timeout" -> screenTimeout(p.num)
        "settings" -> settingsPage(p.a, p.b)

        // -------------------------------------------------------- apps, web
        "url" -> web(if (p.a.startsWith("http")) p.a else "https://" + p.a, "Opening ${p.a}")
        "uninstall" -> uninstall(p.a)
        "app-info" -> appInfo(p.a)
        "translate" -> translate(p.a, p.b)
        "video" -> {
            launch(Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActResult("Video camera open.")
        }
        // ------------------------------------------------------- preferences
        "pref-name" -> {
            val name = p.a.split(" ").filter { it.isNotEmpty() }
                .joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
            prefs.set("name", name)
            ActResult("Nice to meet you, $name.")
        }
        "pref" -> {
            prefs.set(p.a, p.b)
            if (p.a == "units") ActResult("Saved ${p.b} units as your preference. Nothing switches on it yet, but it is stored.")
            else ActResult("Saved.")
        }

        "clear-notifications" -> clearNotifications()
        "email" -> email(p.a, p.b)

        // ---------------------------------------------------------- clipboard
        "clipboard-copy" -> {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Yantra", p.a))
            ActResult("Copied to the clipboard.")
        }
        "clipboard-read" -> {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip
                ?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
            if (text.isBlank()) ActResult("The clipboard is empty, or Android is hiding it while I am in the background.")
            else ActResult("On the clipboard: $text", "The clipboard says: $text")
        }

        // -------------------------------------------------------------- chance
        "coin" -> ActResult(if (Random.nextBoolean()) "Heads." else "Tails.")
        "dice" -> {
            val n = p.pct.coerceIn(1, 10)
            val sides = p.num.toInt().coerceIn(2, 1000)
            val rolls = List(n) { Random.nextInt(1, sides + 1) }
            ActResult(
                if (n == 1) "You rolled ${rolls[0]}."
                else "You rolled ${rolls.joinToString(", ")}. Total ${rolls.sum()}."
            )
        }
        "random" -> {
            val lo = p.a.toLongOrNull() ?: 1L
            val hi = p.b.toLongOrNull() ?: 100L
            ActResult("Your number is ${Random.nextLong(minOf(lo, hi), maxOf(lo, hi) + 1)}.")
        }
        "choose" -> {
            val options = p.a.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            if (options.size < 2) ActResult("Give me at least two options.")
            else ActResult("I pick ${options.random()}.")
        }

        // -------------------------------------------------------- calendar
        "calendar-add" -> calendarAdd(p.a, p.at)
        "agenda" -> agenda()

        // ----------------------------------------------------------- lists
        "list-add" -> {
            val items = prefs.addToList(p.a, p.b)
            ActResult("Added \"${p.b}\" to ${p.a}. ${items.size} item(s) in there.", "Added.")
        }
        "list-show" -> {
            val items = prefs.list(p.a)
            if (items.isEmpty()) ActResult("Your ${p.a} is empty.")
            else ActResult(
                "Your ${p.a}:\n" + items.mapIndexed { i, v -> "${i + 1}. $v" }.joinToString("\n"),
                "You have ${items.size} items in your ${p.a}."
            )
        }
        "list-remove" -> {
            val items = prefs.removeFromList(p.a, p.b)
            ActResult("Removed \"${p.b}\" from ${p.a}. ${items.size} left.")
        }
        "list-clear" -> {
            val n = prefs.clearList(p.a)
            ActResult(if (n > 0) "Cleared $n item(s) from ${p.a}." else "${p.a} was already empty.")
        }

        // ---------------------------------------------------------- search
        "search" -> web("https://www.google.com/search?q=" + enc(p.a), "Searching for \"${p.a}\"")
        "navigate" -> web(
            "https://www.google.com/maps/dir/?api=1&destination=" + enc(p.a),
            "Directions to ${p.a}"
        )
        "nearby" -> web(
            "https://www.google.com/maps/search/?api=1&query=" + enc(p.a + " near me"),
            "Looking for ${p.a} nearby"
        )
        "weather" -> Weather.fetch(ctx, p.a, p.b)
        "world-time" -> worldTime(p.a)
        "countdown" -> countdown(p.a)

        // ---------------------------------------------------------- camera
        "camera" -> takePhoto()

        else -> ActResult("That command is wired in the parser but not the executor yet.")
    }

    // ================================================================= system

    private fun wifi(on: Boolean): ActResult {
        if (Build.VERSION.SDK_INT >= 29) {
            launch(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult(
                "Android 10 and later do not let apps flip Wi-Fi silently, so here is the panel.",
                "Opening the Wi-Fi panel."
            )
        }
        @Suppress("DEPRECATION")
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        @Suppress("DEPRECATION")
        val ok = wm.setWifiEnabled(on)
        return ActResult(if (ok) "Wi-Fi ${if (on) "on" else "off"}." else "Android refused the Wi-Fi change.")
    }

    private fun bluetooth(on: Boolean): ActResult {
        if (!has(Manifest.permission.BLUETOOTH_CONNECT) && Build.VERSION.SDK_INT >= 31)
            return ActResult("I need the nearby-devices permission for Bluetooth. Grant it in app settings.")
        val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager
        val adapter = mgr.adapter ?: return ActResult("This device has no Bluetooth adapter.")
        @Suppress("DEPRECATION")
        if (adapter.isEnabled == on) return ActResult("Bluetooth is already ${if (on) "on" else "off"}.")
        return try {
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT < 33) {
                @Suppress("DEPRECATION")
                if (on) adapter.enable() else adapter.disable()
                val nowOn = adapter.isEnabled
                if (nowOn == on) ActResult("Bluetooth ${if (on) "on" else "off"}.")
                else {
                    val action = if (on) BT_REQUEST_ENABLE else BT_REQUEST_DISABLE
                    launch(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    ActResult("Confirm the Bluetooth prompt.")
                }
            } else {
                val action = if (on) BT_REQUEST_ENABLE else BT_REQUEST_DISABLE
                launch(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                ActResult("Confirm the Bluetooth prompt.")
            }
        } catch (e: SecurityException) {
            ActResult("Android blocked the Bluetooth change without the nearby-devices permission.")
        }
    }

    private fun brightness(percent: Int, from: Int? = null): ActResult {
        if (!Settings.System.canWrite(ctx)) {
            launch(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return ActResult(
                "I need the \"modify system settings\" permission for brightness. Grant it and ask again.",
                "I need permission to change brightness."
            )
        }
        val p = percent.coerceIn(1, 100)
        val raw = (p / 100.0 * 255).toInt().coerceIn(1, 255)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, raw)
        val said = when {
            from == null -> "Brightness set to $p%."
            from == p -> "Brightness is already at $p%."
            else -> "Brightness $from% \u2192 $p%."
        }
        return ActResult(said, "Brightness $p percent.")
    }

    private fun currentBrightness(): Int {
        val raw = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) { 128 }
        return (raw / 255.0 * 100).toInt()
    }

    private fun currentVolumePercent(): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / max
    }

    private fun volume(percent: Int, from: Int? = null): ActResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = percent.coerceIn(0, 100)
        val idx = Math.round(p / 100.0 * max).toInt().coerceIn(0, max)
        return try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
            val said = when {
                p == 0 -> "Muted."
                from == null -> "Volume set to $p%."
                from == p -> "Volume is already at $p%."
                else -> "Volume $from% \u2192 $p%."
            }
            ActResult(said, if (p == 0) "Muted." else "Volume $p percent.")
        } catch (e: SecurityException) {
            ActResult("Android blocked the volume change.")
        }
    }

    private fun flashlight(on: Boolean): ActResult {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { camId ->
            cm.getCameraCharacteristics(camId).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActResult("This phone has no camera flash.")
        return try {
            cm.setTorchMode(id, on)
            ActResult(
                if (on) "Flashlight on."
                else "Flashlight off."
            )
        } catch (e: Exception) {
            ActResult("I could not reach the flash: ${e.message ?: "unknown error"}.")
        }
    }

    private fun dnd(on: Boolean): ActResult {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult(
                "Do Not Disturb needs the policy-access permission. Grant it on the screen I just opened.",
                "I need do not disturb access."
            )
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return ActResult(
            if (on) "Do Not Disturb on."
            else "Do Not Disturb off."
        )
    }

    private fun darkMode(on: Boolean): ActResult {
        return if (Build.VERSION.SDK_INT >= 31) {
            val um = ctx.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
            um.setApplicationNightMode(if (on) UiModeManager.MODE_NIGHT_YES else UiModeManager.MODE_NIGHT_NO)
            ActResult("Dark mode ${if (on) "on" else "off"} for this app.", "Dark mode ${if (on) "on" else "off"}.")
        } else {
            ActResult("System-wide dark mode needs Android 12 or later. This app follows the system theme.")
        }
    }

    private fun battery(): ActResult {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return ActResult(
            "Battery at $level%" + if (charging) ", charging." else ".",
            "Battery at $level percent."
        )
    }

    private fun storage(): ActResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / 1_073_741_824.0
        val totalGb = stat.totalBytes / 1_073_741_824.0
        return ActResult(
            String.format(Locale.ENGLISH, "%.1f GB free of %.1f GB internal storage.", freeGb, totalGb),
            String.format(Locale.ENGLISH, "%.1f gigabytes free.", freeGb)
        )
    }

    private fun network(): ActResult {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return ActResult("No active network.")
        val caps = cm.getNetworkCapabilities(net) ?: return ActResult("Connected, but the network details are hidden.")
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "an unknown transport"
        }
        val down = caps.linkDownstreamBandwidthKbps
        return ActResult("Online on $kind. Estimated link speed ${down / 1000} Mbps.", "Online on $kind.")
    }

    private fun device(): ActResult {
        val dm = ctx.resources.displayMetrics
        return ActResult(
            "Device: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Screen: ${dm.widthPixels} x ${dm.heightPixels} at ${dm.density.toInt()} dpi\n" +
                "CPU cores: ${Runtime.getRuntime().availableProcessors()}",
            "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}."
        )
    }

    @Suppress("MissingPermission")
    private fun location(): ActResult {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION))
            return ActResult("Location permission is not granted yet.")
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
            ?: return ActResult("No location fix yet. Try again in the open.")
        val lat = "%.5f".format(Locale.ENGLISH, loc.latitude)
        val lon = "%.5f".format(Locale.ENGLISH, loc.longitude)
        launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return ActResult("You are at $lat, $lon. Opening maps.", "Opening your location on maps.")
    }

    // =============================================================== apps

    private fun openApp(name: String): ActResult {
        val pm = ctx.packageManager
        val wanted = name.lowercase(Locale.ROOT).trim()
        val alias = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "camera" to "com.android.camera",
            "gallery" to "com.google.android.apps.photos",
            "photos" to "com.google.android.apps.photos",
            "settings" to "com.android.settings",
            "clock" to "com.google.android.deskclock",
            "calculator" to "com.google.android.calculator",
            "play store" to "com.android.vending",
            "spotify" to "com.spotify.music",
            "telegram" to "org.telegram.messenger",
            "phone" to "com.google.android.dialer",
            "contacts" to "com.google.android.contacts"
        )
        alias[wanted]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launch(it)
                return ActResult("Opening ${name.replaceFirstChar { c -> c.uppercase() }}.")
            }
        }
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val label = ri.loadLabel(pm).toString()
            if (label.lowercase(Locale.ROOT).contains(wanted) ||
                ri.activityInfo.packageName.lowercase(Locale.ROOT).contains(wanted)
            ) ri else null
        }
        val best = matches.firstOrNull() ?: return ActResult("I could not find an app called \"$name\".")
        val li = pm.getLaunchIntentForPackage(best.activityInfo.packageName)
            ?: return ActResult("${best.loadLabel(pm)} has no launch screen.")
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launch(li)
        return ActResult("Opening ${best.loadLabel(pm)}.")
    }

    private fun home(): ActResult {
        launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult("Going home.")
    }

    private fun listApps(): ActResult {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.loadLabel(pm).toString() }.distinct().sorted()
        return ActResult("${apps.size} apps installed:\n" + apps.take(40).joinToString(", ") +
            if (apps.size > 40) "\n…and ${apps.size - 40} more." else "")
    }

    // ============================================================= people

    @Suppress("MissingPermission")
    private fun callContact(name: String): ActResult {
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val number = Contacts.numberFor(ctx, name)
            ?: return ActResult("I could not find \"$name\" in your contacts.")
        return call(number).let { ActResult("Calling $name ($number).", "Calling $name.") }
    }

    @Suppress("MissingPermission")
    private fun call(number: String): ActResult {
        if (!has(Manifest.permission.CALL_PHONE)) {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult("Opening the dialler for $number.", "Opening the dialler.")
        }
        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult("Calling $number.", "Calling.")
    }

    @Suppress("MissingPermission")
    private fun sms(number: String, body: String): ActResult {
        if (body.isBlank() || !has(Manifest.permission.SEND_SMS)) {
            launch(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                    if (body.isNotEmpty()) putExtra("sms_body", body)
                }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return ActResult("Opening Messages for $number.", "Opening messages.")
        }
        return try {
            val sm = if (Build.VERSION.SDK_INT >= 31)
                ctx.getSystemService(android.telephony.SmsManager::class.java)
            else
                @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
            val parts = sm.divideMessage(body)
            sm.sendMultipartTextMessage(number, null, parts, null, null)
            ActResult("Message sent to $number.", "Message sent.")
        } catch (e: Exception) {
            ActResult("The message failed: ${e.message ?: "unknown"}.")
        }
    }

    @Suppress("MissingPermission")
    private fun smsContact(name: String, body: String): ActResult {
        if (name.isBlank()) return ActResult("Who should I message? Try \"text mom saying I am late\".")
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val hits = Contacts.search(ctx, name)
        if (hits.isEmpty()) return ActResult("I could not find \"$name\" in your contacts.")
        val number = hits.first().second.replace(Regex("[^\\d+]"), "")
        val who = hits.first().first
        val result = sms(number, body)
        return if (hits.size > 1 && body.isNotBlank())
            ActResult(result.text + " (" + hits.size + " matches for \"$name\"; I used $who.)", result.speak)
        else result
    }

    private fun whatsapp(number: String, body: String): ActResult {
        val intl = if (number.length == 10) "91$number" else number
        val url = "https://wa.me/$intl" + if (body.isNotEmpty()) "?text=" + enc(body) else ""
        return try {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActResult("Opening WhatsApp for $intl.", "Opening WhatsApp.")
        } catch (e: Exception) {
            ActResult("WhatsApp is not installed.")
        }
    }

    private fun whatsappContact(name: String, body: String): ActResult {
        if (name.isBlank()) return ActResult("Who should I message on WhatsApp?")
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val number = Contacts.numberFor(ctx, name)
            ?: return ActResult("I could not find \"$name\" in your contacts.")
        return whatsapp(number, body)
    }

    @Suppress("MissingPermission")
    private fun findContact(name: String): ActResult {
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to search for \"$name\".")
        val hits = Contacts.search(ctx, name)
        if (hits.isEmpty()) return ActResult("No contact matches \"$name\".")
        return ActResult(
            hits.take(5).joinToString("\n") { "${it.first}: ${it.second}" },
            "Found ${hits.size} matches."
        )
    }

    private fun readNotifications(): ActResult {
        val list = `in`.yantra.assistant.service.NotificationListener.cache
        if (list.isEmpty()) return ActResult(
            "No notifications captured. Grant notification access in Settings, then notifications will start appearing here."
        )
        return ActResult(
            list.take(6).joinToString("\n") { "• ${it.title}: ${it.text}" },
            "You have ${list.size} recent notifications."
        )
    }

    // ============================================================= alarms

    private fun setAlarm(hour: Int, minute: Int): ActResult {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = `in`.yantra.assistant.service.AlarmReceiver.pending(ctx, cal.timeInMillis)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, pi), pi)
        } catch (e: SecurityException) {
            return ActResult("Android refused to set the alarm.")
        }
        val label = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(cal.time)
        `in`.yantra.assistant.service.AlarmReceiver.register(cal.timeInMillis, label)
        return ActResult("Alarm set for $label.", "Alarm set for $label.")
    }

    private fun alarmCancel(): ActResult {
        val list = `in`.yantra.assistant.service.AlarmReceiver.active
        if (list.isEmpty()) return ActResult("No alarms or reminders are set by this app.")
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val n = list.size
        for (at in list.keys.toList()) am.cancel(`in`.yantra.assistant.service.AlarmReceiver.pending(ctx, at))
        list.clear()
        return ActResult(if (n == 1) "Cancelled 1 alarm or reminder." else "Cancelled $n alarms and reminders.")
    }

    private fun remind(text: String, at: Long): ActResult {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = `in`.yantra.assistant.service.AlarmReceiver.pending(ctx, at, text)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, pi), pi)
        } catch (e: SecurityException) {
            return ActResult("Android refused to set the reminder.")
        }
        val whenText = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date(at)) + dayLabel(at)
        `in`.yantra.assistant.service.AlarmReceiver.register(at, "$text ($whenText)")
        return ActResult("Reminder set for $whenText: $text.", "Okay, I will remind you: $text.")
    }

    /** "", " tomorrow", or " on 14 Nov", relative to today. */
    private fun dayLabel(at: Long): String {
        val a = Calendar.getInstance().apply { timeInMillis = at }
        val n = Calendar.getInstance()
        val days = (a.get(Calendar.YEAR) - n.get(Calendar.YEAR)) * 366 +
            (a.get(Calendar.DAY_OF_YEAR) - n.get(Calendar.DAY_OF_YEAR))
        return when {
            days <= 0 -> ""
            days == 1 -> " tomorrow"
            else -> " on " + SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(at))
        }
    }

    private fun alarmList(): ActResult {
        val list = `in`.yantra.assistant.service.AlarmReceiver.active
        if (list.isEmpty()) return ActResult("No alarms are set by this app.")
        return ActResult("Alarms:\n" + list.entries.joinToString("\n") { "• ${it.value}" })
    }

    // =========================================================== calendar

    @Suppress("MissingPermission")
    private fun calendarAdd(title: String, startAt: Long): ActResult {
        if (!has(Manifest.permission.WRITE_CALENDAR))
            return ActResult("I need calendar permission to add that event.")
        return try {
            val values = android.content.ContentValues().apply {
                put(android.provider.CalendarContract.Events.TITLE, title)
                put(android.provider.CalendarContract.Events.DTSTART, startAt)
                put(android.provider.CalendarContract.Events.DTEND, startAt + 3_600_000)
                put(android.provider.CalendarContract.Events.CALENDAR_ID, CalTools.writeCalendarId(ctx))
                put(android.provider.CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            }
            ctx.contentResolver.insert(android.provider.CalendarContract.Events.CONTENT_URI, values)
            val when0 = SimpleDateFormat("EEE d MMM, h:mm a", Locale.ENGLISH).format(Date(startAt))
            ActResult("Added \"$title\" on $when0.", "Event added.")
        } catch (e: Exception) {
            ActResult("The calendar insert failed: ${e.message ?: "unknown"}.")
        }
    }

    @Suppress("MissingPermission")
    private fun agenda(): ActResult {
        if (!has(Manifest.permission.READ_CALENDAR))
            return ActResult("I need calendar permission to read your schedule.")
        return try {
            val events = CalTools.today(ctx)
            if (events.isEmpty()) ActResult("Nothing on your calendar today.")
            else ActResult("Today:\n" + events.joinToString("\n") { "• $it" }, "You have ${events.size} events today.")
        } catch (e: Exception) {
            ActResult("I could not read the calendar: ${e.message ?: "unknown"}.")
        }
    }

    // ============================================================= misc

    private fun worldTime(place: String): ActResult {
        val zones = mapOf(
            "london" to "Europe/London", "tokyo" to "Asia/Tokyo", "dubai" to "Asia/Dubai",
            "new york" to "America/New_York", "singapore" to "Asia/Singapore",
            "sydney" to "Australia/Sydney", "paris" to "Europe/Paris",
            "beijing" to "Asia/Shanghai", "moscow" to "Europe/Moscow"
        )
        val zone = zones[place] ?: return ActResult("I only carry time zones for a few major cities.")
        val fmt = SimpleDateFormat("h:mm a", Locale.ENGLISH).apply {
            timeZone = java.util.TimeZone.getTimeZone(zone)
        }
        return ActResult("It is ${fmt.format(Date())} in ${place.replaceFirstChar { it.uppercase() }}.")
    }

    private fun countdown(what: String): ActResult {
        val cal = Calendar.getInstance()
        val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
        val m = Regex("(\\d{1,2})\\s+([a-z]{3})").find(what)
        if (m != null) {
            val day = m.groupValues[1].toInt()
            val mon = months.indexOf(m.groupValues[2])
            if (mon >= 0) {
                val target = Calendar.getInstance().apply {
                    set(Calendar.MONTH, mon); set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                    if (timeInMillis < System.currentTimeMillis()) add(Calendar.YEAR, 1)
                }
                val days = ((target.timeInMillis - cal.timeInMillis) / 86_400_000L).toInt()
                return ActResult("$days days until $what.")
            }
        }
        return ActResult("I could not read that date.")
    }

    private fun takePhoto(): ActResult = try {
        val dir = java.io.File(ctx.cacheDir, "photos").apply { mkdirs() }
        val file = java.io.File(dir, "photo-" + System.currentTimeMillis() + ".jpg")
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx, ctx.packageName + ".fileprovider", file
        )
        val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launch(i)
        ActResult("Camera open. The photo saves to ${file.name}.", "Camera open.")
    } catch (e: Exception) {
        ActResult("The camera did not open: ${e.message ?: "unknown"}.")
    }

    // ------------------------------------------------------------ media keys

    private fun media(cmd: String): ActResult {
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return ActResult("I do not know that media command.")
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActResult(
            when (cmd) {
                "play" -> "Sent play. If nothing starts, open your music app first."
                "pause" -> "Paused."
                "next" -> "Next track."
                "previous" -> "Previous track."
                else -> "Stopped."
            },
            when (cmd) {
                "play" -> "Playing."
                "pause" -> "Paused."
                "next" -> "Next."
                "previous" -> "Previous."
                else -> "Stopped."
            }
        )
    }

    private fun playQuery(query: String, service: String): ActResult =
        if (service == "spotify")
            web("https://open.spotify.com/search/" + enc(query), "Searching Spotify for \"$query\"")
        else
            web("https://www.youtube.com/results?search_query=" + enc(query), "Searching YouTube for \"$query\"")

    private fun ringer(mode: String): ActResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            when (mode) {
                "silent" -> {
                    if (!nm.isNotificationPolicyAccessGranted) {
                        launch(
                            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        return ActResult(
                            "Silent mode needs Do Not Disturb access. Allow Yantra there, then ask again.",
                            "I need Do Not Disturb access for silent mode."
                        )
                    }
                    am.ringerMode = AudioManager.RINGER_MODE_SILENT
                    ActResult("Silent mode on.")
                }
                "vibrate" -> {
                    am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    ActResult("Vibrate mode on.")
                }
                else -> {
                    am.ringerMode = AudioManager.RINGER_MODE_NORMAL
                    ActResult("Ringer is back on.")
                }
            }
        } catch (e: SecurityException) {
            ActResult("Android blocked the ringer change.")
        }
    }

    // ----------------------------------------------------- system settings

    /** Null when we may write system settings, otherwise the reply that sends the person to grant it. */
    private fun askWriteSettings(what: String): ActResult? {
        if (Settings.System.canWrite(ctx)) return null
        launch(
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                .setData(Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return ActResult(
            "I need the \"modify system settings\" permission to change $what. Allow it, then ask again.",
            "I need permission to change $what."
        )
    }

    private fun autoBrightness(on: Boolean): ActResult {
        askWriteSettings("brightness")?.let { return it }
        Settings.System.putInt(
            ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
            if (on) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        return ActResult(if (on) "Auto-brightness on." else "Auto-brightness off.")
    }

    private fun rotate(on: Boolean): ActResult {
        askWriteSettings("screen rotation")?.let { return it }
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
        return ActResult(if (on) "Auto-rotate on." else "Rotation locked.")
    }

    private fun screenTimeout(ms: Long): ActResult {
        askWriteSettings("the screen timeout")?.let { return it }
        val clamped = ms.coerceIn(15_000L, 30 * 60_000L)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, clamped.toInt())
        val secs = clamped / 1000
        val said = if (secs < 60) "$secs seconds" else if (secs == 60L) "1 minute" else "${secs / 60} minutes"
        return ActResult("Screen timeout set to $said.")
    }

    private fun settingsPage(key: String, toggle: String): ActResult {
        val k = key.trim().lowercase(Locale.ROOT)
        val action = when (k) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
            "data usage" -> "android.settings.DATA_USAGE_SETTINGS"
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "date and time" -> Settings.ACTION_DATE_SETTINGS
            "keyboard" -> Settings.ACTION_INPUT_METHOD_SETTINGS
            "vpn" -> Settings.ACTION_VPN_SETTINGS
            "cast" -> Settings.ACTION_CAST_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "privacy" -> Settings.ACTION_PRIVACY_SETTINGS
            "developer" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "about phone" -> Settings.ACTION_DEVICE_INFO_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val said = if (toggle.isNotEmpty())
            "Android does not let apps switch $k $toggle silently. Here is the page."
        else
            "Opening $k settings."
        return panel(Intent(action), said)
    }

    // ---------------------------------------------------------- app actions

    /** The launcher app whose name best matches [name]: exact first, then "contains". */
    private fun resolveApp(name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val wanted = name.lowercase(Locale.ROOT).trim()
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT) == wanted }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(wanted) }
            ?: return null
        return hit.activityInfo.packageName to hit.loadLabel(pm).toString()
    }

    private fun uninstall(name: String): ActResult {
        val (pkg, label) = resolveApp(name) ?: return ActResult("I could not find an app called \"$name\".")
        if (pkg == ctx.packageName) return ActResult("I will not uninstall myself.")
        launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult("Android will ask you to confirm removing $label.")
    }

    private fun appInfo(name: String): ActResult {
        val (pkg, label) = resolveApp(name) ?: return ActResult("I could not find an app called \"$name\".")
        launch(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return ActResult("Here is the info page for $label.")
    }

    private fun clearNotifications(): ActResult {
        val listener = `in`.yantra.assistant.service.NotificationListener.instance
        if (listener == null) {
            launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult("I need notification access to clear them. Allow it, then ask again.")
        }
        listener.cancelAllNotifications()
        synchronized(`in`.yantra.assistant.service.NotificationListener.cache) {
            `in`.yantra.assistant.service.NotificationListener.cache.clear()
        }
        return ActResult("Notifications cleared.")
    }

    private fun email(address: String, body: String): ActResult {
        val uri = Uri.parse("mailto:" + if (address.isNotEmpty()) Uri.encode(address, "@") else "")
        val intent = Intent(Intent.ACTION_SENDTO, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (body.isNotEmpty()) intent.putExtra(Intent.EXTRA_TEXT, body)
        launch(intent)
        return ActResult(
            if (address.isNotEmpty()) "Draft to $address is ready."
            else "Email draft open. Add the recipient."
        )
    }

    private fun translate(text: String, language: String): ActResult {
        val codes = mapOf(
            "hindi" to "hi", "english" to "en", "spanish" to "es", "french" to "fr", "german" to "de",
            "tamil" to "ta", "telugu" to "te", "marathi" to "mr", "bengali" to "bn", "gujarati" to "gu",
            "kannada" to "kn", "malayalam" to "ml", "punjabi" to "pa", "urdu" to "ur",
            "japanese" to "ja", "chinese" to "zh-CN", "arabic" to "ar", "russian" to "ru",
            "portuguese" to "pt", "italian" to "it", "korean" to "ko"
        )
        val code = codes[language.lowercase(Locale.ROOT)]
            ?: return ActResult("I do not know the language \"$language\".")
        return web(
            "https://translate.google.com/?sl=auto&tl=$code&text=${enc(text)}&op=translate",
            "Translating to ${language.replaceFirstChar { it.uppercase() }}"
        )
    }

    private fun web(url: String, note: String): ActResult {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult(note + ".")
    }

    private fun panel(intent: Intent, message: String): ActResult {
        launch(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult(message)
    }

    private fun launch(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { /* nothing to launch */ }
    }

    private fun enc(s: String): String = Uri.encode(s)

    companion object {
        /** BluetoothAdapter.ACTION_REQUEST_DISABLE is not exposed by every SDK
         *  level, so carry the documented action strings ourselves. */
        private const val BT_REQUEST_ENABLE = "android.bluetooth.adapter.action.REQUEST_ENABLE"
        private const val BT_REQUEST_DISABLE = "android.bluetooth.adapter.action.REQUEST_DISABLE"

        val HELP = """
            I am a native Android assistant — real system APIs plus a small on-device brain, no language model.

            CHAT AND SHORTCUTS
            • tell me a joke / a fun fact / motivate me
            • what is the capital of france
            • when I say movie time, open netflix (teach me a shortcut)
            • what have I taught you / forget all shortcuts
            • say "its dark in here" and I will offer the flashlight

            SYSTEM
            • turn on/off wi-fi, bluetooth, mobile data, aeroplane mode
            • brightness 50% / increase brightness by 20% / make it a bit dimmer
            • volume 30% / turn it up / mute / unmute
            • silent mode, vibrate mode, ring mode
            • auto-rotate on/off, auto-brightness on/off
            • screen timeout 2 minutes
            • turn on the flashlight, do not disturb, dark mode
            • open wifi settings (also display, sound, battery, location,
              nfc, hotspot, vpn, storage, apps, accessibility, language)

            MEDIA
            • pause, play, next song, previous song, stop the music
            • play despacito (opens YouTube), play lofi on spotify

            MY VOICE
            • change your voice (cycles through the installed ones)
            • install a voice (opens Android's voice downloads)
            • what voices do you have, speak deeper, speak slowly

            DEVICE
            • battery, storage, network status, device information
            • what's my current location

            APPS
            • open youtube / open whatsapp / open camera / open settings
            • go to bbc.com
            • uninstall twitter, app info for chrome
            • go home, list my apps, clear my notifications

            PEOPLE
            • call mom, call 9876543210
            • text 9876543210 saying I am late
            • whatsapp mom saying I am late
            • find mom's contact, read my notifications
            • email priya@example.com saying running late

            TIME
            • set an alarm for 6:30 am, cancel my alarms
            • set a timer for 10 minutes
            • remind me to call mom at 5 pm / tomorrow morning
            • remind me in an hour to stretch
            • what time is it, what's the date, what day is it tomorrow
            • what day will it be in 10 days
            • what time is it in London

            WORK
            • add event dentist tomorrow at 5pm
            • what's on my calendar
            • note that I parked on level 2
            • add milk to shopping / show my shopping

            QUICK
            • 15% of 2400, 12 * 34, 2 to the power of 10, square root of 729
            • tip on 840 at 15%, split 1200 between 4, 20% off 1500
            • 5 km to miles, 100 f to c
            • copy hello world, read my clipboard
            • translate good morning to hindi, define serendipity
            • flip a coin, roll a dice, pick a number between 1 and 50
            • pick pizza or pasta, tell me a joke
            • weather in Pune, will it rain
            • search for train timings, navigate to Pune airport
            • take a photo, record a video
            • a bit more / again / turn it up (follows what you last changed)
            • you can chain: turn on wifi and bluetooth, then open maps
            • call me Vidya, use metric units
        """.trimIndent()
    }
}
