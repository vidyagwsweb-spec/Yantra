package `in`.yantra.assistant.actions

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.core.content.ContextCompat
import `in`.yantra.assistant.router.Parsed
import `in`.yantra.assistant.util.Prefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ActResult(
    val text: String,
    val speak: String = text
)

/**
 * Every action here is a real Android API call. Nothing is faked — where the
 * platform forbids a silent change (Wi-Fi, aeroplane mode, battery saver) the
 * app opens the system panel instead and says so.
 */
class ActionExecutor(private val ctx: Context) {

    private val prefs = Prefs(ctx)

    private fun has(perm: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    suspend fun run(p: Parsed): ActResult = when (p.action) {
        "say" -> ActResult(p.say)
        "stop" -> ActResult("Stopped.")
        "empty" -> ActResult("")
        "unknown" -> ActResult(
            "I did not catch a command in that. Say \"help\" to hear what I can do."
        )
        "help" -> ActResult(HELP)

        // ---------------------------------------------------------- system
        "wifi" -> wifi(p.on)
        "bluetooth" -> bluetooth(p.on)
        "airplane" -> panel(
            Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS),
            "Aeroplane mode is a protected system switch. Here is the panel."
        )
        "mobile-data" -> panel(
            Intent(
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                else Settings.ACTION_DATA_ROAMING_SETTINGS
            ),
            "Mobile data is a protected system switch. Here is the panel."
        )
        "battery-saver" -> panel(
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            "Battery saver cannot be toggled by an app on this version. Here is the panel."
        )
        "brightness" -> brightness(p.pct)
        "brightness-delta" -> brightness(currentBrightness() + p.num.toInt())
        "volume" -> volume(p.pct)
        "volume-delta" -> volume(currentVolumePercent() + p.num.toInt())
        "flashlight" -> flashlight(p.on)
        "dnd" -> dnd(p.on)
        "dark-mode" -> darkMode(p.on)
        "battery" -> battery()
        "storage" -> storage()
        "network" -> network()
        "device" -> device()
        "location" -> location()

        // ------------------------------------------------------------ apps
        "open-app" -> openApp(p.a)
        "home" -> home()
        "list-apps" -> listApps()

        // ---------------------------------------------------------- people
        "call" -> call(p.a)
        "call-contact" -> callContact(p.a)
        "sms" -> sms(p.a, p.b)
        "sms-contact" -> smsContact(p.a, p.b)
        "whatsapp" -> whatsapp(p.a, p.b)
        "whatsapp-contact" -> whatsappContact(p.a, p.b)
        "find-contact" -> findContact(p.a)
        "read-notifications" -> readNotifications()

        // ---------------------------------------------------------- alarms
        "alarm" -> setAlarm(p.num.toInt(), p.pct)
        "alarm-list" -> alarmList()

        // -------------------------------------------------------- calendar
        "calendar-add" -> calendarAdd(p.a, p.at)
        "agenda" -> agenda()

        // ----------------------------------------------------------- lists
        "list-add" -> {
            val items = prefs.addToList(p.a, p.b)
            ActResult("Added \"${p.b}\" to ${p.a}. ${items.size} item(s) in there.", "Added.")
        }
        "list-show" -> {
            val items = prefs.list(p.a)
            if (items.isEmpty()) ActResult("Your ${p.a} is empty.")
            else ActResult(
                "Your ${p.a}:\n" + items.mapIndexed { i, v -> "${i + 1}. $v" }.joinToString("\n"),
                "You have ${items.size} items in your ${p.a}."
            )
        }
        "list-remove" -> {
            val items = prefs.removeFromList(p.a, p.b)
            ActResult("Removed \"${p.b}\" from ${p.a}. ${items.size} left.")
        }
        "list-clear" -> {
            val n = prefs.clearList(p.a)
            ActResult(if (n > 0) "Cleared $n item(s) from ${p.a}." else "${p.a} was already empty.")
        }

        // ---------------------------------------------------------- search
        "search" -> web("https://www.google.com/search?q=" + enc(p.a), "Searching for \"${p.a}\"")
        "navigate" -> web(
            "https://www.google.com/maps/dir/?api=1&destination=" + enc(p.a),
            "Directions to ${p.a}"
        )
        "nearby" -> web(
            "https://www.google.com/maps/search/?api=1&query=" + enc(p.a + " near me"),
            "Looking for ${p.a} nearby"
        )
        "weather" -> Weather.fetch(ctx, p.a, p.b)
        "world-time" -> worldTime(p.a)
        "countdown" -> countdown(p.a)

        // ---------------------------------------------------------- camera
        "camera" -> takePhoto()

        else -> ActResult("That command is wired in the parser but not the executor yet.")
    }

    // ================================================================= system

    private fun wifi(on: Boolean): ActResult {
        if (Build.VERSION.SDK_INT >= 29) {
            launch(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult(
                "Android 10 and later do not let apps flip Wi-Fi silently, so here is the panel.",
                "Opening the Wi-Fi panel."
            )
        }
        @Suppress("DEPRECATION")
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        @Suppress("DEPRECATION")
        val ok = wm.setWifiEnabled(on)
        return ActResult(if (ok) "Wi-Fi ${if (on) "on" else "off"}." else "Android refused the Wi-Fi change.")
    }

    private fun bluetooth(on: Boolean): ActResult {
        if (!has(Manifest.permission.BLUETOOTH_CONNECT) && Build.VERSION.SDK_INT >= 31)
            return ActResult("I need the nearby-devices permission for Bluetooth. Grant it in app settings.")
        val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager
        val adapter = mgr.adapter ?: return ActResult("This device has no Bluetooth adapter.")
        @Suppress("DEPRECATION")
        if (adapter.isEnabled == on) return ActResult("Bluetooth is already ${if (on) "on" else "off"}.")
        return try {
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT < 33) {
                @Suppress("DEPRECATION")
                if (on) adapter.enable() else adapter.disable()
                val nowOn = adapter.isEnabled
                if (nowOn == on) ActResult("Bluetooth ${if (on) "on" else "off"}.")
                else {
                    val action = if (on) BT_REQUEST_ENABLE else BT_REQUEST_DISABLE
                    launch(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    ActResult("Confirm the Bluetooth prompt.")
                }
            } else {
                val action = if (on) BT_REQUEST_ENABLE else BT_REQUEST_DISABLE
                launch(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                ActResult("Confirm the Bluetooth prompt.")
            }
        } catch (e: SecurityException) {
            ActResult("Android blocked the Bluetooth change without the nearby-devices permission.")
        }
    }

    private fun brightness(percent: Int): ActResult {
        if (!Settings.System.canWrite(ctx)) {
            launch(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return ActResult(
                "I need the \"modify system settings\" permission for brightness. Grant it and ask again.",
                "I need permission to change brightness."
            )
        }
        val p = percent.coerceIn(1, 100)
        val raw = (p / 100.0 * 255).toInt().coerceIn(1, 255)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, raw)
        return ActResult(
            "Brightness set to $p%.",
            "Brightness $p percent."
        )
    }

    private fun currentBrightness(): Int {
        val raw = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) { 128 }
        return (raw / 255.0 * 100).toInt()
    }

    private fun currentVolumePercent(): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / max
    }

    private fun volume(percent: Int): ActResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = percent.coerceIn(0, 100)
        val idx = Math.round(p / 100.0 * max).toInt().coerceIn(0, max)
        return try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
            ActResult(
                if (p == 0) "Muted."
                else "Volume set to $p%.",
                if (p == 0) "Muted." else "Volume $p percent."
            )
        } catch (e: SecurityException) {
            ActResult("Android blocked the volume change.")
        }
    }

    private fun flashlight(on: Boolean): ActResult {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { camId ->
            cm.getCameraCharacteristics(camId).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActResult("This phone has no camera flash.")
        return try {
            cm.setTorchMode(id, on)
            ActResult(
                if (on) "Flashlight on."
                else "Flashlight off."
            )
        } catch (e: Exception) {
            ActResult("I could not reach the flash: ${e.message ?: "unknown error"}.")
        }
    }

    private fun dnd(on: Boolean): ActResult {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult(
                "Do Not Disturb needs the policy-access permission. Grant it on the screen I just opened.",
                "I need do not disturb access."
            )
        }
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return ActResult(
            if (on) "Do Not Disturb on."
            else "Do Not Disturb off."
        )
    }

    private fun darkMode(on: Boolean): ActResult {
        return if (Build.VERSION.SDK_INT >= 31) {
            val um = ctx.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
            um.setApplicationNightMode(if (on) UiModeManager.MODE_NIGHT_YES else UiModeManager.MODE_NIGHT_NO)
            ActResult("Dark mode ${if (on) "on" else "off"} for this app.", "Dark mode ${if (on) "on" else "off"}.")
        } else {
            ActResult("System-wide dark mode needs Android 12 or later. This app follows the system theme.")
        }
    }

    private fun battery(): ActResult {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return ActResult(
            "Battery at $level%" + if (charging) ", charging." else ".",
            "Battery at $level percent."
        )
    }

    private fun storage(): ActResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / 1_073_741_824.0
        val totalGb = stat.totalBytes / 1_073_741_824.0
        return ActResult(
            String.format(Locale.ENGLISH, "%.1f GB free of %.1f GB internal storage.", freeGb, totalGb),
            String.format(Locale.ENGLISH, "%.1f gigabytes free.", freeGb)
        )
    }

    private fun network(): ActResult {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return ActResult("No active network.")
        val caps = cm.getNetworkCapabilities(net) ?: return ActResult("Connected, but the network details are hidden.")
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "an unknown transport"
        }
        val down = caps.linkDownstreamBandwidthKbps
        return ActResult("Online on $kind. Estimated link speed ${down / 1000} Mbps.", "Online on $kind.")
    }

    private fun device(): ActResult {
        val dm = ctx.resources.displayMetrics
        return ActResult(
            "Device: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Screen: ${dm.widthPixels} x ${dm.heightPixels} at ${dm.density.toInt()} dpi\n" +
                "CPU cores: ${Runtime.getRuntime().availableProcessors()}",
            "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}."
        )
    }

    @Suppress("MissingPermission")
    private fun location(): ActResult {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION))
            return ActResult("Location permission is not granted yet.")
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
            ?: return ActResult("No location fix yet. Try again in the open.")
        val lat = "%.5f".format(Locale.ENGLISH, loc.latitude)
        val lon = "%.5f".format(Locale.ENGLISH, loc.longitude)
        launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return ActResult("You are at $lat, $lon. Opening maps.", "Opening your location on maps.")
    }

    // =============================================================== apps

    private fun openApp(name: String): ActResult {
        val pm = ctx.packageManager
        val wanted = name.lowercase(Locale.ROOT).trim()
        val alias = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "camera" to "com.android.camera",
            "gallery" to "com.google.android.apps.photos",
            "photos" to "com.google.android.apps.photos",
            "settings" to "com.android.settings",
            "clock" to "com.google.android.deskclock",
            "calculator" to "com.google.android.calculator",
            "play store" to "com.android.vending",
            "spotify" to "com.spotify.music",
            "telegram" to "org.telegram.messenger",
            "phone" to "com.google.android.dialer",
            "contacts" to "com.google.android.contacts"
        )
        alias[wanted]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launch(it)
                return ActResult("Opening ${name.replaceFirstChar { c -> c.uppercase() }}.")
            }
        }
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val label = ri.loadLabel(pm).toString()
            if (label.lowercase(Locale.ROOT).contains(wanted) ||
                ri.activityInfo.packageName.lowercase(Locale.ROOT).contains(wanted)
            ) ri else null
        }
        val best = matches.firstOrNull() ?: return ActResult("I could not find an app called \"$name\".")
        val li = pm.getLaunchIntentForPackage(best.activityInfo.packageName)
            ?: return ActResult("${best.loadLabel(pm)} has no launch screen.")
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launch(li)
        return ActResult("Opening ${best.loadLabel(pm)}.")
    }

    private fun home(): ActResult {
        launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult("Going home.")
    }

    private fun listApps(): ActResult {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.loadLabel(pm).toString() }.distinct().sorted()
        return ActResult("${apps.size} apps installed:\n" + apps.take(40).joinToString(", ") +
            if (apps.size > 40) "\n…and ${apps.size - 40} more." else "")
    }

    // ============================================================= people

    @Suppress("MissingPermission")
    private fun callContact(name: String): ActResult {
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val number = Contacts.numberFor(ctx, name)
            ?: return ActResult("I could not find \"$name\" in your contacts.")
        return call(number).let { ActResult("Calling $name ($number).", "Calling $name.") }
    }

    @Suppress("MissingPermission")
    private fun call(number: String): ActResult {
        if (!has(Manifest.permission.CALL_PHONE)) {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActResult("Opening the dialler for $number.", "Opening the dialler.")
        }
        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult("Calling $number.", "Calling.")
    }

    @Suppress("MissingPermission")
    private fun sms(number: String, body: String): ActResult {
        if (body.isBlank() || !has(Manifest.permission.SEND_SMS)) {
            launch(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                    if (body.isNotEmpty()) putExtra("sms_body", body)
                }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return ActResult("Opening Messages for $number.", "Opening messages.")
        }
        return try {
            val sm = if (Build.VERSION.SDK_INT >= 31)
                ctx.getSystemService(android.telephony.SmsManager::class.java)
            else
                @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
            val parts = sm.divideMessage(body)
            sm.sendMultipartTextMessage(number, null, parts, null, null)
            ActResult("Message sent to $number.", "Message sent.")
        } catch (e: Exception) {
            ActResult("The message failed: ${e.message ?: "unknown"}.")
        }
    }

    @Suppress("MissingPermission")
    private fun smsContact(name: String, body: String): ActResult {
        if (name.isBlank()) return ActResult("Who should I message? Try \"text mom saying I am late\".")
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val hits = Contacts.search(ctx, name)
        if (hits.isEmpty()) return ActResult("I could not find \"$name\" in your contacts.")
        val number = hits.first().second.replace(Regex("[^\\d+]"), "")
        val who = hits.first().first
        val result = sms(number, body)
        return if (hits.size > 1 && body.isNotBlank())
            ActResult(result.text + " (" + hits.size + " matches for \"$name\"; I used $who.)", result.speak)
        else result
    }

    private fun whatsapp(number: String, body: String): ActResult {
        val intl = if (number.length == 10) "91$number" else number
        val url = "https://wa.me/$intl" + if (body.isNotEmpty()) "?text=" + enc(body) else ""
        return try {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActResult("Opening WhatsApp for $intl.", "Opening WhatsApp.")
        } catch (e: Exception) {
            ActResult("WhatsApp is not installed.")
        }
    }

    private fun whatsappContact(name: String, body: String): ActResult {
        if (name.isBlank()) return ActResult("Who should I message on WhatsApp?")
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to look up \"$name\".")
        val number = Contacts.numberFor(ctx, name)
            ?: return ActResult("I could not find \"$name\" in your contacts.")
        return whatsapp(number, body)
    }

    @Suppress("MissingPermission")
    private fun findContact(name: String): ActResult {
        if (!has(Manifest.permission.READ_CONTACTS))
            return ActResult("I need contacts permission to search for \"$name\".")
        val hits = Contacts.search(ctx, name)
        if (hits.isEmpty()) return ActResult("No contact matches \"$name\".")
        return ActResult(
            hits.take(5).joinToString("\n") { "${it.first}: ${it.second}" },
            "Found ${hits.size} matches."
        )
    }

    private fun readNotifications(): ActResult {
        val list = `in`.yantra.assistant.service.NotificationListener.cache
        if (list.isEmpty()) return ActResult(
            "No notifications captured. Grant notification access in Settings, then notifications will start appearing here."
        )
        return ActResult(
            list.take(6).joinToString("\n") { "• ${it.title}: ${it.text}" },
            "You have ${list.size} recent notifications."
        )
    }

    // ============================================================= alarms

    private fun setAlarm(hour: Int, minute: Int): ActResult {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = `in`.yantra.assistant.service.AlarmReceiver.pending(ctx, cal.timeInMillis)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, pi), pi)
        } catch (e: SecurityException) {
            return ActResult("Android refused to set the alarm.")
        }
        val label = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(cal.time)
        `in`.yantra.assistant.service.AlarmReceiver.register(cal.timeInMillis, label)
        return ActResult("Alarm set for $label.", "Alarm set for $label.")
    }

    private fun alarmList(): ActResult {
        val list = `in`.yantra.assistant.service.AlarmReceiver.active
        if (list.isEmpty()) return ActResult("No alarms are set by this app.")
        return ActResult("Alarms:\n" + list.entries.joinToString("\n") { "• ${it.value}" })
    }

    // =========================================================== calendar

    @Suppress("MissingPermission")
    private fun calendarAdd(title: String, startAt: Long): ActResult {
        if (!has(Manifest.permission.WRITE_CALENDAR))
            return ActResult("I need calendar permission to add that event.")
        return try {
            val values = android.content.ContentValues().apply {
                put(android.provider.CalendarContract.Events.TITLE, title)
                put(android.provider.CalendarContract.Events.DTSTART, startAt)
                put(android.provider.CalendarContract.Events.DTEND, startAt + 3_600_000)
                put(android.provider.CalendarContract.Events.CALENDAR_ID, CalTools.writeCalendarId(ctx))
                put(android.provider.CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            }
            ctx.contentResolver.insert(android.provider.CalendarContract.Events.CONTENT_URI, values)
            val when0 = SimpleDateFormat("EEE d MMM, h:mm a", Locale.ENGLISH).format(Date(startAt))
            ActResult("Added \"$title\" on $when0.", "Event added.")
        } catch (e: Exception) {
            ActResult("The calendar insert failed: ${e.message ?: "unknown"}.")
        }
    }

    @Suppress("MissingPermission")
    private fun agenda(): ActResult {
        if (!has(Manifest.permission.READ_CALENDAR))
            return ActResult("I need calendar permission to read your schedule.")
        return try {
            val events = CalTools.today(ctx)
            if (events.isEmpty()) ActResult("Nothing on your calendar today.")
            else ActResult("Today:\n" + events.joinToString("\n") { "• $it" }, "You have ${events.size} events today.")
        } catch (e: Exception) {
            ActResult("I could not read the calendar: ${e.message ?: "unknown"}.")
        }
    }

    // ============================================================= misc

    private fun worldTime(place: String): ActResult {
        val zones = mapOf(
            "london" to "Europe/London", "tokyo" to "Asia/Tokyo", "dubai" to "Asia/Dubai",
            "new york" to "America/New_York", "singapore" to "Asia/Singapore",
            "sydney" to "Australia/Sydney", "paris" to "Europe/Paris",
            "beijing" to "Asia/Shanghai", "moscow" to "Europe/Moscow"
        )
        val zone = zones[place] ?: return ActResult("I only carry time zones for a few major cities.")
        val fmt = SimpleDateFormat("h:mm a", Locale.ENGLISH).apply {
            timeZone = java.util.TimeZone.getTimeZone(zone)
        }
        return ActResult("It is ${fmt.format(Date())} in ${place.replaceFirstChar { it.uppercase() }}.")
    }

    private fun countdown(what: String): ActResult {
        val cal = Calendar.getInstance()
        val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
        val m = Regex("(\\d{1,2})\\s+([a-z]{3})").find(what)
        if (m != null) {
            val day = m.groupValues[1].toInt()
            val mon = months.indexOf(m.groupValues[2])
            if (mon >= 0) {
                val target = Calendar.getInstance().apply {
                    set(Calendar.MONTH, mon); set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                    if (timeInMillis < System.currentTimeMillis()) add(Calendar.YEAR, 1)
                }
                val days = ((target.timeInMillis - cal.timeInMillis) / 86_400_000L).toInt()
                return ActResult("$days days until $what.")
            }
        }
        return ActResult("I could not read that date.")
    }

    private fun takePhoto(): ActResult = try {
        val dir = java.io.File(ctx.cacheDir, "photos").apply { mkdirs() }
        val file = java.io.File(dir, "photo-" + System.currentTimeMillis() + ".jpg")
        val uri = androidx.core.content.FileProvider.getUriForFile(
            ctx, ctx.packageName + ".fileprovider", file
        )
        val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launch(i)
        ActResult("Camera open. The photo saves to ${file.name}.", "Camera open.")
    } catch (e: Exception) {
        ActResult("The camera did not open: ${e.message ?: "unknown"}.")
    }

    private fun web(url: String, note: String): ActResult {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult(note + ".")
    }

    private fun panel(intent: Intent, message: String): ActResult {
        launch(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActResult(message)
    }

    private fun launch(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { /* nothing to launch */ }
    }

    private fun enc(s: String): String = Uri.encode(s)

    companion object {
        /** BluetoothAdapter.ACTION_REQUEST_DISABLE is not exposed by every SDK
         *  level, so carry the documented action strings ourselves. */
        private const val BT_REQUEST_ENABLE = "android.bluetooth.adapter.action.REQUEST_ENABLE"
        private const val BT_REQUEST_DISABLE = "android.bluetooth.adapter.action.REQUEST_DISABLE"

        val HELP = """
            I am a native Android assistant — real system APIs, no language model.

            SYSTEM
            • turn on/off wi-fi, bluetooth, mobile data, aeroplane mode
            • brightness 50% / increase brightness / max brightness
            • volume 30% / mute / unmute
            • turn on the flashlight
            • turn on do not disturb
            • turn on dark mode

            DEVICE
            • battery, storage, network status, device information
            • what's my current location

            APPS
            • open youtube / open whatsapp / open camera / open settings
            • go home, list my apps

            PEOPLE
            • call mom, call 9876543210
            • text 9876543210 saying I am late
            • whatsapp mom saying I am late
            • find mom's contact, read my notifications

            TIME
            • set an alarm for 6:30 am
            • set a timer for 10 minutes
            • what time is it, what's the date
            • what time is it in London

            WORK
            • add event dentist tomorrow at 5pm
            • what's on my calendar
            • note that I parked on level 2
            • add milk to shopping / show my shopping

            QUICK
            • 15% of 2400, 12 * 34, square root of 729
            • 5 km to miles, 100 f to c
            • weather in Pune, will it rain
            • search for train timings, navigate to Pune airport
            • take a photo
            • call me Vidya, use metric units
        """.trimIndent()
    }
}
