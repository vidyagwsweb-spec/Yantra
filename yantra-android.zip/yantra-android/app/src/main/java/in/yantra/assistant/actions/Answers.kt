package `in`.yantra.assistant.actions

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Answers a question in place instead of opening a browser.
 *
 * Three free sources, no keys, no account:
 *   Wikipedia   the intro of the best matching article
 *   Wikidata    who currently holds an office ("who is the prime minister of india")
 *   a free dictionary API for "define ..." and "meaning of ..."
 *
 * Every path returns null rather than guessing. The caller then falls back to
 * Google, so the worst case is the old behaviour.
 */
object Answers {

    private const val UA = "Yantra/1.0 (personal Android assistant)"

    suspend fun lookup(query: String): ActResult? = withContext(Dispatchers.IO) {
        val plan = AnswerText.plan(query) ?: return@withContext null
        try {
            when (plan.kind) {
                AnswerText.Kind.DEFINE -> define(plan.topic) ?: wikipedia(plan)
                AnswerText.Kind.TOPIC -> wikipedia(plan)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ Wikipedia

    private fun wikipedia(plan: AnswerText.Plan): ActResult? {
        val url = "https://en.wikipedia.org/w/api.php?action=query&format=json&formatversion=2" +
            "&redirects=1&generator=search&gsrsearch=" + Uri.encode(plan.topic) +
            "&gsrlimit=4&gsrnamespace=0&prop=extracts%7Cpageprops&exintro=1&explaintext=1" +
            "&exsentences=5&exlimit=4&ppprop=disambiguation%7Cwikibase_item"
        val body = http(url) ?: return null
        val pages = JSONObject(body).optJSONObject("query")?.optJSONArray("pages") ?: return null

        val found = ArrayList<JSONObject>()
        for (i in 0 until pages.length()) pages.optJSONObject(i)?.let { found.add(it) }
        found.sortBy { it.optInt("index", 99) }

        for (page in found) {
            val title = page.optString("title")
            val extract = page.optString("extract")
            if (extract.isBlank()) continue
            if (page.optJSONObject("pageprops")?.has("disambiguation") == true) continue
            if (title.startsWith("List of") && !plan.topic.startsWith("list")) continue
            if (!AnswerText.accepts(plan.topic, title, plan.strict)) continue

            val link = "https://en.wikipedia.org/wiki/" + Uri.encode(title.replace(' ', '_'))

            if (plan.where) {
                val item = page.optJSONObject("pageprops")?.optString("wikibase_item").orEmpty()
                val place = if (item.isNotEmpty()) placeOf(item, title) else null
                val line = place ?: AnswerText.whereSentence(extract)?.let { AnswerText.tidy(it) }
                // a "where" must be answered with a place; the "what is it" intro would be the wrong answer
                if (line != null) return ActResult(line, AnswerText.speakable(line), link, "Wikipedia")
                continue
            }

            if (plan.role) {
                val item = page.optJSONObject("pageprops")?.optString("wikibase_item").orEmpty()
                val holder = if (item.isNotEmpty()) officeholder(item) else null
                if (holder != null) {
                    val line = "$holder is the $title."
                    return ActResult(line, line, link, "Wikipedia")
                }
            }

            val text = AnswerText.tidy(extract)
            if (text.isEmpty()) continue
            // speak from the untrimmed text so a long first sentence is read to the end
            return ActResult(text, AnswerText.speakable(AnswerText.strip(extract)), link, "Wikipedia")
        }
        return null
    }

    // ------------------------------------------------------------- Wikidata

    /** Where something is, from Wikidata: headquarters, else location, else the region it sits in. */
    private fun placeOf(item: String, title: String): String? {
        for ((prop, verb) in listOf("P159" to "is headquartered in", "P276" to "is in", "P131" to "is in")) {
            val ids = liveClaimIds(item, prop)
            if (ids.size != 1) continue
            val place = label(ids[0]) ?: continue
            // add the country when the place has exactly one, e.g. "New York City, United States"
            val country = liveClaimIds(ids[0], "P17").singleOrNull()?.let { label(it) }
            val where = if (country != null && country != place) "$place, $country" else place
            return "$title $verb $where."
        }
        return null
    }

    /** The one person who holds this office now, or null when the data is not clear-cut. */
    private fun officeholder(item: String): String? {
        val pick = liveClaimIds(item, "P1308")
        // two candidates means the data is ambiguous: better to say less than to name the wrong person
        if (pick.size != 1) return null
        return label(pick[0])
    }

    /** Item ids of a property's current values: not deprecated, no end time; preferred ones win. */
    private fun liveClaimIds(item: String, property: String): List<String> {
        val body = http(
            "https://www.wikidata.org/w/api.php?action=wbgetclaims&format=json&entity=" +
                Uri.encode(item) + "&property=" + property
        ) ?: return emptyList()
        val claims = JSONObject(body).optJSONObject("claims")?.optJSONArray(property) ?: return emptyList()

        val live = ArrayList<Pair<String, String>>()
        for (i in 0 until claims.length()) {
            val c = claims.optJSONObject(i) ?: continue
            val rank = c.optString("rank")
            if (rank == "deprecated") continue
            // a statement with an end time is a former holder
            if (c.optJSONObject("qualifiers")?.has("P582") == true) continue
            val main = c.optJSONObject("mainsnak") ?: continue
            if (main.optString("snaktype") != "value") continue
            val id = main.optJSONObject("datavalue")?.optJSONObject("value")?.optString("id").orEmpty()
            if (id.isNotEmpty()) live.add(id to rank)
        }
        val preferred = live.filter { it.second == "preferred" }
        return (if (preferred.isNotEmpty()) preferred else live).map { it.first }
    }

    private fun label(id: String): String? {
        val body = http(
            "https://www.wikidata.org/w/api.php?action=wbgetentities&format=json&props=labels" +
                "&languages=en&ids=" + Uri.encode(id)
        ) ?: return null
        val value = JSONObject(body).optJSONObject("entities")?.optJSONObject(id)
            ?.optJSONObject("labels")?.optJSONObject("en")?.optString("value").orEmpty()
        return value.ifBlank { null }
    }

    // ----------------------------------------------------------- dictionary

    private fun define(word: String): ActResult? {
        if (word.contains(' ')) return null // the dictionary only knows single words
        val body = http("https://api.dictionaryapi.dev/v2/entries/en/" + Uri.encode(word)) ?: return null
        val entry = JSONArray(body).optJSONObject(0) ?: return null
        val meanings = entry.optJSONArray("meanings") ?: return null

        val shown = ArrayList<String>()
        val spoken = ArrayList<String>()
        for (i in 0 until minOf(meanings.length(), 3)) {
            val m = meanings.optJSONObject(i) ?: continue
            val pos = m.optString("partOfSpeech")
            val def = m.optJSONArray("definitions")?.optJSONObject(0)?.optString("definition").orEmpty().trim()
            if (def.isEmpty()) continue
            shown.add(if (pos.isNotEmpty()) "($pos) $def" else def)
            spoken.add(if (pos.isNotEmpty()) "As a $pos: $def" else def)
        }
        if (shown.isEmpty()) return null

        val head = word.replaceFirstChar { it.uppercase() }
        return ActResult(
            text = head + "\n" + shown.joinToString("\n"),
            speak = head + ". " + spoken.take(2).joinToString(" "),
            link = "https://www.google.com/search?q=" + Uri.encode("define $word"),
            source = "Dictionary"
        )
    }

    // ----------------------------------------------------------------- http

    private fun http(url: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 5000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode != 200) null
            else conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
