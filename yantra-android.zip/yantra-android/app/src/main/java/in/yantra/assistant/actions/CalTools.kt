package `in`.yantra.assistant.actions

import android.content.Context
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object CalTools {

    /** First writable calendar on the device, or 1 as a last resort. */
    fun writeCalendarId(ctx: Context): Long {
        val proj = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
        try {
            ctx.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI, proj, null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val access = c.getInt(1)
                    if (access >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) return id
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return 1L
    }

    /** Today's events, as "9:30 AM  Dentist" strings. */
    fun today(ctx: Context): List<String> {
        val out = ArrayList<String>()
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val end = start + 86_400_000L

        val proj = arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART, CalendarContract.Events.ALL_DAY)
        try {
            ctx.contentResolver.query(
                CalendarContract.Events.CONTENT_URI, proj,
                "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ?",
                arrayOf(start.toString(), end.toString()),
                "${CalendarContract.Events.DTSTART} ASC"
            )?.use { c ->
                val ti = c.getColumnIndex(CalendarContract.Events.TITLE)
                val si = c.getColumnIndex(CalendarContract.Events.DTSTART)
                val ai = c.getColumnIndex(CalendarContract.Events.ALL_DAY)
                while (c.moveToNext() && out.size < 20) {
                    val title = c.getString(ti) ?: "(untitled)"
                    val allDay = c.getInt(ai) == 1
                    val when0 = if (allDay) "All day"
                    else SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date(c.getLong(si)))
                    out.add("$when0  $title")
                }
            }
        } catch (e: Exception) {
            return out
        }
        return out
    }
}
