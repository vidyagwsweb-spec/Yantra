package `in`.yantra.assistant.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

object Contacts {

    fun search(ctx: Context, name: String): List<Pair<String, String>> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return emptyList()

        val out = ArrayList<Pair<String, String>>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER

        try {
            ctx.contentResolver.query(
                uri, arrayOf(nameCol, numCol), "$nameCol LIKE ?", arrayOf("%$name%"), null
            )?.use { c ->
                val ni = c.getColumnIndex(nameCol)
                val pi = c.getColumnIndex(numCol)
                while (c.moveToNext() && out.size < 20) {
                    val n = c.getString(ni) ?: continue
                    val p = c.getString(pi) ?: continue
                    out.add(n to p)
                }
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    fun numberFor(ctx: Context, name: String): String? =
        search(ctx, name).firstOrNull()?.second?.replace(Regex("[^\\d+]"), "")
}
