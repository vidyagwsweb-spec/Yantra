package `in`.yantra.assistant.actions

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Open-Meteo: free, keyless, no account. */
object Weather {

    private fun get(url: String): JSONObject? = try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.requestMethod = "GET"
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        JSONObject(body)
    } catch (e: Exception) {
        null
    }

    suspend fun fetch(ctx: Context, city: String, mode: String): ActResult = withContext(Dispatchers.IO) {
        val place = city.ifEmpty { "Mumbai" }
        val geo = get(
            "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" +
                java.net.URLEncoder.encode(place, "UTF-8")
        )
        val first = geo?.optJSONArray("results")?.optJSONObject(0)
            ?: return@withContext ActResult("I could not find a place called \"$place\".")

        val name = first.optString("name", place)
        val lat = first.optDouble("latitude")
        val lon = first.optDouble("longitude")

        val wx = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=2"
        ) ?: return@withContext ActResult("The weather service did not answer.")

        val cur = wx.optJSONObject("current")
        val temp = cur?.optDouble("temperature_2m") ?: 0.0
        val feels = cur?.optDouble("apparent_temperature") ?: temp
        val hum = cur?.optInt("relative_humidity_2m") ?: 0
        val wind = cur?.optDouble("wind_speed_10m") ?: 0.0
        val code = cur?.optInt("weather_code") ?: 0
        val rain = wx.optJSONObject("daily")?.optJSONArray("precipitation_probability_max")?.optInt(0) ?: 0

        val desc = describe(code)
        if (mode == "rain") {
            return@withContext ActResult(
                if (rain >= 40) "Likely. $rain% chance of rain in $name, currently $desc."
                else "Unlikely. $rain% chance of rain in $name, currently $desc."
            )
        }

        ActResult(
            String.format(
                Locale.ENGLISH,
                "%s: %.0f\u00B0C and %s, feels like %.0f\u00B0C. Humidity %d%%, wind %.0f km/h, %d%% chance of rain.",
                name, temp, desc, feels, hum, wind, rain
            ),
            String.format(Locale.ENGLISH, "%s, %.0f degrees, %s.", name, temp, desc)
        )
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "clear sky"
        1, 2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "fog"
        51, 53, 55 -> "drizzle"
        61, 63, 65 -> "rain"
        71, 73, 75 -> "snow"
        80, 81, 82 -> "rain showers"
        95, 96, 99 -> "a thunderstorm"
        else -> "mixed conditions"
    }
}
