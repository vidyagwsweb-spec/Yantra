package `in`.yantra.assistant.brain

import java.util.Random
import kotlin.math.ln
import kotlin.math.sqrt

/** What the brain decided to do with a sentence. */
sealed class Thought {
    /** Just say this. */
    data class Reply(val text: String) : Thought()

    /** Run this exact command, then show its result. */
    data class Run(val command: String) : Thought()

    /** Ask [prompt]; a "yes" next turn runs [command]. */
    data class Confirm(val command: String, val prompt: String) : Thought()

    /** Nothing here. Let the normal fallback (web search, "I did not catch that") happen. */
    object Pass : Thought()
}

/**
 * A small on-device brain. It is not a language model. It does four things:
 *
 *  1. Fuzzy understanding. Your sentence is reduced to its meaningful words
 *     (stop words dropped, plurals and endings trimmed, near-miss spellings
 *     forgiven) and compared with a few hundred example phrasings. Rare words
 *     count for more than common ones.
 *  2. Small talk, a few facts, and "did you mean...?" for things Yantra can
 *     already do but that were not phrased the way the router expects.
 *  3. Short-term memory: "another one", and a pending yes or no.
 *  4. Learning: "when I say movie time, open netflix" is remembered for good.
 *
 * Pure Kotlin with no Android imports, so it is unit-tested on the JVM.
 */
class Brain(private val rng: Random = Random()) {

    var userName: String = ""

    /** Called whenever the taught shortcuts change, so the owner can save them. */
    var onTaughtChanged: (() -> Unit)? = null

    // normalised phrase -> "say:<text>" or "do:<command>"
    private val taught = LinkedHashMap<String, String>()
    private var pending: String? = null
    private var lastIntent: Intent? = null
    private var lastReply: String? = null

    // ---------------------------------------------------------------- index

    private class Entry(val intent: Intent?, val command: CommandEntry?, val tokens: List<String>)

    private val entries = ArrayList<Entry>()
    private val idf = HashMap<String, Double>()
    private var maxIdf = 1.0

    init {
        for (i in BrainData.INTENTS)
            for (ex in i.examples) entries.add(Entry(i, null, tokens(ex)))
        for (c in BrainData.COMMANDS)
            for (ex in c.examples) entries.add(Entry(null, c, tokens(ex)))

        val df = HashMap<String, Int>()
        for (e in entries) for (t in e.tokens.toSet()) df[t] = (df[t] ?: 0) + 1
        val n = entries.size.toDouble()
        for ((t, d) in df) idf[t] = ln(1.0 + n / d)
        maxIdf = ln(1.0 + n)
    }

    private fun weight(token: String): Double = idf[token] ?: maxIdf

    private val vocab: List<String> by lazy { idf.keys.toList() }

    /** A word Yantra has seen in some phrasing, or a near miss of one. */
    private fun known(token: String): Boolean {
        if (idf.containsKey(token)) return true
        for (v in vocab) if (tokenSimilarity(token, v) >= 0.7) return true
        return false
    }

    // ------------------------------------------------------------- taught

    fun taughtCount(): Int = taught.size

    fun taughtItems(): List<String> = taught.map { it.key + SEP + it.value }

    fun loadTaught(items: List<String>) {
        taught.clear()
        for (item in items) {
            val i = item.indexOf(SEP)
            if (i > 0 && i < item.length - 1) taught[item.substring(0, i)] = item.substring(i + 1)
        }
    }

    fun clearTaught(): Int {
        val n = taught.size
        taught.clear()
        if (n > 0) onTaughtChanged?.invoke()
        return n
    }

    /**
     * Teaching and housekeeping: "when I say X, open Y", "what have I taught you",
     * "forget the shortcut X", "forget all shortcuts". Null when the text is none of these.
     * [isCommand] says whether the router understands a command; only those are saved.
     */
    fun learn(raw: String, isCommand: (String) -> Boolean): Thought? {
        val text = raw.trim()

        TEACH.matchEntire(text)?.let { m ->
            val phrase = norm(m.groupValues[1])
            val verb = m.groupValues[2].lowercase()
            val rest = m.groupValues[3].trim().trim('"', '\u201C', '\u201D', '\'').trim()
            if (phrase.length < 2 || phrase.length > 60 || rest.isEmpty())
                return Thought.Reply("I could not tell what to remember there. Try \"when I say movie time, open netflix\".")
            if (taught.size >= MAX_TAUGHT && !taught.containsKey(phrase))
                return Thought.Reply("I am holding as many shortcuts as I can ($MAX_TAUGHT). Say \"forget all shortcuts\" to clear them.")

            return when (verb) {
                "say", "reply", "respond", "answer" -> {
                    taught[phrase] = "say:$rest"
                    onTaughtChanged?.invoke()
                    Thought.Reply("Got it. When you say \"$phrase\", I will say \"$rest\".")
                }
                else -> {
                    val command = when (verb) {
                        "open" -> "open $rest"
                        "call" -> "call $rest"
                        else -> rest
                    }
                    if (!isCommand(command)) {
                        Thought.Reply("I could not make a command out of \"$command\", so I did not save it. Try one I know, like \"open netflix\".")
                    } else {
                        taught[phrase] = "do:$command"
                        onTaughtChanged?.invoke()
                        Thought.Reply("Got it. When you say \"$phrase\", I will run \"$command\".")
                    }
                }
            }
        }

        val n = norm(text)
        if (LIST_TAUGHT.matches(n)) {
            if (taught.isEmpty()) return Thought.Reply("Nothing yet. Say \"when I say movie time, open netflix\" to teach me one.")
            val lines = taught.entries.take(12).joinToString("\n") { (k, v) ->
                "\u2022 \"$k\" \u2192 " + if (v.startsWith("do:")) v.substring(3) else "say \"" + v.substring(4) + "\""
            }
            val more = if (taught.size > 12) "\nAnd ${taught.size - 12} more." else ""
            return Thought.Reply("You have taught me ${taught.size}:\n$lines$more")
        }
        if (FORGET_ALL.matches(n)) {
            val count = clearTaught()
            return Thought.Reply(if (count == 0) "There was nothing to forget." else "Forgot all $count shortcuts.")
        }
        FORGET_ONE.matchEntire(n)?.let { m ->
            val key = m.groupValues[1].trim()
            return if (taught.remove(key) != null) {
                onTaughtChanged?.invoke()
                Thought.Reply("Forgot \"$key\".")
            } else {
                Thought.Reply("I do not have a shortcut called \"$key\".")
            }
        }
        return null
    }

    /** A phrase the user taught. Checked before the router, so it can override a built-in phrase. */
    fun recall(raw: String): Thought? {
        if (taught.isEmpty()) return null
        val n = norm(raw)
        if (n.isEmpty()) return null
        var value = taught[n]
        if (value == null && n.length >= 6) {
            // forgive one slip on longer phrases
            for ((k, v) in taught) if (k.length >= 6 && editDistance(k, n, 1) <= 1) { value = v; break }
        }
        val hit = value ?: return null
        pending = null
        lastIntent = null
        return if (hit.startsWith("do:")) Thought.Run(hit.substring(3))
        else Thought.Reply(fill(hit.substring(4)))
    }

    // ------------------------------------------------------------ dialogue

    fun hasPending(): Boolean = pending != null

    /** Waits for a yes or no next turn, then runs [command]. Used for things the language model proposed. */
    fun expect(command: String) {
        pending = command
        lastIntent = null
    }

    /** Call first on every turn. Consumes a waiting yes or no; null if nothing was waiting or the answer was neither. */
    fun answerPending(raw: String): Thought? {
        val cmd = pending ?: return null
        val n = norm(raw)
        pending = null
        if (YES.matches(n)) return Thought.Run(cmd)
        if (NO.matches(n)) return Thought.Reply("Okay, leaving it.")
        return null
    }

    /** "another one", "one more": a different reply from the same topic as last time. */
    fun more(raw: String): Thought? {
        val intent = lastIntent ?: return null
        if (intent.replies.size < 2) return null
        if (!MORE.matches(norm(raw))) return null
        return Thought.Reply(fill(pick(intent)))
    }

    /** The router handled the last thing, so "another one" no longer refers to a joke. */
    fun forgetTopic() {
        lastIntent = null
    }

    /**
     * Tries to understand a sentence the router could not. Only call this
     * for sentences the router did not claim.
     */
    fun think(raw: String): Thought {
        val n = norm(raw)
        if (n.isEmpty()) return Thought.Pass

        capital(n)?.let { return Thought.Reply(it) }

        val q = tokens(n)
        if (q.isEmpty()) return Thought.Pass

        // a third or more of the meaningful words are ones we have never seen
        // ("how old is the eiffel tower"): that is a question about something
        // else, so stay out of the way
        if (q.count { !known(it) } * 3 >= q.size) return Thought.Pass

        // best score per target (an intent or a command), so five phrasings of
        // one thing cannot make it look ambiguous with itself
        val best = HashMap<Any, Double>()
        for (e in entries) {
            val s = similarity(q, e.tokens)
            val key: Any = e.intent ?: e.command!!
            if (s > (best[key] ?: 0.0)) best[key] = s
        }
        val ranked = best.entries.sortedByDescending { it.value }
        if (ranked.isEmpty()) return Thought.Pass
        val top = ranked[0]
        val second = if (ranked.size > 1) ranked[1].value else 0.0
        if (top.value - second < MARGIN && top.value < SURE) return Thought.Pass

        val target = top.key
        if (target is Intent) {
            if (top.value < CHAT_MIN) return Thought.Pass
            lastIntent = target
            val text = fill(pick(target))
            if (target.offer != null) {
                pending = target.offer
                return Thought.Confirm(target.offer, text)
            }
            return Thought.Reply(text)
        }

        val c = target as CommandEntry
        lastIntent = null
        return when {
            top.value >= RUN_MIN && !c.alwaysAsk -> Thought.Run(c.command)
            top.value >= ASK_MIN -> {
                pending = c.command
                Thought.Confirm(c.command, c.ask)
            }
            else -> Thought.Pass
        }
    }

    // ------------------------------------------------------------ internals

    private fun pick(intent: Intent): String {
        val options = intent.replies
        if (options.size == 1) return options[0]
        var choice = options[rng.nextInt(options.size)]
        var guard = 0
        while (choice == lastReply && guard++ < 8) choice = options[rng.nextInt(options.size)]
        lastReply = choice
        return choice
    }

    private fun fill(template: String): String {
        val name = userName.trim()
        return if (name.isNotEmpty()) template.replace("{, name}", ", $name").replace("{name}", name)
        else template.replace("{, name}", "").replace("{name}", "").replace(Regex("\\s{2,}"), " ")
    }

    private fun capital(n: String): String? {
        val m = CAPITAL.find(n) ?: return null
        val place = m.groupValues[1].trim().removePrefix("the ").trim()
        val answer = BrainData.CAPITALS[place] ?: return null
        val shown = place.split(" ").joinToString(" ") { w ->
            if (w == "uk" || w == "usa" || w == "uae") w.uppercase() else w.replaceFirstChar { it.uppercase() }
        }
        return "The capital of $shown is $answer."
    }

    /**
     * How well does the query [q] explain a stored phrase [d], and the other way round?
     * Weighted by how rare each word is, then the geometric mean, so extra words
     * and missing words both cost.
     */
    private fun similarity(q: List<String>, d: List<String>): Double {
        if (q.isEmpty() || d.isEmpty()) return 0.0
        var qw = 0.0
        var qm = 0.0
        for (a in q) {
            val w = weight(a)
            var best = 0.0
            for (b in d) {
                val s = tokenSimilarity(a, b)
                if (s > best) best = s
                if (best == 1.0) break
            }
            qw += w
            qm += w * best
        }
        var dw = 0.0
        var dm = 0.0
        for (b in d) {
            val w = weight(b)
            var best = 0.0
            for (a in q) {
                val s = tokenSimilarity(a, b)
                if (s > best) best = s
                if (best == 1.0) break
            }
            dw += w
            dm += w * best
        }
        if (qw == 0.0 || dw == 0.0) return 0.0
        return sqrt((qm / qw) * (dm / dw))
    }

    private fun tokenSimilarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.length >= 5 && b.length >= 5 && editDistance(a, b, 1) <= 1) return 0.85
        if (a.length >= 8 && b.length >= 8 && editDistance(a, b, 2) <= 2) return 0.7
        return 0.0
    }

    companion object {
        private const val SEP = "\u001E"
        private const val MAX_TAUGHT = 100

        // thresholds, tuned against tools/tune-brain.py
        private const val CHAT_MIN = 0.62
        private const val ASK_MIN = 0.58
        private const val RUN_MIN = 0.86
        private const val SURE = 0.9
        private const val MARGIN = 0.05

        private val YES = Regex("(?:yes|yeah|yep|yup|sure|ok|okay|do it|go ahead|please do|haan|ha|haa|kar do|correct|right|why not)")
        private val NO = Regex("(?:no|nope|nah|dont|do not|cancel|never mind|nevermind|nahi|nahin|leave it|not now)")
        private val MORE = Regex("(?:another|another one|one more|more|next one|tell me another|give me another|go on|once more|again|something else)")

        private val TEACH = Regex(
            "^(?:when|if|whenever) i (?:say|type|ask) (.+?)[,;]? (?:then )?(?:you )?(say|reply|respond|answer|do|run|open|call)\\s+(.+)$",
            RegexOption.IGNORE_CASE
        )
        private val LIST_TAUGHT = Regex("(?:what have i taught you|what did i teach you|list (?:my )?shortcuts|show (?:my )?shortcuts|what shortcuts do i have|my shortcuts)")
        private val FORGET_ALL = Regex("(?:forget (?:all|every)(?: my| the)? shortcuts?|clear (?:all )?(?:my )?shortcuts?|forget everything i taught you)")
        private val FORGET_ONE = Regex("forget (?:the )?(?:shortcut|phrase) (.+)")

        private val CAPITAL = Regex("capital (?:city )?of ([a-z ]+)")

        private val STOP = hashSetOf(
            "a", "an", "the", "is", "are", "am", "was", "were", "be", "to", "of", "in", "on", "at", "it", "its",
            "me", "my", "you", "your", "yours", "please", "can", "could", "would", "will", "do", "does", "did",
            "i", "im", "ive", "that", "this", "for", "with", "and", "or", "so", "just", "now", "really", "very",
            "actually", "kindly", "hey", "hi", "yantra", "bro", "buddy", "yaar", "dude", "bhai", "ji", "sir", "madam", "ok", "okay", "then",
            "there", "some", "any", "there", "us", "we", "have", "has", "got", "as", "by", "from", "if", "up"
        )

        // one word for one thing
        private val SYNONYMS = mapOf(
            "torch" to "flashlight", "flashlite" to "flashlight", "favorite" to "favourite",
            "color" to "colour", "pic" to "picture", "photo" to "picture",
            "tune" to "song", "track" to "song", "dim" to "dark", "dimmer" to "dark",
            "blinding" to "bright", "brighter" to "bright", "louder" to "loud", "quieter" to "quiet",
            "noisy" to "loud", "cant" to "cannot", "dont" to "not", "whats" to "what", "hows" to "how"
        )

        fun norm(s: String): String = s.lowercase()
            .replace(Regex("[\u2018\u2019']"), "")
            .replace(Regex("[^a-z0-9\u00B0 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        fun tokens(s: String): List<String> {
            val out = ArrayList<String>()
            for (w in norm(s).split(' ')) {
                if (w.isEmpty() || w in STOP) continue
                out.add(stem(SYNONYMS[w] ?: w))
            }
            return out
        }

        /** Trims plurals and common endings so "jokes" and "joke" meet. The same function runs on both sides. */
        fun stem(word: String): String {
            var w = word
            if (w.length > 3 && w.endsWith("s") && !w.endsWith("ss")) w = w.dropLast(1)
            if (w.length > 5 && w.endsWith("ing")) w = w.dropLast(3)
            else if (w.length > 4 && w.endsWith("ed")) w = w.dropLast(2)
            if (w.length > 3 && w.endsWith("e")) w = w.dropLast(1)
            return w
        }

        /** Edit distance, giving up early once it passes [limit]. Returns limit + 1 in that case. */
        fun editDistance(a: String, b: String, limit: Int): Int {
            if (a == b) return 0
            if (Math.abs(a.length - b.length) > limit) return limit + 1
            var prev = IntArray(b.length + 1) { it }
            var cur = IntArray(b.length + 1)
            for (i in 1..a.length) {
                cur[0] = i
                var rowMin = cur[0]
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                    if (cur[j] < rowMin) rowMin = cur[j]
                }
                if (rowMin > limit) return limit + 1
                val t = prev; prev = cur; cur = t
            }
            return prev[b.length]
        }

        // ---------------------------------------------------------- crisis

        private val CRISIS = Regex(
            "\\b(?:kill myself|killing myself|end my life|end it all|want to die|wanna die|suicide|suicidal|" +
                "dont want to live|do not want to live|no reason to live|hurt myself|harm myself|" +
                "cut myself|better off dead|better off without me)\\b"
        )
        private val NOT_ABOUT_SELF = Regex("^(?:play|open|watch|search|google|download|show|find|launch|define|meaning of)\\b")

        const val CRISIS_REPLY =
            "I am really sorry you are hurting. I am only a small program on your phone, and you deserve " +
                "a real person right now. Please contact someone you trust, or a crisis line. In India, " +
                "Tele-MANAS is 14416. Elsewhere, search for your local crisis line. If you might act on " +
                "these thoughts, call your local emergency number now."

        /** Checked before anything else, on every message. */
        fun crisis(raw: String): Thought.Reply? {
            val n = norm(raw)
            if (NOT_ABOUT_SELF.containsMatchIn(n)) return null
            return if (CRISIS.containsMatchIn(n)) Thought.Reply(CRISIS_REPLY) else null
        }
    }
}
