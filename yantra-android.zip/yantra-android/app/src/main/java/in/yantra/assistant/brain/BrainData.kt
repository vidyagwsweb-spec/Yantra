package `in`.yantra.assistant.brain

/**
 * Everything the mini brain knows, as plain data. Adding a topic means adding
 * an [Intent] with a few ways people might say it; no other code changes.
 *
 * `{name}` is replaced with the user's name, or removed (with its comma) when
 * Yantra does not know it yet.
 */
class Intent(
    val id: String,
    val examples: List<String>,
    val replies: List<String>,
    /** A command to offer after the reply, answered with yes or no. */
    val offer: String? = null
)

/** A fuzzy way to say something Yantra can already do, mapped to the exact command. */
class CommandEntry(
    val command: String,
    val examples: List<String>,
    val ask: String,
    /** Always confirm first, even on a very close match. */
    val alwaysAsk: Boolean = false
)

object BrainData {

    val INTENTS: List<Intent> = listOf(

        Intent(
            "joke",
            examples = listOf(
                "tell me a joke", "make me laugh", "say something funny", "got any jokes",
                "joke", "i want to hear a joke", "crack a joke", "do you know any jokes"
            ),
            replies = listOf(
                "Why did the phone go to therapy? Too many unresolved notifications.",
                "I would tell you a UDP joke, but you might not get it.",
                "Why do programmers prefer dark mode? Because light attracts bugs.",
                "I told my phone I needed space. It opened the storage settings.",
                "Why was the maths book sad? It had too many problems.",
                "What do you call a fake noodle? An impasta.",
                "Why did the scarecrow win an award? He was outstanding in his field.",
                "I am reading a book about anti-gravity. It is impossible to put down."
            )
        ),

        Intent(
            "fact",
            examples = listOf(
                "tell me a fun fact", "tell me something interesting", "random fact",
                "give me a fact", "did you know", "teach me something", "say a fun fact",
                "interesting fact"
            ),
            replies = listOf(
                "Honey almost never spoils. Edible honey has been found in ancient Egyptian tombs.",
                "Octopuses have three hearts.",
                "Botanically, a banana is a berry and a strawberry is not.",
                "A day on Venus is longer than its year.",
                "Wombat droppings are cube shaped.",
                "Sharks are older than trees.",
                "Lightning is several times hotter than the surface of the sun.",
                "The Eiffel Tower grows by around 15 centimetres in summer heat."
            )
        ),

        Intent(
            "motivate",
            examples = listOf(
                "motivate me", "inspire me", "i need motivation", "give me some motivation",
                "say something inspiring", "cheer me up", "encourage me", "pep talk"
            ),
            replies = listOf(
                "Small steps still count. Do the next one.",
                "You do not have to finish today. Start with the part that takes five minutes.",
                "Progress is quiet. Keep showing up.",
                "Pick one thing, do it properly, then pick the next.",
                "A rough first version beats a perfect plan."
            )
        ),

        Intent(
            "compliment",
            examples = listOf(
                "you are smart", "good job", "well done", "you are awesome", "great assistant",
                "you are the best", "you are amazing", "good bot", "nice work", "you are helpful"
            ),
            replies = listOf(
                "Thank you{, name}. Happy to help.",
                "Appreciated{, name}. Anything else?",
                "Glad that worked."
            )
        ),

        Intent(
            "insult",
            examples = listOf(
                "you are stupid", "you are useless", "you suck", "dumb assistant",
                "you are dumb", "you are terrible", "worst assistant", "you are bad"
            ),
            replies = listOf(
                "Fair. I am small and I miss things. Tell me what you were after and I will try again.",
                "Sorry about that. Say it a different way and I will have another go."
            )
        ),

        Intent(
            "creator",
            examples = listOf(
                "who made you", "who created you", "who built you", "who is your creator",
                "who developed you", "who programmed you", "who is your developer"
            ),
            replies = listOf(
                "A developer wrote me in Kotlin. I run entirely on your phone."
            )
        ),

        Intent(
            "yantra-meaning",
            examples = listOf(
                "what does yantra mean", "meaning of yantra", "why are you called yantra",
                "why is your name yantra", "what is yantra"
            ),
            replies = listOf(
                "Yantra is Sanskrit for an instrument or a machine."
            )
        ),

        Intent(
            "about-self",
            examples = listOf(
                "tell me about yourself", "introduce yourself", "describe yourself",
                "what are you made of", "what is your brain", "how do you work",
                "how do you think", "are you smart", "are you intelligent"
            ),
            replies = listOf(
                "I am not a large language model. I match what you say against a few hundred phrasings, " +
                    "tolerate typos and word order, remember the last thing we talked about, and learn shortcuts " +
                    "you teach me. Everything happens on your phone, with no cloud."
            )
        ),

        Intent(
            "feelings",
            examples = listOf(
                "do you have feelings", "are you alive", "are you real", "are you conscious",
                "do you have emotions", "can you feel", "do you think", "are you sentient"
            ),
            replies = listOf(
                "No. I am a program, so no feelings and no inner life. I am still glad to be useful."
            )
        ),

        Intent(
            "favourite",
            examples = listOf(
                "what is your favourite colour", "what is your favorite color", "favourite food",
                "what is your favourite movie", "what is your favourite song", "what do you like",
                "what is your favourite thing"
            ),
            replies = listOf(
                "I do not have tastes, but I will say ember orange. It is the colour of my orb."
            )
        ),

        Intent(
            "age",
            examples = listOf(
                "how old are you", "when were you born", "what is your age", "when were you made"
            ),
            replies = listOf(
                "Not old. I am only as old as this install."
            )
        ),

        Intent(
            "love",
            examples = listOf(
                "i love you", "love you", "i like you", "i really like you", "you are my favourite"
            ),
            replies = listOf(
                "That is kind. I cannot love you back, I am a program, but I am glad I am useful."
            )
        ),

        Intent(
            "bored",
            examples = listOf(
                "i am bored", "im bored", "entertain me", "i have nothing to do",
                "i am so bored", "say something to pass the time"
            ),
            replies = listOf(
                "Try \"tell me a joke\", \"tell me a fun fact\", \"roll a dice\" or \"pick pizza or pasta\"."
            )
        ),

        Intent(
            "low",
            examples = listOf(
                "i am sad", "i feel down", "i am stressed", "i am anxious", "i feel lonely",
                "i am having a bad day", "i feel awful", "i am overwhelmed", "i am so stressed out",
                "i feel low", "i am not okay"
            ),
            replies = listOf(
                "That sounds heavy{, name}. I am only a small program, so someone you trust will do " +
                    "more for you than I can. Want me to set a five minute timer so you can take a breather?"
            ),
            offer = "set a timer for 5 minutes"
        ),

        Intent(
            "tired",
            examples = listOf(
                "i am tired", "i am sleepy", "im exhausted", "i need sleep", "i feel sleepy"
            ),
            replies = listOf(
                "Rest if you can{, name}. I can set an alarm when you know when you need to be up."
            )
        ),

        Intent(
            "hungry",
            examples = listOf(
                "i am hungry", "what should i eat", "what should i have for dinner",
                "what should i cook", "i am starving", "im so hungry"
            ),
            replies = listOf(
                "Give me two options and I will choose. Try \"pick biryani or pasta\"."
            )
        ),

        Intent(
            "good-night",
            examples = listOf(
                "good night", "goodnight", "gn", "sleep well", "i am going to sleep",
                "going to bed now", "time to sleep"
            ),
            replies = listOf(
                "Good night{, name}. Sleep well.",
                "Night{, name}. See you tomorrow."
            )
        ),

        Intent(
            "bye",
            examples = listOf(
                "bye", "goodbye", "see you", "see you later", "talk later", "catch you later", "bye bye"
            ),
            replies = listOf(
                "See you{, name}.",
                "Bye{, name}."
            )
        ),

        Intent(
            "sorry",
            examples = listOf(
                "sorry", "i am sorry", "my bad", "apologies", "oops sorry"
            ),
            replies = listOf(
                "No need to apologise.",
                "All good."
            )
        ),

        Intent(
            "are-you-there",
            examples = listOf(
                "are you there", "can you hear me", "are you listening", "hello are you there",
                "is anybody there", "you there"
            ),
            replies = listOf(
                "Here{, name}.",
                "Listening."
            )
        ),

        Intent(
            "can-learn",
            examples = listOf(
                "can you learn", "can i teach you", "teach you something", "how do i teach you",
                "can you remember things", "can you learn new commands", "how do i add a shortcut"
            ),
            replies = listOf(
                "Yes. Say \"when I say movie time, open netflix\" and I will keep that shortcut. " +
                    "You can also teach me replies: \"when I say good vibes, say thank you\". " +
                    "Say \"what have I taught you\" to see them all."
            )
        ),

        // ------------------------------------------------------------- knowledge

        Intent(
            "k-light",
            examples = listOf("how fast is light", "speed of light", "what is the speed of light"),
            replies = listOf("About 299,792 kilometres per second, roughly 300,000.")
        ),
        Intent(
            "k-planets",
            examples = listOf(
                "how many planets are there", "how many planets in the solar system", "number of planets"
            ),
            replies = listOf("Eight: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune.")
        ),
        Intent(
            "k-everest",
            examples = listOf(
                "tallest mountain in the world", "highest mountain", "how tall is mount everest",
                "what is the highest peak in the world"
            ),
            replies = listOf("Mount Everest, at about 8,849 metres above sea level.")
        ),
        Intent(
            "k-ocean",
            examples = listOf("largest ocean", "biggest ocean in the world", "what is the largest ocean"),
            replies = listOf("The Pacific Ocean.")
        ),
        Intent(
            "k-animal",
            examples = listOf("national animal of india", "what is the national animal of india"),
            replies = listOf("The Bengal tiger.")
        ),
        Intent(
            "k-bird",
            examples = listOf("national bird of india", "what is the national bird of india"),
            replies = listOf("The Indian peacock.")
        ),
        Intent(
            "k-flower",
            examples = listOf("national flower of india", "what is the national flower of india"),
            replies = listOf("The lotus.")
        ),
        Intent(
            "k-states",
            examples = listOf(
                "how many states are there in india", "number of states in india", "how many states does india have"
            ),
            replies = listOf("28 states and 8 union territories.")
        ),
        Intent(
            "k-continents",
            examples = listOf("how many continents are there", "number of continents", "how many continents"),
            replies = listOf("Seven: Asia, Africa, North America, South America, Antarctica, Europe and Australia.")
        ),
        Intent(
            "k-boil",
            examples = listOf(
                "boiling point of water", "at what temperature does water boil", "what temperature does water boil at"
            ),
            replies = listOf("100°C, which is 212°F, at sea level.")
        ),
        Intent(
            "k-freeze",
            examples = listOf(
                "freezing point of water", "at what temperature does water freeze", "when does water freeze"
            ),
            replies = listOf("0°C, which is 32°F.")
        ),
        Intent(
            "k-leap",
            examples = listOf("how many days in a leap year", "days in a leap year", "how long is a leap year"),
            replies = listOf("366 days.")
        ),
        Intent(
            "k-independence",
            examples = listOf(
                "when is indian independence day", "independence day of india", "india independence day date",
                "when did india get independence"
            ),
            replies = listOf("15 August. India became independent in 1947.")
        ),
        Intent(
            "k-republic",
            examples = listOf("when is republic day", "republic day of india", "india republic day date"),
            replies = listOf("26 January. The Constitution came into effect in 1950.")
        ),
        Intent(
            "k-gandhi",
            examples = listOf("father of the nation india", "who is the father of the nation of india"),
            replies = listOf("Mahatma Gandhi.")
        )
    )

    val COMMANDS: List<CommandEntry> = listOf(

        CommandEntry(
            "turn on flashlight",
            examples = listOf(
                "its dark in here", "its pitch dark", "i need some light", "light up the room",
                "need a torch", "torch please", "flashlight", "i need a flashlight", "its too dark to see"
            ),
            ask = "Turn on the flashlight?"
        ),
        CommandEntry(
            "turn off flashlight",
            examples = listOf(
                "flashlight off please", "torch off", "enough light", "i do not need the torch anymore",
                "kill the flashlight"
            ),
            ask = "Turn off the flashlight?"
        ),
        CommandEntry(
            "increase brightness",
            examples = listOf(
                "screen is too dark", "screen too dim", "i cannot read the screen", "brighten the screen",
                "the display is dim", "my screen is dark"
            ),
            ask = "Turn the brightness up?"
        ),
        CommandEntry(
            "decrease brightness",
            examples = listOf(
                "screen is too bright", "it hurts my eyes", "the screen is blinding", "display too bright",
                "my screen is too bright"
            ),
            ask = "Turn the brightness down?"
        ),
        CommandEntry(
            "increase volume",
            examples = listOf(
                "i cannot hear anything", "i cannot hear you", "speak up", "it is too quiet",
                "volume is too low", "the sound is too low"
            ),
            ask = "Turn the volume up?"
        ),
        CommandEntry(
            "decrease volume",
            examples = listOf(
                "it is too noisy", "it hurts my ears", "the sound is too high", "volume is too high",
                "that is too loud", "make it quieter"
            ),
            ask = "Turn the volume down?"
        ),
        CommandEntry(
            "mute",
            examples = listOf(
                "no sound", "quiet please", "silence please", "i want no sound", "kill the sound"
            ),
            ask = "Mute the volume?",
            alwaysAsk = true
        ),
        CommandEntry(
            "turn on do not disturb",
            examples = listOf(
                "i am in a meeting", "i am busy", "going into a meeting", "do not disturb me",
                "leave me alone", "focus time", "i need to focus", "i am studying"
            ),
            ask = "Turn on Do Not Disturb?",
            alwaysAsk = true
        ),
        CommandEntry(
            "what time is it",
            examples = listOf(
                "got the time", "time please", "tell me the time", "what is the time now",
                "what is the clock showing", "do you have the time"
            ),
            ask = "Tell you the time?"
        ),
        CommandEntry(
            "what day is it",
            examples = listOf(
                "which day is today", "todays date", "what is today", "date today",
                "which date is it today", "what is todays date"
            ),
            ask = "Tell you today's date?"
        ),
        CommandEntry(
            "weather",
            examples = listOf(
                "is it going to rain", "how is the weather", "weather outside", "is it hot outside",
                "how is the weather today", "is it cold outside", "will it rain today"
            ),
            ask = "Check the weather?"
        ),
        CommandEntry(
            "battery",
            examples = listOf(
                "how much charge is left", "is my phone dying", "battery level", "how much juice is left",
                "how much battery do i have", "is my phone charged"
            ),
            ask = "Check the battery?"
        ),
        CommandEntry(
            "open wifi settings",
            examples = listOf(
                "internet is not working", "wifi problem", "no internet", "i cannot connect to the internet",
                "connect to wifi", "my wifi is not working"
            ),
            ask = "Open the Wi-Fi settings?"
        ),
        CommandEntry(
            "next song",
            examples = listOf(
                "skip this song", "play the next one", "change the song", "i do not like this song",
                "skip this track"
            ),
            ask = "Skip to the next song?"
        ),
        CommandEntry(
            "pause the music",
            examples = listOf(
                "stop the music", "pause the song", "stop the song", "shut the music off"
            ),
            ask = "Pause the music?"
        ),
        CommandEntry(
            "take a photo",
            examples = listOf(
                "snap a picture", "take a pic", "i want a selfie", "take a picture of this"
            ),
            ask = "Open the camera?"
        )
    )

    /** Capitals for "what is the capital of ...". Static facts only. */
    val CAPITALS: Map<String, String> = mapOf(
        "india" to "New Delhi", "france" to "Paris", "germany" to "Berlin", "italy" to "Rome",
        "spain" to "Madrid", "portugal" to "Lisbon", "united kingdom" to "London", "uk" to "London",
        "england" to "London", "united states" to "Washington, D.C.", "usa" to "Washington, D.C.",
        "america" to "Washington, D.C.", "canada" to "Ottawa", "mexico" to "Mexico City",
        "brazil" to "Brasília", "argentina" to "Buenos Aires", "chile" to "Santiago", "peru" to "Lima",
        "colombia" to "Bogotá", "cuba" to "Havana", "china" to "Beijing", "japan" to "Tokyo",
        "south korea" to "Seoul", "north korea" to "Pyongyang", "russia" to "Moscow",
        "australia" to "Canberra", "new zealand" to "Wellington", "pakistan" to "Islamabad",
        "bangladesh" to "Dhaka", "nepal" to "Kathmandu", "bhutan" to "Thimphu", "afghanistan" to "Kabul",
        "sri lanka" to "Sri Jayawardenepura Kotte, with Colombo as the commercial capital",
        "iran" to "Tehran", "iraq" to "Baghdad", "saudi arabia" to "Riyadh",
        "uae" to "Abu Dhabi", "united arab emirates" to "Abu Dhabi", "turkey" to "Ankara",
        "egypt" to "Cairo", "kenya" to "Nairobi", "nigeria" to "Abuja", "ethiopia" to "Addis Ababa",
        "ghana" to "Accra", "thailand" to "Bangkok", "vietnam" to "Hanoi", "malaysia" to "Kuala Lumpur",
        "singapore" to "Singapore", "philippines" to "Manila", "myanmar" to "Naypyidaw",
        "greece" to "Athens", "netherlands" to "Amsterdam", "belgium" to "Brussels",
        "switzerland" to "Bern", "austria" to "Vienna", "sweden" to "Stockholm", "norway" to "Oslo",
        "denmark" to "Copenhagen", "finland" to "Helsinki", "poland" to "Warsaw", "ukraine" to "Kyiv",
        "ireland" to "Dublin",
        // Indian states
        "arunachal pradesh" to "Itanagar", "assam" to "Dispur", "bihar" to "Patna",
        "chhattisgarh" to "Raipur", "goa" to "Panaji", "gujarat" to "Gandhinagar",
        "haryana" to "Chandigarh", "himachal pradesh" to "Shimla", "jharkhand" to "Ranchi",
        "karnataka" to "Bengaluru", "kerala" to "Thiruvananthapuram", "madhya pradesh" to "Bhopal",
        "maharashtra" to "Mumbai", "manipur" to "Imphal", "meghalaya" to "Shillong",
        "mizoram" to "Aizawl", "nagaland" to "Kohima", "odisha" to "Bhubaneswar",
        "punjab" to "Chandigarh", "rajasthan" to "Jaipur", "sikkim" to "Gangtok",
        "tamil nadu" to "Chennai", "telangana" to "Hyderabad", "tripura" to "Agartala",
        "uttar pradesh" to "Lucknow", "uttarakhand" to "Dehradun", "west bengal" to "Kolkata"
    )
}
