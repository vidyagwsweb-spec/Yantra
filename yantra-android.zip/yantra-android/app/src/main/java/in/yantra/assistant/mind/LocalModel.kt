package `in`.yantra.assistant.mind

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import `in`.yantra.assistant.util.Prefs
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/**
 * A language model that runs on this phone, through Google's MediaPipe LLM
 * Inference. No account, no key, no network: the person picks a model file
 * (Gemma or Qwen, in MediaPipe's `.task` format) and Yantra copies it into its
 * private storage and loads it.
 *
 * The file is not bundled because it is hundreds of megabytes and Gemma's
 * licence has to be accepted by the person downloading it.
 */
class LocalModel(context: Context, private val prefs: Prefs) : TextModel {

    private val app = context.applicationContext
    private val dir = File(app.filesDir, "models")
    private val lock = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var engine: LlmInference? = null

    @Volatile
    override var ready: Boolean = false
        private set

    var lastError: String = ""
        private set

    override val style: PromptStyle
        get() = PromptStyle.forFile(prefs.get(KEY_NAME))

    // ------------------------------------------------------------ the file

    fun installedFile(): File? {
        val name = prefs.get(KEY_FILE)
        if (name.isEmpty()) return null
        val f = File(dir, name)
        return if (f.isFile && f.length() > 0) f else null
    }

    fun installedLabel(): String {
        val f = installedFile() ?: return ""
        val mb = f.length() / (1024 * 1024)
        return prefs.get(KEY_NAME, f.name) + " (" + mb + " MB)"
    }

    /**
     * Copies the model the person picked into private storage. Returns "" on
     * success, otherwise a sentence saying what went wrong.
     */
    suspend fun import(uri: Uri, onProgress: (Int) -> Unit): String {
        withContext(Dispatchers.Default) { lock.withLock { release() } }
        return withContext(Dispatchers.IO) { importBlocking(uri, onProgress) }
    }

    private fun importBlocking(uri: Uri, onProgress: (Int) -> Unit): String {
        var name = "model.task"
        var size = -1L
        try {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
            // the name and size are only nice to have
        }

        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val lower = safe.lowercase()
        if (!(lower.endsWith(".task") || lower.endsWith(".bin"))) {
            return "That is not a MediaPipe model file. Choose a .task file, for example a Gemma 3 1B or Qwen 2.5 file made for MediaPipe."
        }
        if (!dir.exists() && !dir.mkdirs()) return "I could not create a place to keep the model."
        if (size > 0 && dir.usableSpace < size + 64L * 1024 * 1024) {
            return "Not enough free storage for a ${size / (1024 * 1024)} MB model."
        }

        val tmp = File(dir, "import.partial")
        try {
            val input = app.contentResolver.openInputStream(uri) ?: return "I could not open that file."
            input.use { src ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(1 shl 20)
                    var total = 0L
                    var last = -1
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        if (size > 0) {
                            val pct = (total * 100 / size).toInt().coerceIn(0, 100)
                            if (pct != last) { last = pct; onProgress(pct) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            return "Copying failed: ${e.message ?: "unknown error"}."
        }

        if (tmp.length() < MIN_BYTES) {
            tmp.delete()
            return "That file is too small to be a language model."
        }
        dir.listFiles()?.forEach { if (it.name != tmp.name) it.delete() }
        val target = File(dir, safe)
        if (!tmp.renameTo(target)) {
            tmp.delete()
            return "I could not save the model."
        }
        prefs.set(KEY_FILE, safe)
        prefs.set(KEY_NAME, name)
        lastError = ""
        return ""
    }

    // ------------------------------------------------------------- loading

    /** Loads the installed model into memory. True when it is ready to answer. */
    suspend fun load(): Boolean = withContext(Dispatchers.Default) {
        lock.withLock {
            if (engine != null) return@withLock true
            val file = installedFile() ?: return@withLock false
            try {
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file.absolutePath)
                    .setMaxTokens(MAX_TOKENS)
                    .build()
                engine = LlmInference.createFromOptions(app, options)
                ready = true
                lastError = ""
                true
            } catch (e: Throwable) {
                // native load failures (wrong format, not enough memory) are Errors, not Exceptions
                engine = null
                ready = false
                lastError = e.message?.take(160) ?: e.javaClass.simpleName
                false
            }
        }
    }

    suspend fun unload() = withContext(Dispatchers.Default) { lock.withLock { release() } }

    suspend fun remove() = withContext(Dispatchers.IO) {
        lock.withLock {
            release()
            dir.deleteRecursively()
            prefs.set(KEY_FILE, "")
            prefs.set(KEY_NAME, "")
            lastError = ""
        }
    }

    private fun release() {
        ready = false
        try { engine?.close() } catch (ignored: Throwable) { }
        engine = null
    }

    fun shutdown() {
        ready = false
        scope.cancel()
        try { engine?.close() } catch (ignored: Throwable) { }
        engine = null
    }

    // ---------------------------------------------------------- generating

    /**
     * Runs the prompt. Generation is blocking native code that cannot be
     * interrupted, so it runs on its own scope and the caller simply stops
     * waiting after [TIMEOUT_MS]. Calls are queued, one at a time.
     */
    override suspend fun complete(prompt: String): String? {
        if (!ready) return null
        val result = CompletableDeferred<String?>()
        scope.launch {
            lock.withLock {
                result.complete(
                    try { generate(prompt) } catch (e: Throwable) { null }
                )
            }
        }
        return withTimeoutOrNull(TIMEOUT_MS) { result.await() }
    }

    private fun generate(prompt: String): String? {
        val llm = engine ?: return null
        val options = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(20)
            .setTemperature(0.3f)
            .setRandomSeed(1)
            .build()
        val session = LlmInferenceSession.createFromOptions(llm, options)
        return try {
            session.addQueryChunk(prompt)
            session.generateResponse()
        } finally {
            try { session.close() } catch (ignored: Throwable) { }
        }
    }

    private companion object {
        const val KEY_FILE = "llm.file"
        const val KEY_NAME = "llm.name"
        const val MAX_TOKENS = 1024
        const val TIMEOUT_MS = 90_000L
        const val MIN_BYTES = 50L * 1024 * 1024
    }
}
