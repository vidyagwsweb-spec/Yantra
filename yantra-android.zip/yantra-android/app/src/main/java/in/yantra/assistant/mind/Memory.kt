package `in`.yantra.assistant.mind

/**
 * Things the person told Yantra to remember, kept on the phone.
 *
 * Only explicit statements are stored: "remember that ...", "my birthday is ...",
 * "I live in ...". Nothing is inferred from ordinary chat. Anything that looks
 * like a secret (passwords, PINs, card or ID numbers) is refused.
 *
 * Pure Kotlin, no Android imports.
 */
class Memory {

    /** Called after every change so the owner can save [items]. */
    var onChanged: (() -> Unit)? = null

    // topic -> value. Free notes use a topic that starts with "note:".
    private val facts = LinkedHashMap<String, String>()

    fun count(): Int = facts.size

    fun items(): List<String> = facts.map { it.key + SEP + it.value }

    fun load(items: List<String>) {
        facts.clear()
        for (item in items) {
            val i = item.indexOf(SEP)
            if (i > 0 && i < item.length - 1) facts[item.substring(0, i)] = item.substring(i + 1)
        }
    }

    fun clear(): Int {
        val n = facts.size
        facts.clear()
        if (n > 0) onChanged?.invoke()
        return n
    }

    /** A few facts for a prompt, as short lines. Empty when nothing is stored. */
    fun promptBlock(maxChars: Int = 600): String {
        if (facts.isEmpty()) return ""
        val sb = StringBuilder("Things the user told you to remember:\n")
        for ((k, v) in facts.entries.reversed()) {
            val line = "- " + sentence(k, v) + "\n"
            if (sb.length + line.length > maxChars) break
            sb.append(line)
        }
        return sb.toString().trimEnd()
    }

    /**
     * Remembering, recalling and forgetting. Returns the reply, or null when the
     * sentence is none of these, so the normal pipeline carries on.
     */
    fun handle(raw: String): String? {
        val text = raw.trim().trimEnd('.', '!', '?').trim()
        if (text.isEmpty() || text.length > 200) return null

        val low = text.lowercase().replace(Regex("[\u2018\u2019']"), "")

        // ---- forgetting
        if (FORGET_ALL.matches(text)) {
            val n = clear()
            return if (n == 0) "I was not holding anything about you." else "Forgot all $n ${if (n == 1) "thing" else "things"} I knew about you."
        }
        FORGET_MY.matchEntire(text)?.let { m ->
            val key = topicOf(m.groupValues[1])
            if (key.startsWith("shortcut") || key.isEmpty()) return null
            val hit = facts.keys.firstOrNull { if (it.startsWith("note:")) it.contains(key) else sameTopic(it, key) }
            return if (hit != null) { facts.remove(hit); onChanged?.invoke(); "Forgot your $key." }
            else "I do not have anything saved about your $key."
        }
        FORGET_THAT.matchEntire(text)?.let { m ->
            val needle = secondPerson(m.groupValues[1]).lowercase().trimEnd('.')
            if (needle.length < 4 || needle.startsWith("shortcut") || needle.startsWith("all ")) return null
            val word = Regex("\\b" + Regex.escape(needle) + "\\b")
            val hit = facts.entries.firstOrNull { word.containsMatchIn(sentence(it.key, it.value).lowercase()) }
            return if (hit != null) { facts.remove(hit.key); onChanged?.invoke(); "Forgot that." } else null
        }

        // ---- recalling
        if (LIST_ALL.matches(low)) {
            if (facts.isEmpty()) return "Nothing yet. Tell me something with \"remember that ...\" or \"my birthday is ...\"."
            val lines = facts.entries.toList().takeLast(15).joinToString("\n") { "\u2022 " + sentence(it.key, it.value) }
            return "Here is what you told me:\n$lines"
        }
        WHERE_LIVE.matchEntire(low)?.let {
            facts["home"]?.let { v -> return "You live in $v." }
            return null
        }
        ASK_MY.matchEntire(low)?.let { m ->
            val key = topicOf(m.groupValues[1])
            val hit = facts.entries.firstOrNull { !it.key.startsWith("note:") && sameTopic(it.key, key) }
            if (hit != null) return "Your ${hit.key} is ${hit.value}."
            return null
        }

        // ---- remembering
        REMEMBER.matchEntire(text)?.let { m ->
            val body = m.groupValues[1].trim()
            if (body.isEmpty()) return null
            if (body.lowercase().startsWith("to ")) return null // "remember to call mom" is a reminder, not a fact
            return store(body)
        }
        REL.matchEntire(text)?.let { m -> return put(m.groupValues[1].lowercase(), clean(m.groupValues[2])) }
        PROP.matchEntire(text)?.let { m -> return put(topicOf(m.groupValues[1]), clean(m.groupValues[2])) }
        LIVE.matchEntire(text)?.let { m -> return put("home", clean(m.groupValues[1])) }
        WORK.matchEntire(text)?.let { m -> return noteFact("You work ${m.groupValues[1].lowercase()} ${clean(m.groupValues[2])}.") }
        FROM.matchEntire(text)?.let { m -> return noteFact("You are from ${clean(m.groupValues[1])}.") }
        DIET.matchEntire(text)?.let { m -> return noteFact("You are ${m.groupValues[1].lowercase()}.") }
        return null
    }

    // ------------------------------------------------------------ internals

    private fun store(body: String): String {
        MY_IS.matchEntire(body)?.let { m -> return put(topicOf(m.groupValues[1]), clean(m.groupValues[2])) }
        return noteFact(secondPerson(body))
    }

    private fun put(topic: String, value: String): String {
        if (topic.isEmpty() || value.isEmpty()) return "I could not tell what to remember there."
        refuse(topic + " " + value)?.let { return it }
        if (facts.size >= MAX_FACTS && !facts.containsKey(topic)) return FULL
        facts[topic] = value
        onChanged?.invoke()
        return "Okay, your $topic is $value."
    }

    private fun noteFact(sentence: String): String {
        refuse(sentence)?.let { return it }
        val key = "note:" + sentence.lowercase().take(48)
        if (facts.size >= MAX_FACTS && !facts.containsKey(key)) return FULL
        facts[key] = sentence
        onChanged?.invoke()
        return "Okay, I will remember that."
    }

    private fun refuse(s: String): String? {
        if (SECRET.containsMatchIn(s.lowercase()) || LONG_DIGITS.containsMatchIn(s.replace(Regex("[ -]"), "")))
            return "I will not store that. Passwords, PINs and card or ID numbers do not belong in a chat assistant."
        return null
    }

    /** "mom" -> "mom"; "moms name" -> "mom"; "favourite song" stays. */
    private fun topicOf(s: String): String {
        var t = s.lowercase().replace(Regex("[\u2018\u2019']"), "").trim()
        t = t.replace(Regex("^(?:the|my)\\s+"), "").replace(Regex("\\s+name$"), "").trim()
        if (t.length > 3 && t.endsWith("s") && t.dropLast(1) in RELATIONS) t = t.dropLast(1)
        return t
    }

    private fun clean(s: String): String = s.trim().trim('"', '\u201C', '\u201D').trim().trimEnd('.')

    private fun sentence(topic: String, value: String): String =
        if (topic.startsWith("note:")) value else "Your $topic is $value."

    /** True when one topic's words are all inside the other's, so "card limit" is not "car". */
    private fun sameTopic(a: String, b: String): Boolean {
        val aw = a.split(' ').filter { it.isNotEmpty() }.toSet()
        val bw = b.split(' ').filter { it.isNotEmpty() }.toSet()
        return aw.isNotEmpty() && bw.isNotEmpty() && (aw.containsAll(bw) || bw.containsAll(aw))
    }

    /** "I am vegetarian" -> "You are vegetarian." */
    private fun secondPerson(s: String): String {
        var t = " " + s.trim() + " "
        for ((from, to) in PERSON) t = t.replace(Regex("(?i)(?<=\\W)" + from + "(?=\\W)"), to)
        t = t.trim()
        t = t.replaceFirstChar { it.uppercase() }
        return if (t.endsWith(".")) t else "$t."
    }

    companion object {
        private const val SEP = "\u001E"
        private const val MAX_FACTS = 60
        private const val FULL = "I am holding as much as I can (60 things). Say \"forget everything about me\" to clear it, or forget one thing."

        private val RELATIONS = setOf(
            "mom", "mother", "mum", "dad", "father", "wife", "husband", "brother", "sister", "boss",
            "friend", "best friend", "partner", "son", "daughter", "girlfriend", "boyfriend", "roommate"
        )

        private const val REL_WORDS = "mom|mother|mum|dad|father|wife|husband|brother|sister|boss|best friend|friend|partner|son|daughter|girlfriend|boyfriend|roommate"

        private val SECRET = Regex("\\b(?:password|passcode|pin|otp|cvv|card number|aadhaar|aadhar|pan number|ssn|passport)\\b")
        private val LONG_DIGITS = Regex("\\d{12,}")

        private val FORGET_ALL = Regex(
            "(?i)(?:(?:forget|erase|delete|clear) (?:everything|all)(?: that)?(?: you (?:know|remember))? (?:about me|i told you)" +
                "|(?:forget|erase|clear|delete) (?:my )?(?:memory|memories)" +
                "|forget everything)"
        )
        private val FORGET_MY = Regex("(?i)(?:forget|delete) my ([a-z' ]{2,30})")
        private val FORGET_THAT = Regex("(?i)forget (?:that |what i said about |about )(.{2,60})")
        private val LIST_ALL = Regex("(?:what do you (?:know|remember) about me|what have i told you|what do you remember|what do you know about me)")
        private val WHERE_LIVE = Regex("(?:where do i (?:live|stay)|what city do i live in)")
        private val ASK_MY = Regex("(?:what is|whats|when is|whens|who is|whos|where is|what are) my ([a-z' ]{2,30})")

        private val REMEMBER = Regex("(?i)(?:please )?(?:remember|keep in mind)(?: that)? (.+)")
        private val MY_IS = Regex("(?i)my ([a-z' ]{2,30}?) (?:is|are) (.{1,80})")
        private val REL = Regex("(?i)my ($REL_WORDS)(?:['\u2019]s)?(?: name)? (?:is|is called|are called) (.{1,60})")
        private val PROP = Regex("(?i)my (birthday|bday|anniversary|address|city|hometown|home town|phone number|blood group|job|office|car|bike|pet|dog|cat|favou?rite [a-z ]{2,20})(?:['\u2019]s name)? (?:is|are) (.{1,80})")
        private val LIVE = Regex("(?i)i (?:live|stay) in (.{2,40})")
        private val WORK = Regex("(?i)i work (at|for|as|in) (.{2,50})")
        private val FROM = Regex("(?i)i(?:'m|\u2019m| am) from (.{2,40})")
        private val DIET = Regex("(?i)i(?:'m|\u2019m| am) (vegetarian|vegan|eggetarian|jain|allergic to .{2,30}|lactose intolerant|gluten free)")

        private val PERSON = listOf(
            "i am" to "you are", "i'm" to "you are", "im" to "you are", "i was" to "you were",
            "i have" to "you have", "i" to "you", "my" to "your", "me" to "you", "mine" to "yours", "myself" to "yourself"
        )
    }
}
