package `in`.yantra.assistant.mind

/**
 * Things the person told Yantra to remember, kept on the phone.
 *
 * Two ways in:
 *  - Explicit: "remember that ...", "my birthday is ...", "I live in ...".
 *  - Plain statements about yourself, when [handle] is told it may listen for them
 *    ("I am in 9th grade. I love philosophy, innovation, and strategy."). Every
 *    sentence has to be something Yantra understands as a fact about you; if even one
 *    is not, nothing is stored and the whole message goes on to the normal pipeline,
 *    so a command is never swallowed by the memory.
 *
 * Nothing is inferred beyond what was said. Anything that looks like a secret
 * (passwords, PINs, card or ID numbers) is refused.
 *
 * Pure Kotlin, no Android imports.
 */
class Memory {

    /** Called after every change so the owner can save [items]. */
    var onChanged: (() -> Unit)? = null

    /** Called when the person says their name, so the greeting can use it. */
    var onName: ((String) -> Unit)? = null

    // topic -> value. Free notes use a topic that starts with "note:".
    private val facts = LinkedHashMap<String, String>()

    fun count(): Int = facts.size

    fun items(): List<String> = facts.map { it.key + SEP + it.value }

    /** Everything remembered, as readable sentences, oldest first. For the Settings list. */
    fun lines(): List<String> = facts.map { sentence(it.key, it.value) }

    /** Forgets the [index]th line of [lines]. False when there is no such line. */
    fun removeAt(index: Int): Boolean {
        if (index !in 0 until facts.size) return false
        facts.remove(facts.keys.elementAt(index))
        onChanged?.invoke()
        return true
    }

    fun load(items: List<String>) {
        facts.clear()
        for (item in items) {
            val i = item.indexOf(SEP)
            if (i > 0 && i < item.length - 1) facts[item.substring(0, i)] = item.substring(i + 1)
        }
    }

    fun clear(): Int {
        val n = facts.size
        facts.clear()
        if (n > 0) onChanged?.invoke()
        return n
    }

    /** A few facts for a prompt, as short lines. Empty when nothing is stored. */
    fun promptBlock(maxChars: Int = 600): String {
        if (facts.isEmpty()) return ""
        val sb = StringBuilder("Things the user told you to remember:\n")
        for ((k, v) in facts.entries.reversed()) {
            val line = "- " + sentence(k, v) + "\n"
            if (sb.length + line.length > maxChars) break
            sb.append(line)
        }
        return sb.toString().trimEnd()
    }

    /** True for "show my memories" and its many phrasings. */
    fun isListRequest(raw: String): Boolean {
        val low = raw.trim().trimEnd('.', '!', '?').trim().lowercase().replace(Regex("[\u2018\u2019']"), "")
        return low.isNotEmpty() && low.length <= MAX_INPUT && LIST_ALL.any { it.matches(low) }
    }

    /** The numbered list the person sees for "show my memories". */
    fun listing(): String {
        if (facts.isEmpty())
            return "Nothing yet. Tell me about yourself, like \"I am in 9th grade\" or \"remember that my locker code is on the fridge\"."
        val all = lines()
        val first = (all.size - MAX_SHOWN).coerceAtLeast(0)
        val body = all.withIndex().drop(first).joinToString("\n") { (i, line) -> "${i + 1}. $line" }
        val older = if (first > 0) "($first older ${if (first == 1) "one" else "ones"} not shown.)\n" else ""
        return "I remember ${all.size} ${if (all.size == 1) "thing" else "things"} about you:\n$older$body\n" +
            "Say \"forget memory 2\" to drop one, or \"forget everything about me\"."
    }

    /**
     * Remembering, recalling and forgetting. Returns the reply, or null when the
     * sentence is none of these, so the normal pipeline carries on.
     *
     * [passive] lets plain statements like "I love chess" be remembered without the
     * word "remember". Turn it off to keep only the explicit commands.
     */
    fun handle(raw: String, passive: Boolean = true): String? {
        val text = raw.trim().trimEnd('.', '!', '?').trim()
        if (text.isEmpty() || text.length > MAX_INPUT) return null

        val low = text.lowercase().replace(Regex("[\u2018\u2019']"), "")

        // ---- forgetting
        if (FORGET_ALL.matches(text)) {
            val n = clear()
            return if (n == 0) "I was not holding anything about you." else "Forgot all $n ${if (n == 1) "thing" else "things"} I knew about you."
        }
        FORGET_NUM.matchEntire(low)?.let { m ->
            val n = m.groupValues[1].toInt()
            if (facts.isEmpty()) return null
            val line = lines().getOrNull(n - 1) ?: return "I only have ${facts.size} ${if (facts.size == 1) "memory" else "memories"}, so there is no number $n."
            removeAt(n - 1)
            return "Forgot: $line"
        }
        FORGET_MY.matchEntire(text)?.let { m ->
            val key = topicOf(m.groupValues[1])
            if (key.startsWith("shortcut") || key.isEmpty()) return null
            val hit = facts.keys.firstOrNull { if (it.startsWith("note:")) it.contains(key) else sameTopic(it, key) }
            return if (hit != null) { facts.remove(hit); onChanged?.invoke(); "Forgot your $key." }
            else "I do not have anything saved about your $key."
        }
        FORGET_THAT.matchEntire(text)?.let { m ->
            val needle = secondPerson(m.groupValues[1]).lowercase().trimEnd('.')
            if (needle.length < 4 || needle.startsWith("shortcut") || needle.startsWith("all ")) return null
            val word = Regex("\\b" + Regex.escape(needle) + "\\b")
            val hit = facts.entries.firstOrNull { word.containsMatchIn(sentence(it.key, it.value).lowercase()) }
            return if (hit != null) { facts.remove(hit.key); onChanged?.invoke(); "Forgot that." } else null
        }

        // ---- showing and recalling
        if (LIST_ALL.any { it.matches(low) }) return listing()
        recall(low)?.let { return it }

        // ---- remembering, on request
        REMEMBER.matchEntire(text)?.let { m ->
            val body = m.groupValues[1].trim()
            if (body.isEmpty()) return null
            if (body.lowercase().startsWith("to ")) return null // "remember to call mom" is a reminder, not a fact
            val cand = parse(body)
            if (cand != null) return commitAll(listOf(cand))
            return store(body)
        }

        // ---- plain statements about the person
        if (!passive) return null
        return digest(raw.trim())
    }

    // ------------------------------------------------------------ internals

    /** A fact ready to store: where it goes, what it says, and how Yantra answers. */
    private class Cand(val key: String, val value: String, val clause: String, val reply: String)

    private fun fact(topic: String, value: String) =
        Cand(topic, value, "Your $topic is $value.", "Okay, your $topic is $value.")

    private fun note(sentence: String, reply: String = "Okay, I will remember that.") =
        Cand("note:" + sentence.lowercase().take(48), sentence, sentence, reply)

    private fun commitAll(cands: List<Cand>): String {
        for (c in cands) {
            refuse(c.key + " " + c.value)?.let { return it }
            if (facts.size >= MAX_FACTS && !facts.containsKey(c.key)) return FULL
        }
        for (c in cands) facts[c.key] = c.value
        onChanged?.invoke()
        if (cands.size == 1) {
            val c = cands[0]
            if (c.key == "name") onName?.invoke(c.value)
            return c.reply
        }
        cands.firstOrNull { it.key == "name" }?.let { onName?.invoke(it.value) }
        return "Noted. " + cands.joinToString(" ") { it.clause }
    }

    /** Every sentence must be a fact about the person, or the whole message is left alone. */
    private fun digest(text: String): String? {
        val parts = SPLIT.split(text).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty() || parts.size > MAX_SENTENCES) return null
        val cands = ArrayList<Cand>()
        for (p in parts) cands.add(parse(p) ?: return null)
        return commitAll(cands)
    }

    /** One sentence -> a fact, or null when it is not a plain statement about the person. */
    private fun parse(sentence: String): Cand? {
        var s = sentence.trim()
        if (s.endsWith("?")) return null
        s = s.trimEnd('.', '!', ' ').replace(Regex("[\u2018\u2019]"), "'")
        s = FILLER.replace(s, "")
        s = IM.replace(s, "I am")
        if (s.isEmpty() || s.length > 160 || QUESTION_START.containsMatchIn(s)) return null

        REL.matchEntire(s)?.let { m -> return nonEmpty(m.groupValues[1].lowercase(), clean(m.groupValues[2])) }
        NAME.matchEntire(s)?.let { m ->
            val n = clean(m.groupValues[1]).split(' ').joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
            return Cand("name", n, "Your name is $n.", "Nice to meet you, $n.")
        }
        PROP.matchEntire(s)?.let { m -> return nonEmpty(topicOf(m.groupValues[1]), clean(m.groupValues[2])) }
        LIVE.matchEntire(s)?.let { m -> return nonEmpty("home", clean(m.groupValues[1])) }
        WORK.matchEntire(s)?.let { m -> return note("You work ${m.groupValues[1].lowercase()} ${clean(m.groupValues[2])}.") }
        FROM.matchEntire(s)?.let { m -> return note("You are from ${clean(m.groupValues[1])}.") }
        DIET.matchEntire(s)?.let { m -> return note("You are ${m.groupValues[1].lowercase()}.") }

        AGE.matchEntire(s)?.let { m ->
            val n = m.groupValues[1].toInt()
            if (n in 3..99) return fact("age", n.toString())
        }
        GRADE_A.matchEntire(s)?.let { m -> return grade(m.groupValues[1], m.groupValues[2], m.groupValues[3]) }
        GRADE_B.matchEntire(s)?.let { m -> return grade(m.groupValues[2], m.groupValues[1], m.groupValues[3]) }
        ATTEND.matchEntire(s)?.let { m -> return nice("You study at ${clean(m.groupValues[1])}.") }
        ROLE.matchEntire(s)?.let { m -> return nice("You are ${m.groupValues[1].lowercase()}.") }

        LIKES.matchEntire(s)?.let { m ->
            val obj = clean(m.groupValues[2])
            if (usable(obj)) return nice("You ${verb(m.groupValues[1])} ${tidyList(obj)}.")
        }
        DISLIKES.matchEntire(s)?.let { m ->
            val obj = clean(m.groupValues[1])
            if (usable(obj)) return nice("You ${if (s.contains("stand")) "cannot stand" else dislikeVerb(s)} ${tidyList(obj)}.")
        }
        DOING.matchEntire(s)?.let { m ->
            val obj = clean(m.groupValues[2])
            if (usable(obj)) return nice("You are ${m.groupValues[1].lowercase()} ${tidyList(obj)}.")
        }
        GOAL.matchEntire(s)?.let { m ->
            val obj = clean(m.groupValues[2])
            if (usable(obj)) return nice("You want to ${m.groupValues[1].lowercase()} ${tidyList(obj)}.")
        }
        ASPIRE.matchEntire(s)?.let { m ->
            val obj = clean(m.groupValues[2])
            if (usable(obj)) return nice("You ${m.groupValues[1].lowercase()} ${tidyList(obj)}.")
        }
        return null
    }

    private fun nonEmpty(topic: String, value: String): Cand? =
        if (topic.isEmpty() || value.isEmpty()) null else fact(topic, value)

    private fun nice(sentence: String) = note(sentence, "Got it. $sentence")

    private fun grade(num: String, kind: String, extra: String): Cand {
        val n = num.lowercase()
        val label = if (n.all { it.isDigit() }) {
            // "class 9" reads better than "9th class"; "9th grade" reads better than "grade 9"
            val v = n.toInt()
            if (kind.lowercase() == "grade") "${ordinal(v)} grade" else "${kind.lowercase()} $v"
        } else "$n ${kind.lowercase()}"
        val at = clean(extra)
        return nice("You are in $label" + (if (at.isNotEmpty()) " at $at" else "") + ".")
    }

    private fun ordinal(n: Int): String {
        val suffix = if (n % 100 in 11..13) "th" else when (n % 10) { 1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th" }
        return "$n$suffix"
    }

    private fun verb(v: String): String {
        val x = v.lowercase()
        return if (x.startsWith("am ")) "are " + x.removePrefix("am ") else x
    }

    private fun dislikeVerb(s: String): String = when {
        Regex("(?i)\\bdetest\\b").containsMatchIn(s) -> "detest"
        Regex("(?i)\\bdislike\\b").containsMatchIn(s) -> "dislike"
        Regex("(?i)\\b(?:do not|dont) like\\b").containsMatchIn(s) -> "do not like"
        else -> "hate"
    }

    /** "philosophy, innovation and strategy" stays as said; just tidy stray spacing. */
    private fun tidyList(s: String): String = s.replace(Regex("\\s*,\\s*"), ", ").replace(Regex("\\s+"), " ").trim()

    /**
     * What a person likes or studies has to be a thing, not the assistant, not a pronoun,
     * and not a command riding along ("I love music, open youtube").
     */
    private fun usable(obj: String): Boolean {
        if (obj.length < 2) return false
        if (OBJ_PRONOUN.containsMatchIn(obj)) return false
        if (Regex("(?i)\\b(?:you|your|yours|yantra)\\b").containsMatchIn(obj)) return false
        if (CMD_TAIL.containsMatchIn(obj)) return false
        return true
    }

    private fun recall(low: String): String? {
        WHERE_LIVE.matchEntire(low)?.let {
            facts["home"]?.let { v -> return "You live in $v." }
            return null
        }
        if (HOW_OLD.matches(low)) return facts["age"]?.let { "You are $it." }
        if (MY_NAME.matches(low)) return facts["name"]?.let { "Your name is $it." }
        if (WHAT_GRADE.matches(low)) {
            val hit = facts.entries.firstOrNull { it.key.startsWith("note:") && it.value.startsWith("You are in ") }
            return hit?.value
        }
        WHAT_I.matchEntire(low)?.let { m ->
            val askingAm = m.groupValues[1] == "am i"
            val vp = m.groupValues[2].trim()
            val prefixes = when {
                !askingAm && vp in LIKE_FAMILY -> LIKE_FAMILY.map { "you $it" }
                !askingAm && vp in DISLIKE_FAMILY -> DISLIKE_FAMILY.map { "you $it" }
                askingAm -> listOf("you are $vp")
                else -> listOf("you $vp")
            }
            val hits = facts.entries.filter { e ->
                e.key.startsWith("note:") && prefixes.any { e.value.lowercase().startsWith(it) }
            }
            if (hits.isNotEmpty()) return hits.joinToString(" ") { it.value }
            return null
        }
        ASK_MY.matchEntire(low)?.let { m ->
            val key = topicOf(m.groupValues[1])
            val hit = facts.entries.firstOrNull { !it.key.startsWith("note:") && sameTopic(it.key, key) }
            if (hit != null) return "Your ${hit.key} is ${hit.value}."
            return null
        }
        return null
    }

    private fun store(body: String): String {
        MY_IS.matchEntire(body)?.let { m -> return put(topicOf(m.groupValues[1]), clean(m.groupValues[2])) }
        return noteFact(secondPerson(body))
    }

    private fun put(topic: String, value: String): String {
        if (topic.isEmpty() || value.isEmpty()) return "I could not tell what to remember there."
        return commitAll(listOf(fact(topic, value)))
    }

    private fun noteFact(sentence: String): String = commitAll(listOf(note(sentence)))

    private fun refuse(s: String): String? {
        if (SECRET.containsMatchIn(s.lowercase()) || LONG_DIGITS.containsMatchIn(s.replace(Regex("[ -]"), "")))
            return "I will not store that. Passwords, PINs and card or ID numbers do not belong in a chat assistant."
        return null
    }

    /** "mom" -> "mom"; "moms name" -> "mom"; "favourite song" stays. */
    private fun topicOf(s: String): String {
        var t = s.lowercase().replace(Regex("[\u2018\u2019']"), "").trim()
        t = t.replace(Regex("^(?:the|my)\\s+"), "").replace(Regex("\\s+name$"), "").trim()
        if (t.length > 3 && t.endsWith("s") && t.dropLast(1) in RELATIONS) t = t.dropLast(1)
        return t
    }

    private fun clean(s: String): String = s.trim().trim('"', '\u201C', '\u201D').trim().trimEnd('.', '!').trim()

    private fun sentence(topic: String, value: String): String =
        if (topic.startsWith("note:")) value else "Your $topic is $value."

    /** True when one topic's words are all inside the other's, so "card limit" is not "car". */
    private fun sameTopic(a: String, b: String): Boolean {
        val aw = a.split(' ').filter { it.isNotEmpty() }.toSet()
        val bw = b.split(' ').filter { it.isNotEmpty() }.toSet()
        return aw.isNotEmpty() && bw.isNotEmpty() && (aw.containsAll(bw) || bw.containsAll(aw))
    }

    /** "I am vegetarian" -> "You are vegetarian." */
    private fun secondPerson(s: String): String {
        var t = " " + s.trim() + " "
        for ((from, to) in PERSON) t = t.replace(Regex("(?i)(?<=\\W)" + from + "(?=\\W)"), to)
        t = t.trim()
        t = t.replaceFirstChar { it.uppercase() }
        return if (t.endsWith(".")) t else "$t."
    }

    companion object {
        private const val SEP = "\u001E"
        private const val MAX_FACTS = 60
        private const val MAX_SHOWN = 30
        private const val MAX_INPUT = 300
        private const val MAX_SENTENCES = 5
        private const val FULL = "I am holding as much as I can (60 things). Say \"forget everything about me\" to clear it, or forget one thing."

        private val RELATIONS = setOf(
            "mom", "mother", "mum", "dad", "father", "wife", "husband", "brother", "sister", "boss",
            "friend", "best friend", "partner", "son", "daughter", "girlfriend", "boyfriend", "roommate"
        )

        private const val REL_WORDS = "mom|mother|mum|dad|father|wife|husband|brother|sister|boss|best friend|friend|partner|son|daughter|girlfriend|boyfriend|roommate"
        private const val ORDINALS = "first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth"
        private const val ROLES = "student|learner|beginner|developer|programmer|coder|designer|engineer|teacher|doctor|founder|entrepreneur|writer|artist|musician|gamer|athlete|freelancer|scientist|photographer|blogger|youtuber|cricketer|singer|dancer|chess player|reader|thinker|philosopher"

        private val LIKE_FAMILY = listOf("like", "love", "enjoy", "adore", "prefer", "are into")
        private val DISLIKE_FAMILY = listOf("hate", "dislike", "detest", "cannot stand", "do not like")

        private val SECRET = Regex("\\b(?:password|passcode|pin|otp|cvv|card number|aadhaar|aadhar|pan number|ssn|passport)\\b")
        private val LONG_DIGITS = Regex("\\d{12,}")

        private val FORGET_ALL = Regex(
            "(?i)(?:(?:forget|erase|delete|clear) (?:everything|all)(?: that)?(?: you (?:know|remember))? (?:about me|i told you)" +
                "|(?:forget|erase|clear|delete) (?:my |all )?(?:memory|memories)" +
                "|forget everything)"
        )
        private val FORGET_NUM = Regex("(?:forget|delete|remove|erase) (?:(?:memory|memories|item|number|no|entry|line) ?)*#?(\\d{1,2})")
        private val FORGET_MY = Regex("(?i)(?:forget|delete) my ([a-z' ]{2,30})")
        private val FORGET_THAT = Regex("(?i)forget (?:that |what i said about |about )(.{2,60})")

        // "show memories", "what do you remember", "my memories" ...
        private val LIST_ALL = listOf(
            Regex("(?:show|list|display|read|view|open|see|check|get|give|tell)(?: me)?(?: all)?(?: of)?(?: (?:my|your|the|saved|stored|all))* ?(?:memory|memories)(?: list)?"),
            Regex("(?:(?:my|your|saved|all) )?(?:memory|memories)"),
            Regex("what (?:do|did) you (?:know|remember|have|learn|learnt)(?: saved| stored)?(?: about me)?(?: so far)?"),
            Regex("what have (?:i told you|you (?:saved|stored|remembered|learned|learnt|got))(?: about me)?(?: so far)?"),
            Regex("(?:tell me )?what you (?:know|remember)(?: about me)?"),
            Regex("what(?:s| is) (?:in )?(?:your |my )?(?:memory|memories)"),
            Regex("do you (?:know|remember) me"),
            Regex("(?:show|tell) me (?:about )?(?:myself|what you know)")
        )

        private val WHERE_LIVE = Regex("(?:where do i (?:live|stay)|what city do i live in)")
        private val HOW_OLD = Regex("(?:how old am i|what is my age|whats my age)")
        private val MY_NAME = Regex("(?:what is my name|whats my name|who am i|do you know my name|what do you call me)")
        private val WHAT_GRADE = Regex("(?:(?:what|which) (?:grade|class|standard|std) am i in|what grade am i)")
        private val WHAT_I = Regex("(?:what|which(?: things)?) (do i|am i) ([a-z ]{2,30})")
        private val ASK_MY = Regex("(?:what is|whats|when is|whens|who is|whos|where is|what are) my ([a-z' ]{2,30})")

        private val REMEMBER = Regex("(?i)(?:please )?(?:remember|keep in mind)(?: that)? (.+)")
        private val MY_IS = Regex("(?i)my ([a-z' ]{2,30}?) (?:is|are) (.{1,80})")
        private val REL = Regex("(?i)my ($REL_WORDS)(?:['\u2019]s)?(?: name)? (?:is|is called|are called) (.{1,60})")
        private val PROP = Regex(
            "(?i)my (birthday|bday|anniversary|address|city|hometown|home town|phone number|blood group|job|office|car|bike|pet|dog|cat|" +
                "goal|goals|dream|dreams|aim|ambition|hobby|hobbies|passion|interest|interests|school|college|grade|class|age|nickname|language|languages|" +
                "favou?rite [a-z ]{2,20})(?:['\u2019]s name)? (?:is|are) (.{1,80})"
        )
        private val LIVE = Regex("(?i)i (?:live|stay) in (.{2,40})")
        private val WORK = Regex("(?i)i work (at|for|as|in) (.{2,50})")
        private val FROM = Regex("(?i)i(?:'m|\u2019m| am) from (.{2,40})")
        private val DIET = Regex("(?i)i(?:'m|\u2019m| am) (vegetarian|vegan|eggetarian|jain|allergic to .{2,30}|lactose intolerant|gluten free)")

        // ---- plain statements (sentence already tidied: no final full stop, "I'm" -> "I am")
        private val NAME = Regex("(?i)(?:my name is|i am called|they call me|people call me|everyone calls me) ([a-z][a-z.'-]*(?: [a-z][a-z.'-]*){0,2})")
        private val AGE = Regex("(?i)i am (\\d{1,2})(?: years?(?: |-)old| yrs old)?")
        private val GRADE_A = Regex("(?i)i am (?:currently |now )?(?:studying |reading )?in (?:the )?(\\d{1,2}(?:st|nd|rd|th)?|$ORDINALS)[ -](grade|class|std|standard)(?: student)?(?: at (.{2,40}))?")
        private val GRADE_B = Regex("(?i)i am (?:currently |now )?(?:studying |reading )?in (grade|class|std|standard) (\\d{1,2})(?: at (.{2,40}))?")
        private val ATTEND = Regex("(?i)i (?:study at|attend|am studying at|am a student at) (.{3,50})")
        private val ROLE = Regex("(?i)i am (?:a|an) ((?:[a-z]+ ){0,2}(?:$ROLES))")
        private val LIKES = Regex("(?i)i (?:really |truly |absolutely |just |also |totally )?(love|like|enjoy|adore|prefer|am into|am interested in|am passionate about|am fascinated by|am obsessed with|am a fan of) (.{2,120})")
        private val DISLIKES = Regex("(?i)i (?:really |absolutely |totally )?(?:hate|dislike|detest|cant stand|can't stand|cannot stand|do not like|dont like|don't like) (.{2,120})")
        private val DOING = Regex("(?i)i am (studying|learning|building|developing|practicing|practising|preparing for|working on) (.{2,100})")
        private val GOAL = Regex("(?i)i want to (be|become|learn|build|start|study|master|launch|travel|win|crack|ace|get into|work as|work at) (.{2,100})")
        private val ASPIRE = Regex("(?i)i (dream of|aspire to|plan to|hope to) (.{3,100})")

        private val FILLER = Regex("(?i)^(?:(?:and|also|well|so|actually|btw|by the way|ok|okay|hey yantra|hi yantra|yantra)[ ,]+)+")
        private val IM = Regex("(?i)^i'?m\\b")
        private val QUESTION_START = Regex("(?i)^(?:what|who|whom|whose|when|where|why|how|which|do|does|did|can|could|would|will|is|are|should)\\b")
        private val SPLIT = Regex("(?i)(?<=[.!?])\\s+|\\s*;\\s*|\\s*,?\\s+and\\s+(?=i\\s)|\\s*,\\s+(?=i\\s)")
        private val OBJ_PRONOUN = Regex("(?i)^(?:it|this|that|these|those|them|him|her|us|me|everything|nothing|something|how|the way|when|what|where|why|to be)\\b")
        private val CMD_TAIL = Regex("(?i)(?:,|\\band\\b|\\bthen\\b)\\s*(?:please\\s+)?(?:open|call|play|set|turn|text|send|remind|show|take|launch|search|google|put|switch|start|stop|mute)\\b")

        private val PERSON = listOf(
            "i am" to "you are", "i'm" to "you are", "im" to "you are", "i was" to "you were",
            "i have" to "you have", "i" to "you", "my" to "your", "me" to "you", "mine" to "yours", "myself" to "yourself"
        )
    }
}
