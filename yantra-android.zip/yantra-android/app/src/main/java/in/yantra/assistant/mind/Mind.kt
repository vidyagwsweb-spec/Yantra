package `in`.yantra.assistant.mind

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Anything that can turn a prompt into text. The real one is [in.yantra.assistant.mind.LocalModel]; tests use a fake. */
interface TextModel {
    val ready: Boolean
    val style: PromptStyle
    suspend fun complete(prompt: String): String?
}

/**
 * The thinking layer. It sits behind everything deterministic: the router, the
 * taught shortcuts and the small brain all get first go, and the model only
 * sees what they could not handle.
 *
 * Two jobs:
 *  - [plan]: turn free-form speech into router commands the phone can run, plus a reply.
 *  - [answer]: answer a question, grounded in fetched text when there is some.
 *
 * Whatever the model writes is treated as untrusted. Commands are only kept if the
 * router understands them, and the caller decides which need a confirmation.
 */
object Mind {

    /** Questions worth looking up or answering at length, rather than device commands. */
    private val FACTUAL = Regex(
        "^(?:who|whom|whose|what|when|where|which|why|how (?:many|much|far|long|old|tall|big|fast|come|do|does|did|can|is|are|to)|" +
            "tell me about|explain|describe|define|difference between|is it true|can you explain|compare|should i|is it (?:safe|ok|okay|good|bad)|" +
            "are there|do you know|any idea|suggest|recommend|give me (?:some )?(?:ideas|tips|advice))\\b"
    )

    fun looksFactual(text: String): Boolean = FACTUAL.containsMatchIn(
        text.lowercase().replace(Regex("[\u2018\u2019']"), "").replace(Regex("^(?:hey )?yantra[, ]+"), "").trim()
    )

    fun now(date: Date = Date()): String = SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.ENGLISH).format(date)

    /**
     * Asks the model what to do with [text]. Returns null when the model is not
     * ready, says nothing useful, or only produced commands the router rejects.
     */
    suspend fun plan(
        model: TextModel,
        text: String,
        history: List<Turn>,
        memory: String,
        userName: String,
        isCommand: (String) -> Boolean,
        date: Date = Date()
    ): Plan? {
        if (!model.ready) return null
        val prompt = Prompts.wrap(model.style, Prompts.plan(now(date), userName, memory, history, text))
        val raw = model.complete(prompt) ?: return null
        val parsed = PlanParser.parse(raw)

        // keep only commands the router really understands; anything else the model invented is dropped
        val valid = parsed.commands.filter { isCommand(it) }
        val say = parsed.say
        if (valid.isEmpty() && say.isBlank()) return null
        return Plan(valid, say)
    }

    /** One short answer, from [reference] when given. Null when the model is not ready or wrote nothing. */
    suspend fun answer(
        model: TextModel,
        question: String,
        history: List<Turn>,
        memory: String,
        reference: String?,
        date: Date = Date()
    ): String? {
        if (!model.ready) return null
        val prompt = Prompts.wrap(model.style, Prompts.answer(now(date), memory, history, question, reference))
        val raw = model.complete(prompt) ?: return null
        val text = PlanParser.speechOnly(raw)
        return text.ifBlank { null }
    }
}
