package `in`.yantra.assistant.mind

import `in`.yantra.assistant.router.Parsed

/**
 * What the language model decided: zero or more router commands to run, and
 * something to say. Pure Kotlin, so the parsing is unit-tested on the JVM.
 */
data class Plan(val commands: List<String>, val say: String) {
    val isEmpty: Boolean get() = commands.isEmpty() && say.isBlank()
}

object PlanParser {

    const val MAX_COMMANDS = 3
    private const val MAX_SAY = 600

    private val DO = Regex("^\\s*[-\u2022]?\\s*(?:DO|CMD|COMMAND)\\s*:\\s*(.+?)\\s*$", RegexOption.IGNORE_CASE)
    private val SAY = Regex("^\\s*[-\u2022]?\\s*(?:SAY|REPLY|ANSWER)\\s*:\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val NOTHING = Regex("(?:none|n/a|nothing|-|null)", RegexOption.IGNORE_CASE)
    private val END_TOKENS = Regex("<end_of_turn>|<start_of_turn>|<eos>|<bos>|<\\|im_end\\|>|<\\|im_start\\|>|<\\|endoftext\\|>")

    /**
     * Small models drift from formats, so this is forgiving: DO and SAY lines are
     * picked out wherever they appear, and a reply with no markers at all is
     * treated as plain speech.
     */
    fun parse(raw: String): Plan {
        val text = END_TOKENS.replace(raw, "").replace("```", "").replace("**", "").replace("\r", "")
        val commands = ArrayList<String>()
        val say = StringBuilder()
        var inSay = false
        var sawMarker = false

        for (line in text.lines()) {
            val d = DO.matchEntire(line)
            if (d != null) {
                sawMarker = true
                inSay = false
                val c = tidyCommand(d.groupValues[1])
                if (c.isNotEmpty() && !NOTHING.matches(c) && c !in commands && commands.size < MAX_COMMANDS) commands.add(c)
                continue
            }
            val s = SAY.matchEntire(line)
            if (s != null) {
                sawMarker = true
                inSay = true
                say.append(s.groupValues[1]).append('\n')
                continue
            }
            if (inSay) say.append(line).append('\n')
        }
        if (!sawMarker) say.append(text)
        return Plan(commands, speech(say.toString()))
    }

    /** Just the speech from a model reply that should contain no commands (grounded answers). */
    fun speechOnly(raw: String): String = parse(raw).say

    private fun tidyCommand(s: String): String =
        s.trim().trimEnd('.', ';').trim().trim('"', '\u201C', '\u201D', '\'', '`').trim().trimEnd('.', ';').trim()

    /** Plain words for the screen and the speaker: no markdown, no stray markers, bounded length. */
    fun speech(s: String): String {
        var t = s.replace(Regex("[*_#>`]+"), "")
            .replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
        if (t.length > MAX_SAY) {
            val cut = t.substring(0, MAX_SAY)
            val end = maxOf(cut.lastIndexOf(". "), cut.lastIndexOf("? "), cut.lastIndexOf("! "))
            t = if (end > MAX_SAY / 3) cut.substring(0, end + 1) else cut.trimEnd() + "\u2026"
        }
        return t
    }
}

/** Which commands the model may not run without an explicit yes from the person. */
object Risk {
    fun needsConfirm(p: Parsed): Boolean {
        val a = p.action
        return a.startsWith("call") || a.startsWith("sms") || a.startsWith("whatsapp") ||
            a == "email" || a == "uninstall" || a == "clear-notifications" || a == "list-clear"
    }
}
