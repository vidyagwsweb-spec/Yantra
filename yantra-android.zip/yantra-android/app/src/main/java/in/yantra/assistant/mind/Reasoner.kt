package `in`.yantra.assistant.mind

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * A real calculator for the sentences the router's one-operation patterns cannot
 * take: "(12 + 8) * 3 / 4", "what is 15% of 2400 plus 18%", "square root of 144 times 3".
 *
 * It is a small recursive-descent parser, not eval, so it cannot run anything
 * but arithmetic. Returns null for anything that is not clearly a calculation,
 * so ordinary sentences are never hijacked. Pure Kotlin.
 */
object Reasoner {

    private val LEAD = Regex("^(?:hey yantra |yantra )?(?:please )?(?:what is|whats|what's|calculate|compute|work out|solve|how much is|tell me)\\s+")
    private val TAIL = Regex("\\s*(?:=|\\?)+\\s*$")

    private val WORDS = listOf(
        Regex("\\bsquare root of\\s+(-?\\d+(?:\\.\\d+)?)") to "sqrt($1)",
        Regex("\\b(\\d+(?:\\.\\d+)?)\\s+squared\\b") to "($1)^2",
        Regex("\\b(\\d+(?:\\.\\d+)?)\\s+cubed\\b") to "($1)^3",
        Regex("\\bhalf of\\s+") to "0.5*",
        Regex("\\bdouble\\s+(\\d+(?:\\.\\d+)?)") to "2*$1",
        Regex("\\b(\\d+(?:\\.\\d+)?)\\s*(?:%|percent)\\s+of\\s+") to "($1/100)*",
        Regex("\\bto the power of\\b|\\bpower\\b") to "^",
        Regex("\\bmultiplied by\\b|\\btimes\\b|\\binto\\b|\\bx\\b|\\u00D7") to "*",
        Regex("\\bdivided by\\b|\\bover\\b|\\u00F7") to "/",
        Regex("\\bplus\\b|\\band\\b") to "+",
        Regex("\\bminus\\b|\\bless\\b") to "-",
        Regex("\\bmodulo\\b|\\bmod\\b") to " mod "
    )

    /** "2500 + 18%" means 2500 plus 18 percent of 2500, like a shop calculator. */
    private val ADD_PCT = Regex("^(\\d+(?:\\.\\d+)?)\\s*([+-])\\s*(\\d+(?:\\.\\d+)?)\\s*%$")
    private val DATE_LIKE = Regex("\\b\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}\\b")

    private val ALLOWED = Regex("[0-9+\\-*/^%().\\s]|sqrt|abs|round|floor|ceil|pi|mod")

    /** The answer as a sentence, or null when the text is not a calculation. */
    fun evaluate(raw: String): String? {
        var t = raw.lowercase().replace(Regex("[\u2018\u2019']"), "").trim()
        if (t.isEmpty() || t.length > 160) return null
        t = LEAD.replace(t, "")
        t = TAIL.replace(t, "")
        t = t.replace(Regex("(?<=\\d),(?=\\d{3})"), "")
        for ((re, to) in WORDS) t = re.replace(t, to)
        t = t.replace(Regex("\\b(sqrt|abs|round|floor|ceil)\\s+(\\d+(?:\\.\\d+)?)"), "$1($2)")
        t = ADD_PCT.replace(t) { m -> "${m.groupValues[1]} ${m.groupValues[2]} (${m.groupValues[1]}*${m.groupValues[3]}/100)" }
        t = t.replace(Regex("\\s+"), " ").trim()

        // only arithmetic may remain
        if (DATE_LIKE.containsMatchIn(t)) return null
        if (ALLOWED.replace(t, "").isNotBlank()) return null
        if (!t.any { it.isDigit() }) return null
        // a bare number or a bare phone-number-like string is not a calculation
        if (!Regex("[+\\-*/^%()]|sqrt|abs|round|floor|ceil|pi|mod").containsMatchIn(t.trimStart('-'))) return null

        return try {
            val value = Calc(t).run()
            if (value.isNaN() || value.isInfinite()) "That does not work out to a number."
            else "It is ${format(value)}."
        } catch (e: ArithmeticException) {
            e.message ?: "That does not work out."
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    fun format(v: Double): String {
        val f = DecimalFormat("#,##0.######", DecimalFormatSymbols(Locale.US))
        return f.format(v)
    }

    private class Calc(src: String) {
        private val toks = ArrayList<String>()
        private var i = 0
        private var depth = 0

        init {
            var p = 0
            while (p < src.length) {
                val c = src[p]
                when {
                    c == ' ' -> p++
                    c.isDigit() || c == '.' -> {
                        var q = p
                        while (q < src.length && (src[q].isDigit() || src[q] == '.')) q++
                        toks.add(src.substring(p, q)); p = q
                    }
                    c.isLetter() -> {
                        var q = p
                        while (q < src.length && src[q].isLetter()) q++
                        toks.add(src.substring(p, q)); p = q
                    }
                    else -> { toks.add(c.toString()); p++ }
                }
            }
        }

        fun run(): Double {
            val v = expr()
            if (i != toks.size) throw IllegalArgumentException("trailing")
            return v
        }

        private fun peek(): String? = toks.getOrNull(i)

        private fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    "+" -> { i++; v += term() }
                    "-" -> { i++; v -= term() }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                when (peek()) {
                    "*" -> { i++; v *= unary() }
                    "/" -> { i++; val d = unary(); if (d == 0.0) throw ArithmeticException("I cannot divide by zero."); v /= d }
                    "mod" -> { i++; val d = unary(); if (d == 0.0) throw ArithmeticException("I cannot divide by zero."); v %= d }
                    else -> return v
                }
            }
        }

        private fun unary(): Double {
            if (++depth > 40) throw IllegalArgumentException("too deep")
            try {
                return when (peek()) {
                    "-" -> { i++; -unary() }
                    "+" -> { i++; unary() }
                    else -> power()
                }
            } finally { depth-- }
        }

        private fun power(): Double {
            val base = postfix()
            if (peek() == "^") {
                i++
                val e = unary()
                val r = Math.pow(base, e)
                return r
            }
            return base
        }

        /** "50%" on its own is 0.5. */
        private fun postfix(): Double {
            var v = primary()
            while (peek() == "%") { i++; v /= 100.0 }
            return v
        }

        private fun primary(): Double {
            val t = peek() ?: throw IllegalArgumentException("end")
            i++
            if (t == "(") {
                val v = expr()
                if (peek() != ")") throw IllegalArgumentException("paren")
                i++
                return v
            }
            if (t == "pi") return Math.PI
            if (t[0].isDigit() || t[0] == '.') return t.toDoubleOrNull() ?: throw IllegalArgumentException("number")
            if (t == "sqrt" || t == "abs" || t == "round" || t == "floor" || t == "ceil") {
                if (peek() != "(") throw IllegalArgumentException("call")
                i++
                val v = expr()
                if (peek() != ")") throw IllegalArgumentException("paren")
                i++
                return when (t) {
                    "sqrt" -> { if (v < 0) throw ArithmeticException("There is no real square root of a negative number."); Math.sqrt(v) }
                    "abs" -> Math.abs(v)
                    "round" -> Math.round(v).toDouble()
                    "floor" -> Math.floor(v)
                    else -> Math.ceil(v)
                }
            }
            throw IllegalArgumentException("unexpected $t")
        }
    }
}
