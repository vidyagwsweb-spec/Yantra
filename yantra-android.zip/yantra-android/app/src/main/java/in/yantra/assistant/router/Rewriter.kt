package `in`.yantra.assistant.router

import java.util.Locale

/**
 * Turns the way people actually talk into the shape the router expects.
 *
 * The router is a bank of patterns, so "turn on the flashlight" matches but
 * "turn the flashlight on" does not. Rather than double every pattern, this
 * rewrites the common variations — word order, politeness, synonyms — into the
 * canonical phrasing.
 *
 * It is deliberately conservative: `Router.route` only consults it when the
 * original text produced nothing, so a rewrite can add coverage but can never
 * break a command that already worked.
 */
object Rewriter {

    private class Rule(val re: Regex, val to: String)

    private val RULES: List<Rule> = listOf(
        // ---------------------------------------------------- addressing me
        Rule(Regex("^(?:hey|hi|hello|ok|okay)\\s+(?:yantra|assistant)\\b[,!\\s]*"), ""),
        Rule(Regex("^(?:please|kindly)\\s+"), ""),
        Rule(Regex("^(?:can|could|would|will)\\s+you\\s+(?:please\\s+)?"), ""),
        Rule(Regex("^i\\s+(?:want|need|would\\s+like|d\\s+like)\\s+(?:you\\s+)?to\\s+"), ""),
        Rule(Regex("^(?:do|did)\\s+you\\s+know\\s+"), ""),
        Rule(Regex("^(?:just|quickly|right now)\\s+"), ""),
        Rule(Regex("^(?:tell me|let me know)\\s+"), ""),

        // ------------------------------------------- word order: verb last
        // "turn the flashlight on" -> "turn on flashlight"
        Rule(Regex("^(?:turn|switch|put)\\s+(?:the\\s+|my\\s+)?(.+?)\\s+(on|off)\\s*$"), "turn $2 $1"),

        // "put the brightness to 50%" -> "set brightness to 50%"
        Rule(
            Regex("^(?:put|set|change|make|adjust|bring)\\s+(?:the\\s+|my\\s+)?(brightness|volume|sound|audio|timer|alarm|screen)\\s+(?:to|at|down to|up to)\\s+(.+)$"),
            "set $1 to $2"
        ),

        // ------------------------------------------------ volume / brightness
        Rule(Regex("^(?:make\\s+)?(?:it|the\\s+volume|the\\s+sound|the\\s+audio)\\s+(?:louder|higher|up)\\s*$"), "increase volume"),
        Rule(Regex("^(?:make\\s+)?(?:it|the\\s+volume|the\\s+sound|the\\s+audio)\\s+(?:quieter|lower|down|softer)\\s*$"), "decrease volume"),
        Rule(Regex("^turn\\s+it\\s+up\\s*$"), "increase volume"),
        Rule(Regex("^turn\\s+it\\s+down\\s*$"), "decrease volume"),
        Rule(Regex("^(?:dim|darken)\\s+(?:the\\s+)?(?:screen|display)\\s*$"), "decrease brightness"),
        Rule(Regex("^(?:brighten|lighten)\\s+(?:the\\s+)?(?:screen|display)\\s*$"), "increase brightness"),

        // -------------------------------------------------------- time of day
        Rule(Regex("\\bin the morning\\b"), "am"),
        Rule(Regex("\\b(?:in the evening|in the afternoon|at night)\\b"), "pm"),

        // ------------------------------------------------------------ synonyms
        Rule(Regex("\\btorch\\b"), "flashlight"),
        Rule(Regex("\\b(?:picture|pic|snap)\\b"), "photo"),
        Rule(Regex("\\bmobile data\\b"), "mobile data"),
        Rule(Regex("\\bwi fi\\b"), "wi-fi"),

        // ------------------------------------------------------------- numbers
        // Words first, then the percent sign — otherwise "fifty percent" is
        // still a word when the percent rule runs and nothing matches.
        Rule(Regex("\\ba couple of\\b"), "2"),
        Rule(Regex("\\bforty five\\b"), "45"),
        Rule(Regex("\\btwenty five\\b"), "25"),
        Rule(Regex("\\bfifty\\b"), "50"),
        Rule(Regex("\\bthirty\\b"), "30"),
        Rule(Regex("\\btwenty\\b"), "20"),
        Rule(Regex("\\bfifteen\\b"), "15"),
        Rule(Regex("\\bten\\b"), "10"),
        Rule(Regex("\\b(\\d+)\\s*(?:percent|per cent)\\b"), "$1%"),

        // -------------------------------------------------------- trailing fluff
        Rule(Regex("[\\s,]*(?:please|now|thanks|thank you|for me)\\s*$"), "")
    )

    /** Lowercase and drop apostrophes so the rules stay readable. */
    private fun tidy(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[\u2018\u2019']"), "").trim()

    fun rewrite(input: String): String {
        var out = tidy(input)
        if (out.isEmpty()) return out
        for (rule in RULES) {
            out = rule.re.replace(out, rule.to).trim()
            if (out.isEmpty()) return out
        }
        return out.replace(Regex("\\s+"), " ").trim()
    }
}
