package `in`.yantra.assistant.router

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The result of understanding one command.
 *
 * `action` is the verb the executor switches on. Everything else is a parameter
 * slot that only the relevant actions read. This mirrors the JSON shape the web
 * build used, which keeps the porting obvious and the tests simple.
 */
data class Parsed(
    val action: String,
    val say: String = "",
    val a: String = "",
    val b: String = "",
    val num: Long = 0L,
    val on: Boolean = false,
    val pct: Int = -1,
    val at: Long = 0L
)

/** Everything the router is allowed to know about the world. */
data class Ctx(
    val now: Long = System.currentTimeMillis(),
    val lastUser: String? = null,
    val lastBot: String? = null,
    val lastEventTitle: String? = null,
    val lastEventAt: Long = 0L,
    /** "brightness" or "volume" when that was the last thing adjusted, so "a bit more" knows what to adjust. */
    val lastTarget: String? = null
)

/**
 * Pure command parser. No Android imports, no I/O, no globals — which is why it
 * can be unit tested on the JVM in a few milliseconds.
 */
object Router {

    private val COMMA = Regex("(\\d),(\\d)")
    private val WS = Regex("\\s+")
    private val PUNCT = Regex("[?!,;]+")

    fun normalize(s: String): String = s.lowercase(Locale.ROOT)
        .replace(Regex("[\u2018\u2019']"), "")
        .replace(COMMA, "\$1\$2")
        .replace(PUNCT, " ")
        .replace(WS, " ")
        .trim()

    /**
     * "send a message to X to come to the party at 3 o'clock"
     *   -> who = "x", body = "come to the party at 3 o'clock"
     * The first connector after the recipient starts the body.
     */
    fun splitRecipient(rest: String): Pair<String, String> {
        // padded so a connector at position 0 is still found
        val text = " " + rest.trim() + " "
        val connectors = listOf(" saying ", " that ", " to ", " about ", ": ")
        var at = -1
        var len = 0
        for (c in connectors) {
            val i = text.indexOf(c)
            if (i in 0 until (if (at == -1) Int.MAX_VALUE else at)) {
                at = i
                len = c.length
            }
        }
        return if (at > 0) text.substring(0, at).trim() to text.substring(at + len).trim()
        else if (at == 0) "" to text.substring(len).trim()
        else rest.trim() to ""
    }

    // ------------------------------------------------------------ valley

    private val VALLEY_TAIL = Regex("^(.+?)\\s+(?:on|in|with|using|via|through|inside)\\s+(?:the )?valley(?: browser| app)?$")
    private val VALLEY_HEAD = Regex("^(?:(?:ask|tell|use) )?valley(?: browser)?,? (?:to )?(open|go to|visit|search for|search|google|look up|find) (.+)$")
    private val VALLEY_NEW_TAB = Regex("^(?:open |start |make |create )?(?:a |an |another )?(new tab|new window|private tab|private window|incognito tab|incognito window|private browsing|incognito)$")
    private val VALLEY_OPEN = Regex("^(?:open|go to|goto|visit|launch|load|browse|take me to) (?:the )?(?:website |site |page |url )?(.+)$")
    private val VALLEY_SEARCH = Regex("^(?:search for|search|google|look up|lookup|find|show me) (.+)$")

    /**
     * Anything aimed at the Valley browser. `a` is the text Valley's smart search
     * should get, `b` is "open" (go to a site), "search" or "tab" (just open a tab),
     * `on` means a private tab.
     */
    private fun valleyIntent(t0: String): Parsed? {
        val t = t0.trimEnd('.', ' ')
        val body = VALLEY_TAIL.matchEntire(t)?.groupValues?.get(1)
            ?: VALLEY_HEAD.matchEntire(t)?.let { it.groupValues[1] + " " + it.groupValues[2] }
            ?: return null

        VALLEY_NEW_TAB.matchEntire(body)?.let {
            val w = it.groupValues[1]
            return Parsed("valley", b = "tab", on = w.startsWith("private") || w.startsWith("incognito"))
        }
        VALLEY_OPEN.matchEntire(body)?.let { m ->
            val target = siteWords(m.groupValues[1])
            if (target.isNotEmpty()) return Parsed("valley", a = "open $target", b = "open")
        }
        VALLEY_SEARCH.matchEntire(body)?.let { m ->
            return Parsed("valley", a = m.groupValues[1].trim(), b = "search")
        }
        // "best phones under 20000 on valley": the whole thing is the search
        return Parsed("valley", a = body.trim(), b = "search")
    }

    /**
     * What follows "open": "the amazon website" -> "amazon", and a spoken site name
     * that the recogniser split into words ("maharashtra board solutions") is joined back
     * into one ("maharashtraboardsolutions"), which Valley turns into a .com address.
     */
    internal fun siteWords(raw: String): String {
        var x = raw.trim()
            .replace(Regex("\\s+(?:website|web site|site|webpage|web page|homepage|home page)$"), "")
            .trim()
        val words = x.split(' ').filter { it.isNotEmpty() }
        if (words.size in 2..4 && words.all { Regex("^[a-z0-9]+$").matches(it) }) x = words.joinToString("")
        return x
    }

    private fun messageIntent(channel: String, who: String, body: String): Parsed {
        if (who.isBlank()) return Parsed("say", "Who should I message?")
        val digits = who.replace(Regex("[^\\d+]"), "")
        val bare = digits.replace(Regex("\\D"), "")
        return if (bare.length >= 6) Parsed(channel, a = digits, b = body)
        else Parsed(channel + "-contact", a = who, b = body)
    }

    /** The amount in "by 50%", or the default step when none was given. */
    private fun step(given: String, default: Int): Long =
        (given.toIntOrNull() ?: default).coerceIn(1, 100).toLong()

    private fun whole(t: String, p: String): MatchResult? = Regex(p).matchEntire(t)
    private fun has(t: String, p: String): Boolean = Regex(p).containsMatchIn(t)

    private fun fmtDate(d: Date): String =
        SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(d)

    private fun fmtTime(d: Date): String =
        SimpleDateFormat("h:mm a", Locale.ENGLISH).format(d)

    /** Parses "5 minutes", "1 hour 30 minutes", "two hours". */
    fun durationMs(s: String): Long {
        val words = mapOf(
            "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
            "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
            "twelve" to 12, "fifteen" to 15, "twenty" to 20, "thirty" to 30,
            "forty" to 40, "forty five" to 45, "an" to 1, "a" to 1
        )
        var text = s.replace(Regex("\\bhalf an? hour\\b"), "30 minutes")
        for ((k, v) in words) text = text.replace(Regex("\\b$k\\b"), v.toString())

        var total = 0L
        Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|hr|h|minutes?|mins?|min|m|seconds?|secs?|sec|s)\\b")
            .findAll(text).forEach { mr ->
                val n = mr.groupValues[1].toDouble()
                val unit = mr.groupValues[2]
                total += when {
                    unit.startsWith("h") -> (n * 3_600_000).toLong()
                    unit.startsWith("m") -> (n * 60_000).toLong()
                    else -> (n * 1000).toLong()
                }
            }
        return total
    }

    /** Pulls a clock time out of "6:30 am", "at 17:00", "7pm". */
    fun clockTime(s: String): Pair<Int, Int>? {
        Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)").find(s)?.let { mr ->
            var h = mr.groupValues[1].toInt()
            val m = mr.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = mr.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h in 0..23 && m in 0..59) return h to m
        }
        Regex("(\\d{1,2}):(\\d{2})").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            val m = mr.groupValues[2].toInt()
            if (h in 0..23 && m in 0..59) return h to m
        }
        Regex("(\\d{1,2})\\s*o'?clock").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            if (h in 0..23) return h to 0
        }
        Regex("\\bat\\s+(\\d{1,2})\\b").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            if (h in 0..23) return h to 0
        }
        // "alarm for 7": nothing but an hour
        Regex("^\\s*(\\d{1,2})\\s*$").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            if (h in 0..23) return h to 0
        }
        return null
    }

    private val AGAIN = Regex("^(?:do (?:that|it) again|again|once more|one more time|repeat (?:the )?(?:last )?command|same again)$")
    private val WH = Regex("^(?:who|what|whats|when|where|why|how|which)\\b")
    private val SPLIT = Regex("\\s*(?:,|;|&|\\band then\\b|\\bthen\\b|\\band\\b|\\bafter that\\b|\\balso\\b)\\s*")
    private val VERB_PREFIX = Regex("^(?:please )?((?:turn|switch) (?:on|off)|enable|disable|open|launch|mute|call|increase|decrease|raise|lower|reduce|turn up|turn down|set)\\b")

    /**
     * One command, one result.
     *
     * Tries the text as given, and only if that produces nothing, tries the
     * [Translator]'s version. A translation can therefore add coverage but can
     * never take away a command that already worked. Questions nothing else
     * claimed become a web search.
     */
    fun route(raw: String, ctx: Ctx = Ctx()): Parsed {
        val last = ctx.lastUser
        if (AGAIN.matches(normalize(raw)) && !last.isNullOrBlank())
            return route(last, ctx.copy(lastUser = null))
        val single = routeSingle(raw, ctx)
        if (single.action != "unknown") return single
        return question(raw) ?: single
    }

    /**
     * Like [route], but also understands several commands in one breath:
     * "turn on wifi and bluetooth", "dim the screen then open youtube".
     * A split only counts when every part is understood.
     */
    fun routeAll(raw: String, ctx: Ctx = Ctx()): List<Parsed> {
        val last = ctx.lastUser
        if (AGAIN.matches(normalize(raw)) && !last.isNullOrBlank())
            return routeAll(last, ctx.copy(lastUser = null))
        val single = routeSingle(raw, ctx)
        // these capture "the rest of the sentence", so "open youtube and whatsapp"
        // would otherwise be one app called "youtube and whatsapp"
        if (single.action == "open-app" || single.action == "alarm" || single.action == "timer")
            compound(raw, ctx)?.let { return it }
        if (single.action != "unknown" && single.action != "ask") return listOf(single)
        compound(raw, ctx)?.let { return it }
        if (single.action == "unknown") return listOf(question(raw) ?: single)
        return listOf(single)
    }

    private fun routeSingle(raw: String, ctx: Ctx): Parsed {
        val direct = routeDirect(raw, ctx)
        if (direct.action != "unknown" && direct.action != "ask") return direct
        val alt = Translator.translate(raw, ctx.lastTarget)
        if (alt.isNotEmpty() && alt != normalize(raw)) {
            val second = routeDirect(alt, ctx)
            if (second.action != "unknown" && second.action != "ask") return second
        }
        return direct
    }

    private fun compound(raw: String, ctx: Ctx): List<Parsed>? {
        val parts = raw.lowercase(Locale.ROOT).split(SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size < 2 || parts.size > 4) return null
        val out = ArrayList<Parsed>()
        var verb: String? = null
        for (part in parts) {
            var r = routeSingle(part, ctx)
            // "turn on wifi and bluetooth": the second part borrows the first one's verb
            if (r.action == "unknown" && verb != null) r = routeSingle("$verb $part", ctx)
            if (r.action == "unknown" || r.action == "ask") return null
            out.add(r)
            VERB_PREFIX.find(part)?.let { verb = it.groupValues[1] }
        }
        return out
    }

    private fun question(raw: String): Parsed? {
        val t = normalize(raw)
        if (!WH.containsMatchIn(t) || t.split(' ').size < 3) return null
        return Parsed("search", a = raw.trim().trimEnd('?', '.', '!'))
    }

    private fun routeDirect(raw: String, ctx: Ctx): Parsed {
        val t = normalize(raw)
        if (t.isEmpty()) return Parsed("empty")
        val now = Date(ctx.now)
        val cal = Calendar.getInstance().apply { time = now }

        // ---------------------------------------------------------------- meta
        if (whole(t, "(who are you|what are you|whats your name|are you (?:an? )?(?:ai|robot))") != null)
            return Parsed(
                "say",
                "I am Yantra, a native Android assistant. No language model inside — " +
                    "about 190 patterns wired to real system APIs, plus a small on-device brain for chat."
            )

        if (whole(t, "(help|commands|what can you do|what can you help me with|list commands)") != null)
            return Parsed("help")

        if (whole(t, "how do i (?:float|open you)(?: over (?:other )?apps| anywhere)?|how do i summon you|float over apps") != null)
            return Parsed(
                "say",
                "Add the \"Ask Yantra\" tile in Quick Settings: pull the shade down twice, tap the pencil, drag it in. " +
                    "Or set Yantra as your assistant app in Settings, then use the assistant gesture. " +
                    "Either way the panel opens over whatever you are doing, and closes when you tap outside it."
            )

        if (whole(t, "(hi|hello|hey|namaste|good morning|good afternoon|good evening)") != null)
            return Parsed("say", "Hey. What do you need?")

        if (whole(t, "(thanks|thank you|thx|ok|okay|cool|nice)") != null)
            return Parsed("say", "Anytime.")

        if (whole(t, "(how are you|how are you doing|hows it going|whats up|how do you do)") != null)
            return Parsed("say", "Running fine, thanks. What do you need?")
        if (whole(t, "(good night|goodnight)") != null) return Parsed("say", "Good night.")
        if (whole(t, "(i love you|love you)") != null)
            return Parsed("say", "That is kind. I am only patterns and system calls, but I will take it.")
        if (whole(t, "(?:tell me )?(?:a )?joke|make me laugh|tell me something funny") != null)
            return Parsed("say", JOKES[((ctx.now / 1000L) % JOKES.size).toInt()])

        // ---------------------------------------------------------- valley
        // "open maharashtraboardsolutions on Valley", "search iphone 15 flipkart in valley",
        // "open a private tab in valley". Checked early: "on valley" must not become an app called
        // "x on valley", and a trailing site name must not be eaten by the generic search rule.
        valleyIntent(t)?.let { return it }

        // ----------------------------------------------------------- chance
        if (whole(t, "(?:flip|toss) (?:a )?coin|heads or tails") != null) return Parsed("coin")
        if (whole(t, "(?:roll|throw) (?:a |an |one )?(?:dice|die)") != null)
            return Parsed("dice", num = 6L, pct = 1)
        whole(t, "(?:roll|throw) (\\d{1,2}) (?:dice|dies)")?.let {
            return Parsed("dice", num = 6L, pct = it.groupValues[1].toInt())
        }
        whole(t, "(?:roll|throw) (?:a |an )?d(\\d{1,4})")?.let {
            return Parsed("dice", num = it.groupValues[1].toLong(), pct = 1)
        }
        whole(t, "(?:pick|choose|give me|generate) (?:a )?(?:random )?number (?:between|from) (\\d+) (?:and|to) (\\d+)")?.let {
            return Parsed("random", a = it.groupValues[1], b = it.groupValues[2])
        }
        if (whole(t, "(?:pick|choose|give me|generate) (?:a )?random number|random number") != null)
            return Parsed("random", a = "1", b = "100")
        whole(t, "(?:pick|choose|decide) (?:between |from )?(.+? or .+)")?.let {
            return Parsed("choose", a = it.groupValues[1].split(" or ").joinToString("|") { o -> o.trim() })
        }

        if (whole(t, "(stop|cancel|never ?mind|quiet|shut up|be quiet)") != null)
            return Parsed("stop")

        // -------------------------------------------------------------- memory
        if (whole(t, "(repeat that|say that again|what did you say|come again)") != null)
            return Parsed("say", ctx.lastBot ?: "I have not said anything yet.")

        if (whole(t, "(what did i ask|what was the last thing i asked|my last question)") != null)
            return Parsed(
                "say",
                ctx.lastUser?.let { "You asked: \"$it\"." } ?: "That was your first message."
            )

        // ------------------------------------------------- device: radios on/off
        whole(t, "(?:turn|switch) (on|off) (?:the )?wi-?fi")?.let {
            return Parsed("wifi", a = it.groupValues[1], on = it.groupValues[1] == "on")
        }
        whole(t, "(?:turn|switch) (on|off) (?:the )?bluetooth")?.let {
            return Parsed("bluetooth", a = it.groupValues[1], on = it.groupValues[1] == "on")
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?airplane mode")?.let {
            return Parsed("airplane", on = !t.contains("disable") && !t.contains("off"))
        }
        // "turn on data", "turn off mobile data", "switch on cellular data", "turn on the internet"
        whole(t, "(?:turn|switch) (on|off) (?:the |my )?(?:mobile |cellular )?(?:data|internet)(?: connection)?")?.let {
            return Parsed("mobile-data", on = it.groupValues[1] == "on")
        }

        // ------------------------------------------------------- device: screen
        whole(t, "(?:set )?brightness (?:to )?(\\d{1,3})\\s*%?")?.let {
            return Parsed("brightness", pct = it.groupValues[1].toInt().coerceIn(1, 100))
        }
        // "increase brightness" or "increase brightness by 50%"
        whole(t, "(?:increase|raise|turn up|boost) (?:my |the )?(?:screen )?brightness(?: by (\\d{1,3})\\s*%?)?")?.let {
            return Parsed("brightness-delta", num = step(it.groupValues[1], 20))
        }
        whole(t, "(?:decrease|lower|turn down|reduce) (?:my |the )?(?:screen )?brightness(?: by (\\d{1,3})\\s*%?)?")?.let {
            return Parsed("brightness-delta", num = -step(it.groupValues[1], 20))
        }
        if (whole(t, "(max|maximum) brightness") != null) return Parsed("brightness", pct = 100)
        if (whole(t, "(min|minimum|lowest) brightness") != null) return Parsed("brightness", pct = 5)

        whole(t, "(?:set )?(?:the )?volume (?:to )?(\\d{1,3})\\s*%?")?.let {
            return Parsed("volume", pct = it.groupValues[1].toInt().coerceIn(0, 100))
        }
        whole(t, "(?:increase|raise|turn up|boost) (?:my |the )?volume(?: by (\\d{1,3})\\s*%?)?")?.let {
            return Parsed("volume-delta", num = step(it.groupValues[1], 15))
        }
        whole(t, "(?:decrease|lower|turn down|reduce) (?:my |the )?volume(?: by (\\d{1,3})\\s*%?)?")?.let {
            return Parsed("volume-delta", num = -step(it.groupValues[1], 15))
        }
        if (whole(t, "(?:mute|silence)(?: (?:the )?(?:audio|sound|volume|phone))?") != null)
            return Parsed("volume", pct = 0)
        if (whole(t, "unmute") != null) return Parsed("volume", pct = 60)

        whole(t, "(?:turn|switch) (on|off) (?:the )?(?:camera )?(?:flash|flashlight|torch)")?.let {
            return Parsed("flashlight", on = it.groupValues[1] == "on")
        }
        whole(t, "(?:turn|switch) (on|off) do not disturb")?.let {
            return Parsed("dnd", on = it.groupValues[1] == "on")
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?dark mode")?.let {
            return Parsed("dark-mode", on = !t.contains("disable") && !t.contains("off"))
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?battery saver")?.let {
            return Parsed("battery-saver", on = !t.contains("disable") && !t.contains("off"))
        }

        // ------------------------------------------------ device: more switches
        whole(t, "(?:turn on |enable |switch to |set )?(silent|vibrate|vibration|normal|ring|general) mode")?.let {
            return Parsed("ringer", a = ringerMode(it.groupValues[1]))
        }
        whole(t, "(?:put |set )?(?:my |the )?phone (?:on|to|in) (silent|vibrate|normal|ring)(?: mode)?")?.let {
            return Parsed("ringer", a = ringerMode(it.groupValues[1]))
        }
        whole(t, "(?:turn|switch) (on|off) (?:the )?(?:auto|adaptive|automatic)[ -]?brightness")?.let {
            return Parsed("auto-brightness", on = it.groupValues[1] == "on")
        }
        // "set auto brightness on", "turn auto brightness off", "auto brightness on."
        whole(t, "(?:(?:set|turn|switch|put|keep) )?(?:the )?(?:auto|adaptive|automatic)[ -]?brightness (?:to )?(on|off)\\.?")?.let {
            return Parsed("auto-brightness", on = it.groupValues[1] == "on")
        }
        whole(t, "(?:turn|switch) (on|off) (?:the )?(?:screen |auto[ -]?)?rotat(?:e|ion)")?.let {
            return Parsed("rotate", on = it.groupValues[1] == "on")
        }
        whole(t, "(lock|unlock) (?:the )?(?:screen )?rotation")?.let {
            return Parsed("rotate", on = it.groupValues[1] == "unlock")
        }
        whole(t, "(?:set )?(?:the )?screen (?:timeout|off time|sleep time)(?: to| for)? (.+)|keep (?:the )?screen on for (.+)")?.let {
            val ms = durationMs(it.groupValues[1].ifEmpty { it.groupValues[2] })
            if (ms > 0) return Parsed("screen-timeout", num = ms)
        }
        // Android does not let apps flip these silently, so they open the right page
        whole(t, "(?:turn|switch) (on|off) (?:the )?(location|gps|nfc|hotspot|vpn|cast)")?.let {
            return Parsed("settings", a = it.groupValues[2], b = it.groupValues[1])
        }
        whole(t, "(?:open |show |go to )?(?:the )?(wi-?fi|bluetooth|display|sound|battery|location|nfc|hotspot|data usage|storage|apps|accessibility|language|date and time|keyboard|vpn|cast|security|privacy|developer|about phone) settings")?.let {
            return Parsed("settings", a = it.groupValues[1])
        }

        // -------------------------------------------------------- device: status
        if (has(t, "\\bbattery\\b") && !t.contains("saver") && !t.contains("usage"))
            return Parsed("battery")
        if (has(t, "\\bstorage\\b"))
            return Parsed("storage")
        if (has(t, "network status") || has(t, "internet connection") || has(t, "internet working") ||
            whole(t, "(?:which|what) wi-?fi(?: am i (?:on|connected to))?|wi-?fi name|am i (?:online|connected)(?: to the internet)?") != null
        ) return Parsed("network")
        if (has(t, "device information") || has(t, "device info") || has(t, "what phone is this"))
            return Parsed("device")
        if (has(t, "current location") || whole(t, "where am i") != null)
            return Parsed("location")

        // ------------------------------------------------------------ camera
        if (whole(t, "(?:record|take|shoot|film) (?:a )?video|(?:open )?video camera") != null)
            return Parsed("video")
        if (whole(t, "open (?:the )?camera|take a (?:photo|picture)|take a selfie") != null)
            return Parsed("camera", on = t.contains("selfie"))
        if (whole(t, "(?:take|click) (?:a )?screenshot") != null) return Parsed("say", "Use power + volume down for a screenshot.")

        // ------------------------------------------------------------- apps
        whole(t, "(?:go to |open |visit |browse |load )(?:the )?(?:website |site |url )?((?:https?://)?[a-z0-9-]+(?:\\.[a-z0-9-]+)+(?:/\\S*)?)")?.let {
            return Parsed("url", a = it.groupValues[1])
        }
        whole(t, "(?:uninstall|delete app|remove app) (?:the )?(.+?)(?: app)?")?.let {
            return Parsed("uninstall", a = it.groupValues[1].trim())
        }
        whole(t, "app info (?:for |of )?(?:the )?(.+)|(?:show |open )?(?:the )?(.+?) app info")?.let {
            return Parsed("app-info", a = it.groupValues[1].ifEmpty { it.groupValues[2] }.trim())
        }
        if (whole(t, "(?:clear|dismiss|delete) (?:all )?(?:my )?notifications") != null)
            return Parsed("clear-notifications")
        if (t.startsWith("copy ")) {
            Regex("^\\s*copy\\s+(.+?)(?:\\s+to\\s+(?:the\\s+|my\\s+)?clipboard)?\\s*$", RegexOption.IGNORE_CASE)
                .matchEntire(raw)?.let {
                    val text = it.groupValues[1].trim()
                    if (text.isNotEmpty()) return Parsed("clipboard-copy", a = text)
                }
        }
        if (whole(t, "(?:read|show|whats on|what is on|whats in|what is in|paste) (?:my |the )?clipboard") != null)
            return Parsed("clipboard-read")
        whole(t, "open (?:the )?(.+?)(?: app| application)?")?.let { mr ->
            val target = mr.groupValues[1].trim()
            if (target.isNotEmpty()) return Parsed("open-app", a = target)
        }
        if (whole(t, "(close|quit|exit) (?:the )?(?:current )?(?:app|application)") != null ||
            whole(t, "go home") != null
        ) return Parsed("home")
        if (whole(t, "(?:show|list) (?:my )?(?:installed )?apps") != null) return Parsed("list-apps")

        // ------------------------------------------------------- people
        whole(t, "(?:call|dial|phone) (?!me\\b)(.+)")?.let { mr ->
            val target = mr.groupValues[1].trim()
            if (Regex("\\d{5,}").containsMatchIn(target))
                return Parsed("call", a = target.replace(Regex("[^\\d+]"), ""))
            return Parsed("call-contact", a = target.removeSuffix("'s").trim())
        }
        whole(t, "(?:send (?:a |an )?)?(?:text|sms|message|msg)(?: to)? (.+)")?.let { mr ->
            val (who, body) = splitRecipient(mr.groupValues[1])
            return messageIntent("sms", who, body)
        }
        whole(t, "(?:send (?:a |an )?)?whatsapp(?: to)? (.+)")?.let { mr ->
            val (who, body) = splitRecipient(mr.groupValues[1])
            return messageIntent("whatsapp", who, body)
        }
        whole(t, "(?:send |write |compose )?(?:an? )?email")?.let { return Parsed("email") }
        whole(t, "(?:send (?:an? )?)?(?:email|mail|gmail)(?: to)? (.+)")?.let { mr ->
            val (who, body) = splitRecipient(mr.groupValues[1])
            val addr = spokenEmail(who)
            return if (addr != null) Parsed("email", a = addr, b = body)
            else Parsed("email", b = body)
        }
        whole(t, "(?:find|show) (.+?)'?s? contact")?.let {
            return Parsed("find-contact", a = it.groupValues[1].trim())
        }
        if (whole(t, "(?:read|show) my (?:latest|unread|recent) (?:notifications?|messages?)") != null ||
            whole(t, "(?:read|show) my notifications") != null
        ) return Parsed("read-notifications")

        // ------------------------------------------------------- reminders
        // "remind me to call mom at 5 pm", "remind me at 5 pm to call mom",
        // "remind me in 10 minutes to stretch". Without a task it is a timer (below).
        whole(t, "remind me (?:to |about |that )?(.+)")?.let { mr ->
            val body = mr.groupValues[1]
            val lead = Regex("^((?:at|by|in|after|tomorrow|tonight|today|this (?:morning|afternoon|evening))\\b.*?) to (.+)$").find(body)
            val phrase = if (lead != null) lead.groupValues[2] + " " + lead.groupValues[1] else body
            val (text, at) = whenFrom(phrase, ctx.now)
            if (text.isNotEmpty()) {
                if (at == 0L) return Parsed("ask", "When should I remind you? Try \"remind me to $text at 5 pm\".")
                return Parsed("remind", a = text, at = at)
            }
        }

        // ---------------------------------------------------------- alarms
        whole(t, "(?:set )?(?:an? )?alarm (?:for |at )?(.+)")?.let { mr ->
            val body = mr.groupValues[1]
            val rel = durationMs(body)
            if (rel > 0 && (body.contains("from now") || body.contains("in ")))
                return Parsed("timer", num = rel, a = "alarm")
            val hm = clockTime(body)
            if (hm != null) return Parsed("alarm", num = hm.first.toLong(), pct = hm.second)
            return Parsed("ask", "Give me a time, like \"alarm at 6:30 am\".")
        }
        if (whole(t, "wake me (?:up )?(?:at|in) (.+)") != null) {
            val hm = clockTime(t)
            if (hm != null) return Parsed("alarm", num = hm.first.toLong(), pct = hm.second)
        }
        whole(t, "remind me in (.+)")?.let {
            val ms = durationMs(it.groupValues[1])
            if (ms > 0) return Parsed("timer", num = ms, a = it.groupValues[1])
        }
        whole(t, "(?:set )?(?:a )?timer (?:for )?(.+)")?.let {
            val ms = durationMs(it.groupValues[1])
            if (ms > 0) return Parsed("timer", num = ms, a = it.groupValues[1])
        }
        if (whole(t, "(pause|hold) (?:the )?timer") != null) return Parsed("timer-pause")
        if (whole(t, "(resume|continue) (?:the )?timer") != null) return Parsed("timer-resume")
        if (whole(t, "(cancel|stop|delete) (?:the )?timer") != null) return Parsed("timer-cancel")
        if (whole(t, "how much time is left|time left|how long is left") != null) return Parsed("timer-status")
        if (whole(t, "(?:show|list) (?:my )?alarms|whats my next alarm") != null) return Parsed("alarm-list")
        if (whole(t, "(?:cancel|delete|clear|remove) (?:my |the |all )?(?:alarms?|reminders?)") != null)
            return Parsed("alarm-cancel")

        // ------------------------------------------------------------- media
        if (whole(t, "(?:play|resume|continue|unpause)(?: (?:the |some |my )?(?:music|songs?|audio|playback|media|video))?") != null)
            return Parsed("media", a = "play")
        if (whole(t, "pause(?: (?:the |my )?(?:music|songs?|audio|playback|media|video))?") != null)
            return Parsed("media", a = "pause")
        if (whole(t, "stop (?:the |my )?(?:music|songs?|audio|playback|media|video|playing)") != null)
            return Parsed("media", a = "stop")
        if (whole(t, "(?:play |go to |skip to )?(?:the )?next (?:song|track|one)|skip(?: (?:this|the) (?:song|track))?|next") != null)
            return Parsed("media", a = "next")
        if (whole(t, "(?:play |go to |skip to )?(?:the )?(?:previous|last) (?:song|track|one)|previous|go back(?: a song| a track)?") != null)
            return Parsed("media", a = "previous")

        // -------------------------------------------------------- time and date
        if (whole(t, "what time is it|whats the time|time|current time") != null)
            return Parsed("say", "It is ${fmtTime(now)}.")
        if (whole(t, "what day is it|whats the date|what is the date|todays date") != null)
            return Parsed("say", "Today is ${fmtDate(now)}.")
        whole(t, "what time is it in ([a-z ]+)")?.let {
            return Parsed("world-time", a = it.groupValues[1].trim())
        }
        whole(t, "how many days until (.+)")?.let {
            return Parsed("countdown", a = it.groupValues[1].trim())
        }
        whole(t, "(?:whats |what is |what )(?:the )?(?:day|date)(?: is it| is)? (tomorrow|yesterday)")?.let {
            val ahead = it.groupValues[1] == "tomorrow"
            val c = Calendar.getInstance().apply { time = now; add(Calendar.DAY_OF_YEAR, if (ahead) 1 else -1) }
            return Parsed("say", "${if (ahead) "Tomorrow" else "Yesterday"} is ${fmtDate(c.time)}.")
        }
        whole(t, "(?:what day|what date|whats the date|what is the date)(?: will it be| is it| was it)? (?:in (\\d+) (day|week|month)s?|(\\d+) (day|week|month)s? (ago|from now))")?.let {
            val g = it.groupValues
            val n = g[1].ifEmpty { g[3] }.toInt()
            val unit = g[2].ifEmpty { g[4] }
            val sign = if (g[5] == "ago") -1 else 1
            val field = when (unit) {
                "week" -> Calendar.WEEK_OF_YEAR
                "month" -> Calendar.MONTH
                else -> Calendar.DAY_OF_YEAR
            }
            val c = Calendar.getInstance().apply { time = now; add(field, sign * n) }
            return Parsed("say", "That is ${fmtDate(c.time)}.")
        }
        whole(t, "what time (?:will it be|is it) in (\\d+) (hour|minute)s?")?.let {
            val n = it.groupValues[1].toLong()
            val ms = if (it.groupValues[2] == "hour") n * 3_600_000L else n * 60_000L
            return Parsed("say", "It will be ${fmtTime(Date(ctx.now + ms))}.")
        }

        // ------------------------------------------------------------- maths
        whole(t, "(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*(\\d+(?:\\.\\d+)?)")?.let {
            val p = it.groupValues[1].toDouble()
            val n = it.groupValues[2].toDouble()
            return Parsed("say", "That is ${trim(p / 100.0 * n)}.")
        }
        whole(t, "(?:what is |whats |calculate )?square root of (\\d+(?:\\.\\d+)?)")?.let {
            return Parsed("say", "The square root is ${trim(kotlin.math.sqrt(it.groupValues[1].toDouble()))}.")
        }
        whole(t, "(?:what is |whats |calculate )?([\\d.]+)\\s*([+\\-*/x^])\\s*([\\d.]+)")?.let {
            val a = it.groupValues[1].toDouble()
            val b = it.groupValues[3].toDouble()
            val r = when (it.groupValues[2]) {
                "+" -> a + b
                "-" -> a - b
                "*", "x" -> a * b
                "^" -> Math.pow(a, b)
                else -> if (b != 0.0) a / b else Double.NaN
            }
            if (!r.isNaN()) return Parsed("say", "That is ${trim(r)}.")
        }
        whole(t, "(?:what is |whats |calculate )?cube root of (\\d+(?:\\.\\d+)?)")?.let {
            return Parsed("say", "The cube root is ${trim(Math.cbrt(it.groupValues[1].toDouble()))}.")
        }
        whole(t, "(?:what is |whats |calculate )?(?:the )?tip (?:on|for) (\\d+(?:\\.\\d+)?)(?: at (\\d+(?:\\.\\d+)?)\\s*%?)?")?.let {
            return Parsed("say", tipText(it.groupValues[1].toDouble(), it.groupValues[2].ifEmpty { "10" }.toDouble()))
        }
        whole(t, "(\\d+(?:\\.\\d+)?)\\s*%\\s*tip (?:on|for) (\\d+(?:\\.\\d+)?)")?.let {
            return Parsed("say", tipText(it.groupValues[2].toDouble(), it.groupValues[1].toDouble()))
        }
        whole(t, "split (\\d+(?:\\.\\d+)?) (?:between|among|by|with|for) (\\d+)(?: people| ways| persons)?")?.let {
            val people = it.groupValues[2].toInt()
            if (people > 0) return Parsed("say", "Each person pays ${trim(it.groupValues[1].toDouble() / people)}.")
        }
        whole(t, "(\\d+(?:\\.\\d+)?)\\s*%\\s*(?:off|discount)(?: on| of)? (\\d+(?:\\.\\d+)?)")?.let {
            val price = it.groupValues[2].toDouble()
            val save = price * it.groupValues[1].toDouble() / 100.0
            return Parsed("say", "Final price ${trim(price - save)}. You save ${trim(save)}.")
        }
        whole(t, "(?:what percent|what percentage) is (\\d+(?:\\.\\d+)?) of (\\d+(?:\\.\\d+)?)")?.let {
            val base = it.groupValues[2].toDouble()
            if (base != 0.0) return Parsed("say", "That is ${trim(it.groupValues[1].toDouble() / base * 100.0)}%.")
        }
        whole(t, "(?:convert )?([\\d.]+) (\\w+) (?:to|into|in) (\\w+)")?.let {
            val v = it.groupValues[1].toDouble()
            val from = it.groupValues[2]
            val to = it.groupValues[3]
            val r = convert(v, from, to)
            if (r != null) return Parsed("say", "${it.groupValues[1]} $from is ${trim(r)} $to.")
        }

        // ------------------------------------------------------------- lists
        if (whole(t, "(?:show|read|list) (?:my )?notes") != null) return Parsed("list-show", a = "notes")
        if (whole(t, "(?:clear|delete) (?:my )?notes") != null) return Parsed("list-clear", a = "notes")
        whole(t, "(?:note|remember) (?:that )?(.+)")?.let {
            return Parsed("list-add", a = "notes", b = it.groupValues[1].trim())
        }
        whole(t, "add (.+?) to (?:my |the )?(.+?)(?: list)?")?.let {
            return Parsed("list-add", a = it.groupValues[2].trim(), b = it.groupValues[1].trim())
        }
        // ------------------------------------------------------------- voice
        if (whole(t, "(?:change|switch|try|use|pick|give me|get me)(?: to)?(?: (?:a|an|another|the next|your|the other))?(?: (?:more natural|more human|less robotic|different|other|new|better|natural|nicer|human))? voice|next voice|another voice|different voice|new voice") != null)
            return Parsed("voice", a = "next")
        if (whole(t, "(?:list|show) (?:the |your |all )?voices|what voices (?:do you have|are there)|which voice(?: are you using)?|what voice (?:are you using|is this)") != null)
            return Parsed("voice", a = "list")
        if (whole(t, "(?:install|download|get|add) (?:a |an |some |more |another |new )?(?:better |natural |new |more )?voices?(?: data)?|install (?:text to speech|tts)(?: voices?)?|voice settings|text to speech settings") != null)
            return Parsed("voice", a = "install")
        whole(t, "(?:speak|talk|sound|use) (?:in )?(?:a )?(deeper|lower|higher)(?: voice)?|(?:a )?(deeper|higher) voice")?.let {
            val w = it.groupValues[1].ifEmpty { it.groupValues[2] }
            return Parsed("voice", a = if (w == "higher") "higher" else "deeper")
        }
        if (whole(t, "reset (?:your |the )?voice|default voice") != null) return Parsed("voice", a = "reset")

        whole(t, "(?:show|read|list) (?:my |the )?(.+?)(?: list)?")?.let {
            val name = it.groupValues[1].trim()
            if (name !in setOf("notifications", "messages", "contacts", "apps"))
                return Parsed("list-show", a = name)
        }
        whole(t, "(?:remove|delete) (.+?) from (?:my |the )?(.+?)(?: list)?")?.let {
            return Parsed("list-remove", a = it.groupValues[2].trim(), b = it.groupValues[1].trim())
        }

        // ---------------------------------------------------------- calendar
        if (whole(t, "(?:whats|what is) on my calendar|my agenda|agenda|my schedule") != null)
            return Parsed("agenda")
        whole(t, "(?:add|create|schedule) (?:an? )?(?:event|meeting|appointment|reminder) (.+)")?.let {
            val body = it.groupValues[1]
            val hm = clockTime(body)
            val dayOffset = when {
                body.contains("tomorrow") -> 1
                body.contains("day after tomorrow") -> 2
                else -> 0
            }
            val title = body
                .replace(Regex("\\b(today|tomorrow|day after tomorrow)\\b"), " ")
                .replace(Regex("\\bat \\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?"), " ")
                .replace(Regex("\\b\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)\\b"), " ")
                .replace(Regex("\\bon [a-z]+\\b"), " ")
                .replace(WS, " ").trim()
            val startCal = Calendar.getInstance().apply {
                time = now
                add(Calendar.DAY_OF_YEAR, dayOffset)
                if (hm != null) set(Calendar.HOUR_OF_DAY, hm.first).also { set(Calendar.MINUTE, hm.second) }
                else { set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0) }
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            return Parsed("calendar-add", a = title.ifEmpty { "Event" }, at = startCal.timeInMillis)
        }

        whole(t, "(?:whats|what is) (?:on|in) (?:my |the )?(.+?)(?: list)?")?.let {
            val name = it.groupValues[1].trim()
            if (name !in setOf("calendar", "schedule", "agenda", "screen", "phone", "clipboard"))
                return Parsed("list-show", a = name)
        }

        // ------------------------------------------------------------ weather
        whole(t, "(?:whats |what is )?(?:the )?weather(?: like)?(?: in ([a-z .-]+))?")?.let { mr ->
            return Parsed("weather", a = mr.groupValues[1].trim())
        }
        if (whole(t, "will it rain|is it going to rain") != null) return Parsed("weather", b = "rain")
        if (whole(t, "should i (?:carry|take) an umbrella") != null) return Parsed("weather", b = "rain")

        // ------------------------------------------------------- open / search
        whole(t, "(?:search|google|look up) (?:for )?(.+)")?.let {
            // "google X" and "search the web for X" mean the browser; plain "search for X"
            // and "look up X" are answered in place when a direct answer exists
            val browser = t.startsWith("google") ||
                Regex("^search (?:on )?(?:google|the web|the internet|online)\\b").containsMatchIn(t)
            val query = it.groupValues[1].trim()
                .replace(Regex("^(?:google|the web|the internet|online)(?: for)? "), "")
            return Parsed("search", a = query, b = if (browser) "browser" else "")
        }
        whole(t, "(?:navigate|directions|take me) to (.+)")?.let {
            return Parsed("navigate", a = it.groupValues[1].trim())
        }
        whole(t, "(?:find|show) (?:the )?(?:nearest|nearby) (.+)")?.let {
            return Parsed("nearby", a = it.groupValues[1].trim())
        }
        whole(t, "(?:define|definition of|meaning of) (.+)")?.let {
            return Parsed("search", a = "define " + it.groupValues[1].trim())
        }
        whole(t, "what does (.+) mean")?.let {
            return Parsed("search", a = "meaning of " + it.groupValues[1].trim())
        }
        whole(t, "translate (.+?) (?:to|into) ([a-z]+)")?.let {
            return Parsed("translate", a = it.groupValues[1].trim(), b = it.groupValues[2])
        }
        whole(t, "play (.+?) on (youtube|spotify)")?.let {
            return Parsed("play", a = it.groupValues[1].trim(), b = it.groupValues[2])
        }
        whole(t, "play (.+)")?.let {
            return Parsed("play", a = it.groupValues[1].trim(), b = "youtube")
        }

        // ------------------------------------------------------------- prefs
        whole(t, "call me (.+)")?.let { return Parsed("pref-name", a = it.groupValues[1].trim()) }
        if (whole(t, "use metric units") != null) return Parsed("pref", a = "units", b = "metric")
        if (whole(t, "speak (?:more )?slowly") != null) return Parsed("pref", a = "rate", b = "slow")
        if (whole(t, "speak faster") != null) return Parsed("pref", a = "rate", b = "fast")

        // ----------------------------------------------------------- fallback
        return Parsed("unknown")
    }

    private val JOKES = listOf(
        "I would tell you a UDP joke, but you might not get it.",
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "There are 10 kinds of people: those who understand binary and those who do not.",
        "A SQL query walks into a bar, sees two tables, and asks: can I join you?",
        "Why was the phone wearing glasses? It lost its contacts.",
        "My battery and I have a lot in common. We both give up around four in the afternoon."
    )

    private fun ringerMode(w: String): String = when (w) {
        "silent" -> "silent"
        "vibrate", "vibration" -> "vibrate"
        else -> "normal"
    }

    private fun tipText(bill: Double, pct: Double): String {
        val tip = bill * pct / 100.0
        return "A ${trim(pct)}% tip on ${trim(bill)} is ${trim(tip)}. Total ${trim(bill + tip)}."
    }

    /** "john at example dot com" -> "john@example.com", or null if it is not an address. */
    internal fun spokenEmail(s: String): String? {
        val x = s.trim()
            .replace(Regex("\\s+at\\s+"), "@")
            .replace(Regex("\\s+dot\\s+"), ".")
            .replace(" ", "")
        return if (Regex("^[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+$").matches(x)) x else null
    }

    private val REL_WHEN = Regex("\\s(?:in|after)\\s+((?:\\d+(?:\\.\\d+)?|an?|half an?)\\s*(?:hours?|hrs?|minutes?|mins?)(?:\\s+and\\s+\\d+\\s*(?:minutes?|mins?))?)(?=\\s)")
    private val DAY_WORD = Regex("\\b(day after tomorrow|tomorrow|today|tonight)\\b")
    private val PART_WORD = Regex("\\b(?:this |in the )?(morning|afternoon|evening)\\b")
    private val EXPLICIT_AMPM = Regex("\\d\\s*(?:am|pm)\\b")
    private val TIME_BITS = listOf(
        Regex("\\b(?:at|by)\\s+\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?\\b"),
        Regex("\\b\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)\\b"),
        Regex("\\b\\d{1,2}:\\d{2}\\b"),
        Regex("\\b\\d{1,2}\\s*o'?clock\\b")
    )

    /**
     * Splits "call mom at 5 pm tomorrow" into the task and the moment.
     * The moment is 0 when the text names none.
     */
    internal fun whenFrom(s: String, nowMs: Long): Pair<String, Long> {
        val text = " " + s.trim() + " "

        REL_WHEN.find(text)?.let { m ->
            val ms = durationMs(m.groupValues[1])
            if (ms > 0) return tidyTask(text.removeRange(m.range)) to nowMs + ms
        }

        val day = DAY_WORD.find(text)?.groupValues?.get(1)
        val part = PART_WORD.find(text)?.groupValues?.get(1)
        val hm = clockTime(text)
        if (day == null && part == null && hm == null) return tidyTask(text) to 0L

        val (h0, m) = hm ?: when {
            day == "tonight" -> 21 to 0
            part == "evening" -> 18 to 0
            part == "afternoon" -> 15 to 0
            else -> 9 to 0
        }
        var h = h0
        val late = part == "evening" || part == "afternoon" || day == "tonight"
        if (hm != null && !EXPLICIT_AMPM.containsMatchIn(text) && h < 12 && late) h += 12

        val c = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        when (day) {
            "tomorrow" -> c.add(Calendar.DAY_OF_YEAR, 1)
            "day after tomorrow" -> c.add(Calendar.DAY_OF_YEAR, 2)
            else -> if (c.timeInMillis <= nowMs) c.add(Calendar.DAY_OF_YEAR, 1)
        }

        var rest = text
        DAY_WORD.find(rest)?.let { rest = rest.removeRange(it.range) }
        PART_WORD.find(rest)?.let { rest = rest.removeRange(it.range) }
        for (re in TIME_BITS) rest = re.replace(rest, " ")
        return tidyTask(rest) to c.timeInMillis
    }

    private fun tidyTask(s: String): String =
        s.replace(WS, " ").trim().removePrefix("to ").trim()
            .replace(Regex("\\s+(?:at|by|on|in|for|this)$"), "")

    private fun trim(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "undefined"
        val r = Math.round(d * 1_000_000.0) / 1_000_000.0
        return if (r == Math.floor(r)) r.toLong().toString() else r.toString()
    }

    private fun convert(v: Double, from: String, to: String): Double? {
        val f = from.lowercase(Locale.ROOT)
        val t = to.lowercase(Locale.ROOT)
        // temperature
        val temps = setOf("c", "celsius", "f", "fahrenheit", "k", "kelvin")
        if (f in temps && t in temps) {
            val c = when {
                f.startsWith("c") -> v
                f.startsWith("f") -> (v - 32) * 5 / 9
                else -> v - 273.15
            }
            return when {
                t.startsWith("c") -> c
                t.startsWith("f") -> c * 9 / 5 + 32
                else -> c + 273.15
            }
        }
        val length = mapOf(
            "km" to 1000.0, "kilometre" to 1000.0, "kilometres" to 1000.0, "kilometers" to 1000.0,
            "m" to 1.0, "metre" to 1.0, "metres" to 1.0, "meter" to 1.0, "meters" to 1.0,
            "cm" to 0.01, "mm" to 0.001, "mile" to 1609.344, "miles" to 1609.344, "mi" to 1609.344,
            "ft" to 0.3048, "feet" to 0.3048, "foot" to 0.3048,
            "inch" to 0.0254, "inches" to 0.0254, "in" to 0.0254
        )
        val mass = mapOf(
            "kg" to 1.0, "kilo" to 1.0, "kilos" to 1.0, "g" to 0.001, "gram" to 0.001, "grams" to 0.001,
            "lb" to 0.45359237, "lbs" to 0.45359237, "pound" to 0.45359237, "pounds" to 0.45359237,
            "oz" to 0.0283495
        )
        val volume = mapOf(
            "l" to 1.0, "litre" to 1.0, "litres" to 1.0, "liter" to 1.0, "liters" to 1.0,
            "ml" to 0.001, "gallon" to 3.78541, "gallons" to 3.78541, "pint" to 0.473176, "pints" to 0.473176,
            "cup" to 0.236588, "cups" to 0.236588, "tbsp" to 0.0147868, "tsp" to 0.00492892
        )
        val time = mapOf(
            "second" to 1.0, "seconds" to 1.0, "sec" to 1.0, "secs" to 1.0,
            "minute" to 60.0, "minutes" to 60.0, "min" to 60.0, "mins" to 60.0,
            "hour" to 3600.0, "hours" to 3600.0, "hr" to 3600.0, "hrs" to 3600.0,
            "day" to 86400.0, "days" to 86400.0, "week" to 604800.0, "weeks" to 604800.0
        )
        val data = mapOf(
            "b" to 1.0, "byte" to 1.0, "bytes" to 1.0, "kb" to 1024.0, "mb" to 1048576.0,
            "gb" to 1073741824.0, "tb" to 1099511627776.0
        )
        val speed = mapOf(
            "kmh" to 0.277778, "kph" to 0.277778, "mph" to 0.44704, "mps" to 1.0, "knots" to 0.514444
        )
        if (f in volume && t in volume) return v * volume.getValue(f) / volume.getValue(t)
        if (f in time && t in time) return v * time.getValue(f) / time.getValue(t)
        if (f in data && t in data) return v * data.getValue(f) / data.getValue(t)
        if (f in speed && t in speed) return v * speed.getValue(f) / speed.getValue(t)
        if (f in length && t in length) return v * length.getValue(f) / length.getValue(t)
        if (f in mass && t in mass) return v * mass.getValue(f) / mass.getValue(t)
        return null
    }
}
