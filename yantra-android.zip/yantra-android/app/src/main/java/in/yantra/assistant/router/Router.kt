package `in`.yantra.assistant.router

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The result of understanding one command.
 *
 * `action` is the verb the executor switches on. Everything else is a parameter
 * slot that only the relevant actions read. This mirrors the JSON shape the web
 * build used, which keeps the porting obvious and the tests simple.
 */
data class Parsed(
    val action: String,
    val say: String = "",
    val a: String = "",
    val b: String = "",
    val num: Long = 0L,
    val on: Boolean = false,
    val pct: Int = -1,
    val at: Long = 0L
)

/** Everything the router is allowed to know about the world. */
data class Ctx(
    val now: Long = System.currentTimeMillis(),
    val lastUser: String? = null,
    val lastBot: String? = null,
    val lastEventTitle: String? = null,
    val lastEventAt: Long = 0L
)

/**
 * Pure command parser. No Android imports, no I/O, no globals — which is why it
 * can be unit tested on the JVM in a few milliseconds.
 */
object Router {

    private val COMMA = Regex("(\\d),(\\d)")
    private val WS = Regex("\\s+")
    private val PUNCT = Regex("[?!,;]+")

    fun normalize(s: String): String = s.lowercase(Locale.ROOT)
        .replace(Regex("[\u2018\u2019']"), "")
        .replace(COMMA, "\$1\$2")
        .replace(PUNCT, " ")
        .replace(WS, " ")
        .trim()

    /**
     * "send a message to X to come to the party at 3 o'clock"
     *   -> who = "x", body = "come to the party at 3 o'clock"
     * The first connector after the recipient starts the body.
     */
    fun splitRecipient(rest: String): Pair<String, String> {
        // padded so a connector at position 0 is still found
        val text = " " + rest.trim() + " "
        val connectors = listOf(" saying ", " that ", " to ", " about ", ": ")
        var at = -1
        var len = 0
        for (c in connectors) {
            val i = text.indexOf(c)
            if (i in 0 until (if (at == -1) Int.MAX_VALUE else at)) {
                at = i
                len = c.length
            }
        }
        return if (at > 0) text.substring(0, at).trim() to text.substring(at + len).trim()
        else if (at == 0) "" to text.substring(len).trim()
        else rest.trim() to ""
    }

    private fun messageIntent(channel: String, who: String, body: String): Parsed {
        if (who.isBlank()) return Parsed("say", "Who should I message?")
        val digits = who.replace(Regex("[^\\d+]"), "")
        val bare = digits.replace(Regex("\\D"), "")
        return if (bare.length >= 6) Parsed(channel, a = digits, b = body)
        else Parsed(channel + "-contact", a = who, b = body)
    }

    private fun whole(t: String, p: String): MatchResult? = Regex(p).matchEntire(t)
    private fun has(t: String, p: String): Boolean = Regex(p).containsMatchIn(t)

    private fun fmtDate(d: Date): String =
        SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(d)

    private fun fmtTime(d: Date): String =
        SimpleDateFormat("h:mm a", Locale.ENGLISH).format(d)

    /** Parses "5 minutes", "1 hour 30 minutes", "two hours". */
    fun durationMs(s: String): Long {
        val words = mapOf(
            "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
            "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
            "twelve" to 12, "fifteen" to 15, "twenty" to 20, "thirty" to 30,
            "forty" to 40, "forty five" to 45, "an" to 1, "a" to 1
        )
        var text = s.replace(Regex("\\bhalf an? hour\\b"), "30 minutes")
        for ((k, v) in words) text = text.replace(Regex("\\b$k\\b"), v.toString())

        var total = 0L
        Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|hr|h|minutes?|mins?|min|m|seconds?|secs?|sec|s)\\b")
            .findAll(text).forEach { mr ->
                val n = mr.groupValues[1].toDouble()
                val unit = mr.groupValues[2]
                total += when {
                    unit.startsWith("h") -> (n * 3_600_000).toLong()
                    unit.startsWith("m") -> (n * 60_000).toLong()
                    else -> (n * 1000).toLong()
                }
            }
        return total
    }

    /** Pulls a clock time out of "6:30 am", "at 17:00", "7pm". */
    fun clockTime(s: String): Pair<Int, Int>? {
        Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)").find(s)?.let { mr ->
            var h = mr.groupValues[1].toInt()
            val m = mr.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = mr.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h in 0..23 && m in 0..59) return h to m
        }
        Regex("(\\d{1,2}):(\\d{2})").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            val m = mr.groupValues[2].toInt()
            if (h in 0..23 && m in 0..59) return h to m
        }
        Regex("(\\d{1,2})\\s*o'?clock").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            if (h in 0..23) return h to 0
        }
        Regex("\\bat\\s+(\\d{1,2})\\b").find(s)?.let { mr ->
            val h = mr.groupValues[1].toInt()
            if (h in 0..23) return h to 0
        }
        return null
    }

    fun route(raw: String, ctx: Ctx = Ctx()): Parsed {
        val t = normalize(raw)
        if (t.isEmpty()) return Parsed("empty")
        val now = Date(ctx.now)
        val cal = Calendar.getInstance().apply { time = now }

        // ---------------------------------------------------------------- meta
        if (whole(t, "(who are you|what are you|whats your name|are you (?:an? )?(?:ai|robot))") != null)
            return Parsed(
                "say",
                "I am Yantra, a native Android assistant. No language model inside — " +
                    "about 190 patterns wired to real system APIs."
            )

        if (whole(t, "(help|commands|what can you do|what can you help me with|list commands)") != null)
            return Parsed("help")

        if (whole(t, "(hi|hello|hey|namaste|good morning|good afternoon|good evening)") != null)
            return Parsed("say", "Hey. What do you need?")

        if (whole(t, "(thanks|thank you|thx|ok|okay|cool|nice)") != null)
            return Parsed("say", "Anytime.")

        if (whole(t, "(stop|cancel|never ?mind|quiet|shut up|be quiet)") != null)
            return Parsed("stop")

        // -------------------------------------------------------------- memory
        if (whole(t, "(repeat that|say that again|what did you say|come again)") != null)
            return Parsed("say", ctx.lastBot ?: "I have not said anything yet.")

        if (whole(t, "(what did i ask|what was the last thing i asked|my last question)") != null)
            return Parsed(
                "say",
                ctx.lastUser?.let { "You asked: \"$it\"." } ?: "That was your first message."
            )

        // ------------------------------------------------- device: radios on/off
        whole(t, "(?:turn|switch) (on|off) (?:the )?wi-?fi")?.let {
            return Parsed("wifi", a = it.groupValues[1], on = it.groupValues[1] == "on")
        }
        whole(t, "(?:turn|switch) (on|off) (?:the )?bluetooth")?.let {
            return Parsed("bluetooth", a = it.groupValues[1], on = it.groupValues[1] == "on")
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?airplane mode")?.let {
            return Parsed("airplane", on = !t.contains("disable") && !t.contains("off"))
        }
        whole(t, "(?:turn|switch) (on|off) (?:the )?mobile data")?.let {
            return Parsed("mobile-data", on = it.groupValues[1] == "on")
        }

        // ------------------------------------------------------- device: screen
        whole(t, "(?:set )?brightness (?:to )?(\\d{1,3})\\s*%?")?.let {
            return Parsed("brightness", pct = it.groupValues[1].toInt().coerceIn(1, 100))
        }
        if (whole(t, "(increase|raise|turn up) (?:my |the )?(?:screen )?brightness") != null)
            return Parsed("brightness-delta", num = 20)
        if (whole(t, "(decrease|lower|turn down|reduce) (?:my |the )?(?:screen )?brightness") != null)
            return Parsed("brightness-delta", num = -20)
        if (whole(t, "(max|maximum) brightness") != null) return Parsed("brightness", pct = 100)
        if (whole(t, "(min|minimum|lowest) brightness") != null) return Parsed("brightness", pct = 5)

        whole(t, "(?:set )?(?:the )?volume (?:to )?(\\d{1,3})\\s*%?")?.let {
            return Parsed("volume", pct = it.groupValues[1].toInt().coerceIn(0, 100))
        }
        if (whole(t, "(increase|raise|turn up) (?:my |the )?volume") != null)
            return Parsed("volume-delta", num = 15)
        if (whole(t, "(decrease|lower|turn down|reduce) (?:my |the )?volume") != null)
            return Parsed("volume-delta", num = -15)
        if (whole(t, "(?:mute|silence)(?: (?:the )?(?:audio|sound|volume|phone))?") != null)
            return Parsed("volume", pct = 0)
        if (whole(t, "unmute") != null) return Parsed("volume", pct = 60)

        whole(t, "(?:turn|switch) (on|off) (?:the )?(?:camera )?(?:flash|flashlight|torch)")?.let {
            return Parsed("flashlight", on = it.groupValues[1] == "on")
        }
        whole(t, "(?:turn|switch) (on|off) do not disturb")?.let {
            return Parsed("dnd", on = it.groupValues[1] == "on")
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?dark mode")?.let {
            return Parsed("dark-mode", on = !t.contains("disable") && !t.contains("off"))
        }
        whole(t, "(?:enable|disable|turn on|turn off) (?:the )?battery saver")?.let {
            return Parsed("battery-saver", on = !t.contains("disable") && !t.contains("off"))
        }

        // -------------------------------------------------------- device: status
        if (has(t, "\\bbattery\\b") && !t.contains("saver") && !t.contains("usage"))
            return Parsed("battery")
        if (has(t, "\\bstorage\\b"))
            return Parsed("storage")
        if (has(t, "network status") || has(t, "internet connection") || has(t, "internet working"))
            return Parsed("network")
        if (has(t, "device information") || has(t, "device info") || has(t, "what phone is this"))
            return Parsed("device")
        if (has(t, "current location") || whole(t, "where am i") != null)
            return Parsed("location")

        // ------------------------------------------------------------ camera
        if (whole(t, "open (?:the )?camera|take a (?:photo|picture)|take a selfie") != null)
            return Parsed("camera", on = t.contains("selfie"))
        if (whole(t, "(?:take|click) (?:a )?screenshot") != null) return Parsed("say", "Use power + volume down for a screenshot.")

        // ------------------------------------------------------------- apps
        whole(t, "open (?:the )?(.+?)(?: app| application)?")?.let { mr ->
            val target = mr.groupValues[1].trim()
            if (target.isNotEmpty()) return Parsed("open-app", a = target)
        }
        if (whole(t, "(close|quit|exit) (?:the )?(?:current )?(?:app|application)") != null ||
            whole(t, "go home") != null
        ) return Parsed("home")
        if (whole(t, "(?:show|list) (?:my )?(?:installed )?apps") != null) return Parsed("list-apps")

        // ------------------------------------------------------- people
        whole(t, "(?:call|dial|phone) (?!me\\b)(.+)")?.let { mr ->
            val target = mr.groupValues[1].trim()
            if (Regex("\\d{5,}").containsMatchIn(target))
                return Parsed("call", a = target.replace(Regex("[^\\d+]"), ""))
            return Parsed("call-contact", a = target.removeSuffix("'s").trim())
        }
        whole(t, "(?:send (?:a |an )?)?(?:text|sms|message|msg)(?: to)? (.+)")?.let { mr ->
            val (who, body) = splitRecipient(mr.groupValues[1])
            return messageIntent("sms", who, body)
        }
        whole(t, "(?:send (?:a |an )?)?whatsapp(?: to)? (.+)")?.let { mr ->
            val (who, body) = splitRecipient(mr.groupValues[1])
            return messageIntent("whatsapp", who, body)
        }
        whole(t, "(?:find|show) (.+?)'?s? contact")?.let {
            return Parsed("find-contact", a = it.groupValues[1].trim())
        }
        if (whole(t, "(?:read|show) my (?:latest|unread|recent) (?:notifications?|messages?)") != null ||
            whole(t, "(?:read|show) my notifications") != null
        ) return Parsed("read-notifications")

        // ---------------------------------------------------------- alarms
        whole(t, "(?:set )?(?:an? )?alarm (?:for |at )?(.+)")?.let { mr ->
            val body = mr.groupValues[1]
            val rel = durationMs(body)
            if (rel > 0 && (body.contains("from now") || body.contains("in ")))
                return Parsed("timer", num = rel, a = "alarm")
            val hm = clockTime(body)
            if (hm != null) return Parsed("alarm", num = hm.first.toLong(), pct = hm.second)
            return Parsed("say", "Give me a time, like \"alarm at 6:30 am\".")
        }
        if (whole(t, "wake me (?:up )?(?:at|in) (.+)") != null) {
            val hm = clockTime(t)
            if (hm != null) return Parsed("alarm", num = hm.first.toLong(), pct = hm.second)
        }
        whole(t, "remind me in (.+)")?.let {
            val ms = durationMs(it.groupValues[1])
            if (ms > 0) return Parsed("timer", num = ms, a = it.groupValues[1])
        }
        whole(t, "(?:set )?(?:a )?timer (?:for )?(.+)")?.let {
            val ms = durationMs(it.groupValues[1])
            if (ms > 0) return Parsed("timer", num = ms, a = it.groupValues[1])
        }
        if (whole(t, "(pause|hold) (?:the )?timer") != null) return Parsed("timer-pause")
        if (whole(t, "(resume|continue) (?:the )?timer") != null) return Parsed("timer-resume")
        if (whole(t, "(cancel|stop|delete) (?:the )?timer") != null) return Parsed("timer-cancel")
        if (whole(t, "how much time is left|time left|how long is left") != null) return Parsed("timer-status")
        if (whole(t, "(?:show|list) (?:my )?alarms|whats my next alarm") != null) return Parsed("alarm-list")

        // -------------------------------------------------------- time and date
        if (whole(t, "what time is it|whats the time|time|current time") != null)
            return Parsed("say", "It is ${fmtTime(now)}.")
        if (whole(t, "what day is it|whats the date|what is the date|todays date") != null)
            return Parsed("say", "Today is ${fmtDate(now)}.")
        whole(t, "what time is it in ([a-z ]+)")?.let {
            return Parsed("world-time", a = it.groupValues[1].trim())
        }
        whole(t, "how many days until (.+)")?.let {
            return Parsed("countdown", a = it.groupValues[1].trim())
        }

        // ------------------------------------------------------------- maths
        whole(t, "(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*(\\d+(?:\\.\\d+)?)")?.let {
            val p = it.groupValues[1].toDouble()
            val n = it.groupValues[2].toDouble()
            return Parsed("say", "That is ${trim(p / 100.0 * n)}.")
        }
        whole(t, "(?:what is |whats |calculate )?square root of (\\d+(?:\\.\\d+)?)")?.let {
            return Parsed("say", "The square root is ${trim(kotlin.math.sqrt(it.groupValues[1].toDouble()))}.")
        }
        whole(t, "(?:what is |whats |calculate )?([\\d.]+)\\s*([+\\-*/x])\\s*([\\d.]+)")?.let {
            val a = it.groupValues[1].toDouble()
            val b = it.groupValues[3].toDouble()
            val r = when (it.groupValues[2]) {
                "+" -> a + b
                "-" -> a - b
                "*", "x" -> a * b
                else -> if (b != 0.0) a / b else Double.NaN
            }
            if (!r.isNaN()) return Parsed("say", "That is ${trim(r)}.")
        }
        whole(t, "(?:convert )?([\\d.]+) (\\w+) (?:to|into|in) (\\w+)")?.let {
            val v = it.groupValues[1].toDouble()
            val from = it.groupValues[2]
            val to = it.groupValues[3]
            val r = convert(v, from, to)
            if (r != null) return Parsed("say", "${it.groupValues[1]} $from is ${trim(r)} $to.")
        }

        // ------------------------------------------------------------- lists
        if (whole(t, "(?:show|read|list) (?:my )?notes") != null) return Parsed("list-show", a = "notes")
        if (whole(t, "(?:clear|delete) (?:my )?notes") != null) return Parsed("list-clear", a = "notes")
        whole(t, "(?:note|remember) (?:that )?(.+)")?.let {
            return Parsed("list-add", a = "notes", b = it.groupValues[1].trim())
        }
        whole(t, "add (.+?) to (?:my |the )?(.+?)(?: list)?")?.let {
            return Parsed("list-add", a = it.groupValues[2].trim(), b = it.groupValues[1].trim())
        }
        whole(t, "(?:show|read|list) (?:my |the )?(.+?)(?: list)?")?.let {
            val name = it.groupValues[1].trim()
            if (name !in setOf("notifications", "messages", "contacts", "apps"))
                return Parsed("list-show", a = name)
        }
        whole(t, "(?:remove|delete) (.+?) from (?:my |the )?(.+?)(?: list)?")?.let {
            return Parsed("list-remove", a = it.groupValues[2].trim(), b = it.groupValues[1].trim())
        }

        // ---------------------------------------------------------- calendar
        if (whole(t, "(?:whats|what is) on my calendar|my agenda|agenda|my schedule") != null)
            return Parsed("agenda")
        whole(t, "(?:add|create|schedule) (?:an? )?(?:event|meeting|appointment|reminder) (.+)")?.let {
            val body = it.groupValues[1]
            val hm = clockTime(body)
            val dayOffset = when {
                body.contains("tomorrow") -> 1
                body.contains("day after tomorrow") -> 2
                else -> 0
            }
            val title = body
                .replace(Regex("\\b(today|tomorrow|day after tomorrow)\\b"), " ")
                .replace(Regex("\\bat \\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?"), " ")
                .replace(Regex("\\b\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)\\b"), " ")
                .replace(Regex("\\bon [a-z]+\\b"), " ")
                .replace(WS, " ").trim()
            val startCal = Calendar.getInstance().apply {
                time = now
                add(Calendar.DAY_OF_YEAR, dayOffset)
                if (hm != null) set(Calendar.HOUR_OF_DAY, hm.first).also { set(Calendar.MINUTE, hm.second) }
                else { set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0) }
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            return Parsed("calendar-add", a = title.ifEmpty { "Event" }, at = startCal.timeInMillis)
        }

        // ------------------------------------------------------------ weather
        whole(t, "(?:whats |what is )?(?:the )?weather(?: like)?(?: in ([a-z .-]+))?")?.let { mr ->
            return Parsed("weather", a = mr.groupValues[1].trim())
        }
        if (whole(t, "will it rain|is it going to rain") != null) return Parsed("weather", b = "rain")
        if (whole(t, "should i (?:carry|take) an umbrella") != null) return Parsed("weather", b = "rain")

        // ------------------------------------------------------- open / search
        whole(t, "(?:search|google|look up) (?:for )?(.+)")?.let {
            return Parsed("search", a = it.groupValues[1].trim())
        }
        whole(t, "(?:navigate|directions|take me) to (.+)")?.let {
            return Parsed("navigate", a = it.groupValues[1].trim())
        }
        whole(t, "(?:find|show) (?:the )?(?:nearest|nearby) (.+)")?.let {
            return Parsed("nearby", a = it.groupValues[1].trim())
        }
        if (whole(t, "play some music|play music") != null) return Parsed("open-app", a = "youtube")

        // ------------------------------------------------------------- prefs
        whole(t, "call me (.+)")?.let { return Parsed("pref-name", a = it.groupValues[1].trim()) }
        if (whole(t, "use metric units") != null) return Parsed("pref", a = "units", b = "metric")
        if (whole(t, "speak (?:more )?slowly") != null) return Parsed("pref", a = "rate", b = "slow")
        if (whole(t, "speak faster") != null) return Parsed("pref", a = "rate", b = "fast")

        // ----------------------------------------------------------- fallback
        return Parsed("unknown")
    }

    private fun trim(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "undefined"
        val r = Math.round(d * 1_000_000.0) / 1_000_000.0
        return if (r == Math.floor(r)) r.toLong().toString() else r.toString()
    }

    private fun convert(v: Double, from: String, to: String): Double? {
        val f = from.lowercase(Locale.ROOT)
        val t = to.lowercase(Locale.ROOT)
        // temperature
        val temps = setOf("c", "celsius", "f", "fahrenheit", "k", "kelvin")
        if (f in temps && t in temps) {
            val c = when {
                f.startsWith("c") -> v
                f.startsWith("f") -> (v - 32) * 5 / 9
                else -> v - 273.15
            }
            return when {
                t.startsWith("c") -> c
                t.startsWith("f") -> c * 9 / 5 + 32
                else -> c + 273.15
            }
        }
        val length = mapOf(
            "km" to 1000.0, "kilometre" to 1000.0, "kilometres" to 1000.0, "kilometers" to 1000.0,
            "m" to 1.0, "metre" to 1.0, "metres" to 1.0, "meter" to 1.0, "meters" to 1.0,
            "cm" to 0.01, "mm" to 0.001, "mile" to 1609.344, "miles" to 1609.344, "mi" to 1609.344,
            "ft" to 0.3048, "feet" to 0.3048, "foot" to 0.3048,
            "inch" to 0.0254, "inches" to 0.0254, "in" to 0.0254
        )
        val mass = mapOf(
            "kg" to 1.0, "kilo" to 1.0, "kilos" to 1.0, "g" to 0.001, "gram" to 0.001, "grams" to 0.001,
            "lb" to 0.45359237, "lbs" to 0.45359237, "pound" to 0.45359237, "pounds" to 0.45359237,
            "oz" to 0.0283495
        )
        if (f in length && t in length) return v * length.getValue(f) / length.getValue(t)
        if (f in mass && t in mass) return v * mass.getValue(f) / mass.getValue(t)
        return null
    }
}
