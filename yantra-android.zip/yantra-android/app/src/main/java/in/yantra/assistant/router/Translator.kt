package `in`.yantra.assistant.router

import java.util.Locale

/**
 * Translates the way people actually talk into the canonical phrasing the
 * [Router] understands.
 *
 *   "increase the brightness by fifty percent"  -> "increase brightness by 50%"
 *   "it's a bit too loud"                       -> "decrease volume by 10%"
 *   "set an alarm for half past six"            -> "set an alarm for 6:30"
 *   "brigtness to 40"                           -> "set brightness to 40%"
 *   "a bit more"            (after a volume command) -> "increase volume by 10%"
 *
 * Pure Kotlin, no Android imports, so it is unit-tested on the JVM.
 *
 * The router only consults this when its own patterns found nothing, so the
 * translator can add coverage but can never break a command that already worked.
 *
 * Pipeline:
 *   1. tidy          lowercase, strip apostrophes and punctuation
 *   2. typos         "brigtness" -> "brightness" (keyword vocabulary only)
 *   3. numbers       "twenty five" -> 25, "fifty percent" -> 50%
 *   4. spoken times  "half past six" -> "6:30", "noon" -> "12 pm"
 *   5. spoken urls   "youtube dot com" -> "youtube.com"
 *   6. follow-ups    "a bit more", "set it to 40" (needs the last target)
 *   7. Rewriter      politeness, word order, synonyms
 *   8. aliases       dnd, bt, flight mode, torch...
 *   9. indirect      "too loud", "I can't see anything"
 *  10. levels        brightness / volume: absolute, relative, qualitative
 *  11. phrases       "how much charge do I have" -> "battery"
 *  12. toggles       "wifi on", "disable bluetooth" -> "turn off bluetooth"
 */
object Translator {

    private class Rule(val re: Regex, val to: String)

    // ------------------------------------------------------------ numbers

    private val UNITS = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
        "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15,
        "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19
    )
    private val TENS = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    private val HYPHEN_NUM = Regex("\\b(twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)-(one|two|three|four|five|six|seven|eight|nine)\\b")
    private val PERCENT = Regex("(\\d+)\\s*(?:percent|per cent|percentage|pct)\\b")
    private val SPACED_PCT = Regex("(\\d)\\s+%")
    private val QUARTER = Regex("\\b(?:a )?quarter\\b(?! (?:past|to))")
    private val THREE_QUARTERS = Regex("\\bthree quarters\\b")

    // -------------------------------------------------------- spoken times

    private val AMPM_DOTS = Regex("(\\d)\\s*([ap])\\.m\\.?")
    private val HALF_PAST = Regex("\\bhalf past (\\d{1,2})\\b")
    private val QUARTER_PAST = Regex("\\bquarter past (\\d{1,2})\\b")
    private val QUARTER_TO = Regex("\\bquarter to (\\d{1,2})\\b")
    private val NOON = Regex("\\b(?:noon|midday)\\b")
    private val MIDNIGHT = Regex("\\bmidnight\\b")
    private val SPLIT_TIME = Regex("\\b(\\d{1,2}) (\\d{2}) (am|pm)\\b")
    private val DOT_COM = Regex("\\b([a-z0-9-]+) dot (com|org|net|in|io|co|app|dev|edu|gov|ai)\\b")

    // ------------------------------------------------- level vocabulary

    private val BRIGHT = Regex("\\b(?:brightness|screen|display|backlight)\\b")
    private val BRIGHT_IMPLICIT = Regex("\\b(?:brighter|brighten|dimmer|dim|darken)\\b")
    private val VOLUME = Regex("\\b(?:volume|sound|audio|music|media)\\b")
    private val VOLUME_IMPLICIT = Regex("\\b(?:louder|quieter|softer)\\b")

    private val DIR_UP = Regex("\\b(?:increase|raise|boost|bump up|bump|turn up|crank up|pump up|ramp up|dial up|up|lift|higher|more|brighter|brighten|louder)\\b")
    private val DIR_DOWN = Regex("\\b(?:decrease|lower|reduce|drop|cut|dim|dimmer|darken|turn down|tone down|dial down|down|quieter|softer|less)\\b")

    private val TO_ABS = Regex("\\b(?:to|at|equals?)\\s+(?:about\\s+|around\\s+|roughly\\s+)?(?:\\d|half|max|maximum|full|min|minimum|lowest|highest)")
    private val BY_HALF = Regex("\\bby half\\b")
    private val NOTCH = Regex("(\\d{1,3})\\s*(?:levels?|notches?|steps?|bars?|clicks?)\\b")
    private val MAXW = Regex("\\b(?:max|maximum|maxed|full|fully|highest|all the way)\\b")
    private val MINW = Regex("\\b(?:min|minimum|lowest)\\b")
    private val HALF = Regex("\\bhalf\\b")
    private val SMALL = Regex("\\b(?:a little|a bit|a touch|a tad|slightly|little|bit)\\b")
    private val LARGE = Regex("\\b(?:a lot|lot|much|way|significantly|massively)\\b")

    private val NUM_PCT = Regex("(\\d{1,3})\\s*%")
    private val NUM_PREP = Regex("\\b(?:to|at|by)\\s+(?:about\\s+|around\\s+)?(\\d{1,3})\\b")
    private val NUM_ANY = Regex("\\b(\\d{1,3})\\b")

    // "how do I make the screen brighter" is a question, not a command
    private val QUESTION = Regex("^(?:how|why|what|whats|when|where|who|which|is|are|does|do|did)\\b")
    // never steal a command that is really about something else
    private val UNRELATED = Regex("\\b(?:alarm|timer|remind|reminder|call|text|message|whatsapp|note|event|calendar|timeout|rotation|rotate|record|recording|cast|mirror|saver|lock|sleep|email|mail)\\b")

    // ------------------------------------------- follow-ups and indirect asks

    private val FOLLOW = Regex("^(?:(?:turn|make|bump|take|put|go) it |go |just |even |slightly |much |a (?:little |bit |lot )?)*(more|less|up|down|higher|lower)(?: (?:a )?(?:little|bit|lot|notch))?$")
    private val FOLLOW_NUM = Regex("^(\\d{1,3})\\s*%?\\s*(more|less|higher|lower)$")
    private val SET_IT = Regex("^(?:set|put|make|change|bring) it (?:to|at) (\\d{1,3})\\s*%?$")

    private val TOO_BRIGHT = Regex("\\b(?:too|so|way too|much too|really|very) (?:bright|glaring)\\b|\\bblinding\\b|\\bhurts? my eyes\\b|\\bburning my eyes\\b")
    private val TOO_DARK = Regex("\\b(?:too|so) (?:dark|dim)\\b|\\b(?:cant|cannot|hard to|difficult to|unable to) see\\b|\\bscreen (?:is )?(?:so |too |very )?(?:dark|dim)\\b")
    private val TOO_LOUD = Regex("\\b(?:too|so|way too|much too|really|very) (?:loud|noisy)\\b|\\bdeafening\\b|\\bhurts? my ears\\b")
    private val TOO_QUIET = Regex("\\b(?:too|so) (?:quiet|soft|low|faint)\\b|\\b(?:cant|cannot|hard to|difficult to|unable to) hear\\b|\\bbarely hear\\b")
    private val WAY_TOO = Regex("\\b(?:way too|much too|so)\\b")

    // ---------------------------------------------------------------- typos

    /** Only distinctive command words. Ordinary English is deliberately absent. */
    private val VOCAB = listOf(
        "brightness", "brighter", "brighten", "darken", "dimmer", "volume", "louder", "quieter",
        "bluetooth", "flashlight", "airplane", "battery", "calendar", "notification", "notifications",
        "screenshot", "timer", "alarm", "weather", "camera", "message", "silent", "vibrate",
        "increase", "decrease", "reduce", "enable", "disable", "remind", "reminder", "youtube",
        "whatsapp", "settings", "tomorrow", "tonight", "location", "rotation", "hotspot",
        "clipboard", "uninstall", "contact", "contacts", "navigate", "directions", "mobile",
        "storage", "network", "music", "translate", "flashlight"
    ).distinct()
    private val VOCAB_SET = VOCAB.toSet()

    /** Real words one edit away from a keyword. "12 times 7" must not become "12 timer 7". */
    private val PROTECTED = setOf("times", "timed")

    // ------------------------------------------------------------ vocabulary

    private val ALIASES = listOf(
        Rule(Regex("\\bdnd\\b"), "do not disturb"),
        Rule(Regex("\\bbt\\b"), "bluetooth"),
        Rule(Regex("\\bblue tooth\\b"), "bluetooth"),
        Rule(Regex("\\baeroplane\\b"), "airplane"),
        Rule(Regex("\\bflight mode\\b"), "airplane mode"),
        Rule(Regex("\\b(?:night mode|dark theme|night theme)\\b"), "dark mode"),
        Rule(Regex("\\b(?:personal hotspot|wi-?fi hotspot|mobile hotspot|tethering)\\b"), "hotspot"),
        Rule(Regex("\\b(?:cellular data|mobile network|data connection|internet data)\\b"), "mobile data"),
        Rule(Regex("\\b(?:torchlight|lamp)\\b"), "flashlight"),
        Rule(Regex("\\b(?:auto[ -]?rotat(?:e|ion)|autorotate|screen rotation)\\b"), "auto rotate"),
        Rule(Regex("\\b(?:adaptive|automatic) brightness\\b"), "auto brightness")
    )

    // "you sound robotic" is a request for a different voice. These run before the
    // level logic, because "make you sound more human" contains "sound" and "more".
    private val VOICE_RULES = listOf(
        Rule(Regex("^(?:make )?(?:you|it|your voice) sounds? (?:more )?(?:human|natural|real|less robotic|better|nicer)$"), "change voice"),
        Rule(Regex("^(?:you sound|your voice (?:is|sounds)|this voice (?:is|sounds)|the voice (?:is|sounds)) (?:too |so |very |really )?(?:robotic|robot-?like|mechanical|flat|fake|artificial|monotone|boring|weird)$"), "change voice"),
        Rule(Regex("^i (?:hate|dislike|do not like|dont like) (?:this|your|the) voice$"), "change voice")
    )

    // Whole-phrase rewrites. First match wins; every pattern is anchored.
    private val PHRASE_RULES = listOf(
        // ---- timers
        Rule(Regex("^(?:set |start |create |make )?(?:a |an )?(\\d+(?:\\.\\d+)?)[ -]?(second|sec|minute|min|hour|hr)s?[ -]timer$"), "set a timer for $1 $2s"),
        Rule(Regex("^(?:start|begin|create|make|put on|put)\\s+(?:me\\s+)?(?:an?\\s+)?(timer|alarm)\\b\\s*(.*)$"), "set a $1 $2"),
        Rule(Regex("^(?:time me for|count ?down (?:for |from )?)\\s*(.+)$"), "set a timer for $1"),

        // ---- spoken arithmetic: "5 plus 3" -> "5 + 3"
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) (?:plus|added to) (\\d+(?:\\.\\d+)?)$"), "$1 + $2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) (?:minus|subtract|take away) (\\d+(?:\\.\\d+)?)$"), "$1 - $2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) (?:times|multiplied by|into) (\\d+(?:\\.\\d+)?)$"), "$1 * $2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) (?:divided by|over|upon) (\\d+(?:\\.\\d+)?)$"), "$1 / $2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) (?:to the power of|to the power|raised to|power) (\\d+(?:\\.\\d+)?)$"), "$1 ^ $2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) squared$"), "$1 ^ 2"),
        Rule(Regex("^(?:what is |whats |calculate )?(\\d+(?:\\.\\d+)?) cubed$"), "$1 ^ 3"),
        // "how many minutes in 3 hours" -> "3 hours to minutes"
        Rule(Regex("^how many (\\w+) (?:are )?(?:there )?in (\\d+(?:\\.\\d+)?) (\\w+)$"), "$2 $3 to $1"),

        // ---- weather, battery, storage, time, location, network
        Rule(Regex("^(?:hows the weather|how is the weather|hows it outside|how is it outside|whats it like outside|weather today|weather forecast|weather report|forecast|todays weather|todays forecast)$"), "weather"),
        Rule(Regex("^(?:whats|what is) (?:the )?weather(?: like)?(?: (?:today|outside|right now|now|like outside))?$"), "weather"),
        Rule(Regex("^(?:weather|forecast)(?: forecast| report)? (?:for|at|of) (.+)$"), "weather in $1"),
        Rule(Regex("^(?:is it (?:going|gonna) to rain|will it (?:rain|pour|drizzle)|is it gonna rain|do i need (?:an )?umbrella|do i need a raincoat|should i (?:bring|carry|take) an umbrella)(?: .*)?$"), "will it rain"),
        Rule(Regex("^(?:how much (?:battery|charge|juice|power)(?: (?:do i have|is left|left|remaining))?|is my phone charging|am i charging|how charged am i|battery level|battery percentage|battery status)$"), "battery"),
        Rule(Regex("^how much (?:space|storage|memory|room)(?: (?:do i have|is left|left|free|available))?$"), "storage"),
        Rule(Regex("^(?:got the time|do you have the time|time please|tell the time|what is the time now|whats the time now)$"), "what time is it"),
        Rule(Regex("^(?:whats my location|my location|where am i right now|where exactly am i)$"), "where am i"),
        Rule(Regex("^(?:(?:which|what) (?:wi-?fi|network)(?: am i (?:on|connected to))?|wi-?fi name|am i (?:online|connected)(?: to the internet)?)$"), "network status"),

        // ---- places
        Rule(Regex("^(?:how (?:do|can) i get to|route to|way to|guide me to|navigate me to|drive me to|get me to)\\s+(.+)$"), "navigate to $1"),
        Rule(Regex("^(?:find|show|where(?:s| is| can i find)?)\\s+(?:me\\s+)?(?:an?\\s+|the\\s+)?(.+?)\\s+near\\s+(?:me|here|by)$"), "find nearest $1"),
        Rule(Regex("^(?:nearest|nearby|closest)\\s+(.+)$"), "find nearest $1"),

        // ---- opening things
        Rule(Regex("^(?:launch|fire up|bring up|pull up|run|start|load)\\s+(?!an?\\s|\\d|timer|alarm|music|song|video|playing|the timer)(?:the\\s+)?(.+?)(?:\\s+app)?$"), "open $1"),

        // ---- people
        Rule(Regex("^(?:ring|buzz|phone up|call up|give (?:a )?call to|give (?:a )?ring to)\\s+(.+)$"), "call $1"),
        Rule(Regex("^(?:ping|dm|drop (?:a )?(?:message|text|line) to|shoot (?:a )?(?:message|text) to|write to)\\s+(.+)$"), "message $1"),
        Rule(Regex("^(?:mail|drop (?:an )?email to|write an email to|compose an email to)\\s+(.+)$"), "email $1"),

        // ---- camera
        Rule(Regex("^(?:click|snap|capture|shoot)\\s+(?:me\\s+)?(?:an?\\s+)?(photo|selfie)$"), "take a $1"),
        Rule(Regex("^(?:film|capture)\\s+(?:a\\s+)?video$"), "record a video"),

        // ---- sound profile
        Rule(Regex("^(?:put|set|switch|turn)\\s+(?:my |the )?phone\\s+(?:on|to|in)\\s+(silent|vibrate|vibration|normal|ring)(?: mode)?$"), "$1 mode"),
        Rule(Regex("^(?:go|switch)\\s+(?:to\\s+)?(silent|vibrate|normal)(?: mode)?$"), "$1 mode"),
        Rule(Regex("^(?:enable|turn on|activate|switch to)\\s+(silent|vibrate|vibration|normal|ring|general) mode$"), "$1 mode"),
        Rule(Regex("^(silent|vibrate|vibration)$"), "$1 mode"),

        // ---- the phone's light is the flashlight
        Rule(Regex("^turn (on|off) (?:the )?(?:phone )?light$"), "turn $1 flashlight")
    )

    private val TOGGLE_RULES = listOf(
        Rule(Regex("^(?:enable|activate|start|switch on|power on)\\s+(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver|hotspot|location|gps|nfc|vpn|cast|auto rotate|auto brightness|rotation)$"), "turn on $1"),
        Rule(Regex("^(?:disable|deactivate|switch off|power off|shut off)\\s+(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver|hotspot|location|gps|nfc|vpn|cast|auto rotate|auto brightness|rotation)$"), "turn off $1"),
        Rule(Regex("^(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver|hotspot|location|gps|nfc|vpn|cast|auto rotate|auto brightness|rotation)\\s+(on|off)$"), "turn $2 $1")
    )

    // ------------------------------------------------------------- public

    /**
     * Returns the canonical phrasing, or the tidied text if nothing applied.
     * [lastTarget] is "brightness" or "volume" when that was the last thing the
     * person adjusted, which lets "a bit more" mean the right thing.
     * Never throws.
     */
    fun translate(raw: String, lastTarget: String? = null): String {
        var t = tidy(raw)
        if (t.isEmpty()) return t
        t = fixTypos(t)
        t = digitize(t)
        t = PERCENT.replace(t, "$1%")
        t = SPACED_PCT.replace(t, "$1%")
        t = timeWords(t)
        repeat(2) { t = DOT_COM.replace(t, "$1.$2") }

        if (lastTarget != null) followUp(t, lastTarget)?.let { return it }

        t = Rewriter.rewrite(t)
        if (t.isEmpty()) return t
        for (a in ALIASES) t = a.re.replace(t, a.to)

        for (r in VOICE_RULES) {
            if (r.re.containsMatchIn(t)) return r.re.replace(t, r.to).trim()
        }
        indirect(t)?.let { return it }
        adjustLevel(t)?.let { return it }

        for (r in PHRASE_RULES) {
            if (r.re.containsMatchIn(t)) return r.re.replace(t, r.to).trim()
        }
        for (r in TOGGLE_RULES) {
            if (r.re.containsMatchIn(t)) return r.re.replace(t, r.to).trim()
        }
        return t
    }

    // ------------------------------------------------------------- levels

    /**
     * Brightness and volume, in every way people ask for them.
     *
     * Three shapes come out:
     *   set <target> to N%
     *   increase|decrease <target> by N%
     *   increase|decrease <target>            (the router picks a default step)
     */
    internal fun adjustLevel(t: String): String? {
        if (QUESTION.containsMatchIn(t) || UNRELATED.containsMatchIn(t)) return null

        val bright = BRIGHT.containsMatchIn(t) || BRIGHT_IMPLICIT.containsMatchIn(t)
        val vol = VOLUME.containsMatchIn(t) || VOLUME_IMPLICIT.containsMatchIn(t)
        if (bright == vol) return null // neither, or ambiguous
        val target = if (bright) "brightness" else "volume"

        val upAt = DIR_UP.find(t)?.range?.first ?: -1
        val downAt = DIR_DOWN.find(t)?.range?.first ?: -1
        val dir = when {
            upAt >= 0 && downAt >= 0 -> if (upAt < downAt) 1 else -1
            upAt >= 0 -> 1
            downAt >= 0 -> -1
            else -> 0
        }

        val n = number(t)
        val toAbs = TO_ABS.containsMatchIn(t)
        val notches = NOTCH.find(t)?.groupValues?.get(1)?.toIntOrNull()

        return when {
            BY_HALF.containsMatchIn(t) && dir != 0 -> delta(target, dir, 50)
            notches != null && dir != 0 -> delta(target, dir, notches * if (bright) 10 else 7)
            MAXW.containsMatchIn(t) -> absolute(target, 100)
            MINW.containsMatchIn(t) -> absolute(target, if (bright) 5 else 0)
            HALF.containsMatchIn(t) -> absolute(target, 50)
            n != null && (toAbs || dir == 0) -> absolute(target, n)
            n != null -> delta(target, dir, n)
            dir != 0 -> delta(target, dir, qualitative(t))
            else -> null
        }
    }

    /** "it's too loud", "I can't see anything", "that hurts my eyes". */
    internal fun indirect(t: String): String? {
        if (UNRELATED.containsMatchIn(t)) return null
        val amount = when {
            SMALL.containsMatchIn(t) -> 10
            WAY_TOO.containsMatchIn(t) -> 30
            else -> null
        }
        return when {
            TOO_BRIGHT.containsMatchIn(t) -> delta("brightness", -1, amount)
            TOO_DARK.containsMatchIn(t) -> delta("brightness", 1, amount)
            TOO_LOUD.containsMatchIn(t) -> delta("volume", -1, amount)
            TOO_QUIET.containsMatchIn(t) -> delta("volume", 1, amount)
            else -> null
        }
    }

    /**
     * "a bit more", "less", "turn it up", "20 more", "set it to 40": the thing
     * being adjusted comes from what was adjusted last. Words that name their
     * own target ("louder", "dimmer") are left to the normal pipeline.
     */
    private fun followUp(t: String, target: String): String? {
        FOLLOW.find(t)?.let { m ->
            val w = m.groupValues[1]
            val dir = if (w == "more" || w == "up" || w == "higher") 1 else -1
            return delta(target, dir, qualitative(t))
        }
        FOLLOW_NUM.find(t)?.let { m ->
            val dir = if (m.groupValues[2] == "more" || m.groupValues[2] == "higher") 1 else -1
            return delta(target, dir, m.groupValues[1].toInt())
        }
        SET_IT.find(t)?.let { return absolute(target, it.groupValues[1].toInt()) }
        return null
    }

    private fun number(t: String): Int? =
        (NUM_PCT.find(t) ?: NUM_PREP.find(t) ?: NUM_ANY.find(t))
            ?.groupValues?.get(1)?.toIntOrNull()

    private fun qualitative(t: String): Int? = when {
        SMALL.containsMatchIn(t) -> 10
        LARGE.containsMatchIn(t) -> 30
        else -> null
    }

    private fun absolute(target: String, pct: Int) = "set $target to ${pct.coerceIn(0, 100)}%"

    private fun delta(target: String, dir: Int, amount: Int?): String {
        val verb = if (dir > 0) "increase" else "decrease"
        return if (amount == null) "$verb $target" else "$verb $target by ${amount.coerceIn(1, 100)}%"
    }

    // ------------------------------------------------------------ helpers

    private fun tidy(s: String): String = s.lowercase(Locale.ROOT)
        .replace(Regex("[\u2018\u2019']"), "")
        .replace(Regex("[?!,;]+"), " ")
        .replace(Regex("\\.+\\s*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    /** "half past six" -> "6:30", "quarter to seven" -> "6:45", "noon" -> "12 pm". */
    internal fun timeWords(s: String): String {
        var t = AMPM_DOTS.replace(s, "$1 $2m")
        t = HALF_PAST.replace(t, "$1:30")
        t = QUARTER_PAST.replace(t, "$1:15")
        t = QUARTER_TO.replace(t) { m ->
            val h = m.groupValues[1].toInt()
            "${if (h <= 1) 12 else h - 1}:45"
        }
        t = NOON.replace(t, "12 pm")
        t = MIDNIGHT.replace(t, "12 am")
        t = SPLIT_TIME.replace(t, "$1:$2 $3")
        t = THREE_QUARTERS.replace(t, "75%")
        t = QUARTER.replace(t, "25%")
        return t
    }

    // ---------------------------------------------------------------- typos

    /** Optimal-string-alignment distance: a swapped pair of letters counts as one edit. */
    internal fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, d[i - 2][j - 2] + 1)
                }
                d[i][j] = v
            }
        }
        return d[a.length][b.length]
    }

    /**
     * Fixes slips in command words only. A word is corrected when it is at
     * least five letters, starts with the same letter as exactly one keyword,
     * and is within one edit (two for long words). Names and everyday English
     * are not in the vocabulary, so they are never touched.
     */
    internal fun fixTypos(t: String): String = t.split(" ").joinToString(" ") { w ->
        if (w.length < 5 || !w.all { it in 'a'..'z' } || w in VOCAB_SET || w in PROTECTED) {
            w
        } else {
            val limit = if (w.length >= 8) 2 else 1
            var best: String? = null
            var bestD = Int.MAX_VALUE
            var tie = false
            for (v in VOCAB) {
                if (v[0] != w[0] || kotlin.math.abs(v.length - w.length) > limit) continue
                val dd = distance(w, v)
                if (dd < bestD) {
                    bestD = dd
                    best = v
                    tie = false
                } else if (dd == bestD) {
                    tie = true
                }
            }
            if (best != null && bestD <= limit && !tie) best else w
        }
    }

    // -------------------------------------------------------------- numbers

    private fun kindOf(w: String): Int {
        if (w == "zero") return 5
        if (w == "hundred") return 4
        if (TENS.containsKey(w)) return 3
        val u = UNITS[w] ?: return 0
        return if (u >= 10) 2 else 1
    }

    // 1 unit, 2 teen, 3 tens, 4 hundred, 5 zero. Keeps "nine one one" as three
    // numbers instead of adding them up.
    private fun allowed(prev: Int, kind: Int): Boolean = when (kind) {
        1 -> prev == 0 || prev == 3 || prev == 4
        2, 3 -> prev == 0 || prev == 4
        4 -> prev == 0 || prev == 1
        5 -> prev == 0
        else -> false
    }

    /** "twenty five" -> "25", "a hundred" -> "100". A lone "one" is left alone. */
    internal fun digitize(s: String): String {
        val toks = HYPHEN_NUM.replace(s, "$1 $2").split(" ")
        val out = ArrayList<String>(toks.size)
        var i = 0
        while (i < toks.size) {
            val w = toks[i]
            val aHundred = w == "a" && toks.getOrNull(i + 1) == "hundred"
            if (!aHundred && kindOf(w) == 0) {
                out.add(w)
                i++
                continue
            }

            var cur = 0
            var prev = 0
            var j = i
            if (aHundred) {
                cur = 100
                prev = 4
                j = i + 2
            }
            while (j < toks.size) {
                val x = toks[j]
                val k = kindOf(x)
                if (k == 0 || !allowed(prev, k)) break
                if (k == 4) cur = if (cur == 0) 100 else cur * 100
                else if (k != 5) cur += (UNITS[x] ?: TENS[x] ?: 0)
                prev = k
                j++
            }

            if (j - i == 1 && w == "one") out.add(w) else out.add(cur.toString())
            i = j
        }
        return out.joinToString(" ")
    }
}
