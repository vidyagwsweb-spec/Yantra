package `in`.yantra.assistant.router

import java.util.Locale

/**
 * Translates the way people actually talk into the canonical phrasing the
 * [Router] understands.
 *
 *   "increase the brightness by fifty percent"  -> "increase brightness by 50%"
 *   "make the screen a bit dimmer"              -> "decrease brightness by 10%"
 *   "turn the volume up to forty"               -> "set volume to 40%"
 *   "bring the volume down by half"             -> "decrease volume by 50%"
 *   "flashlight on"                             -> "turn on flashlight"
 *
 * Pure Kotlin, no Android imports, so it is unit-tested on the JVM.
 *
 * The router only consults this when its own patterns found nothing, so the
 * translator can add coverage but can never break a command that already worked.
 *
 * Pipeline:
 *   1. tidy        lowercase, strip apostrophes and punctuation
 *   2. numbers     "twenty five" -> 25, "fifty percent" -> 50%
 *   3. Rewriter    politeness, word order, synonyms
 *   4. aliases     dnd -> do not disturb, bt -> bluetooth
 *   5. levels      brightness / volume: absolute, relative, qualitative
 *   6. toggles     "wifi on", "disable bluetooth" -> "turn off bluetooth"
 */
object Translator {

    private class Rule(val re: Regex, val to: String)

    // ------------------------------------------------------------ numbers

    private val UNITS = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
        "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15,
        "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19
    )
    private val TENS = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    private val HYPHEN_NUM = Regex("\\b(twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)-(one|two|three|four|five|six|seven|eight|nine)\\b")
    private val PERCENT = Regex("(\\d+)\\s*(?:percent|per cent|percentage|pct)\\b")
    private val SPACED_PCT = Regex("(\\d)\\s+%")

    // ------------------------------------------------- level vocabulary

    private val BRIGHT = Regex("\\b(?:brightness|screen|display|backlight)\\b")
    private val BRIGHT_IMPLICIT = Regex("\\b(?:brighter|brighten|dimmer|dim|darken)\\b")
    private val VOLUME = Regex("\\b(?:volume|sound|audio|music|media)\\b")
    private val VOLUME_IMPLICIT = Regex("\\b(?:louder|quieter|softer)\\b")

    private val DIR_UP = Regex("\\b(?:increase|raise|boost|bump up|bump|turn up|crank up|pump up|ramp up|dial up|up|lift|higher|more|brighter|brighten|louder)\\b")
    private val DIR_DOWN = Regex("\\b(?:decrease|lower|reduce|drop|cut|dim|dimmer|darken|turn down|tone down|dial down|down|quieter|softer|less)\\b")

    private val TO_ABS = Regex("\\b(?:to|at|equals?)\\s+(?:about\\s+|around\\s+|roughly\\s+)?(?:\\d|half|max|maximum|full|min|minimum|lowest|highest)")
    private val BY_HALF = Regex("\\bby half\\b")
    private val NOTCH = Regex("(\\d{1,3})\\s*(?:levels?|notches?|steps?|bars?|clicks?)\\b")
    private val MAXW = Regex("\\b(?:max|maximum|maxed|full|fully|highest|all the way)\\b")
    private val MINW = Regex("\\b(?:min|minimum|lowest)\\b")
    private val HALF = Regex("\\bhalf\\b")
    private val SMALL = Regex("\\b(?:a little|a bit|a touch|a tad|slightly|little|bit)\\b")
    private val LARGE = Regex("\\b(?:a lot|lot|much|way|significantly|massively)\\b")

    private val NUM_PCT = Regex("(\\d{1,3})\\s*%")
    private val NUM_PREP = Regex("\\b(?:to|at|by)\\s+(?:about\\s+|around\\s+)?(\\d{1,3})\\b")
    private val NUM_ANY = Regex("\\b(\\d{1,3})\\b")

    // "how do I make the screen brighter" is a question, not a command
    private val QUESTION = Regex("^(?:how|why|what|whats|when|where|who|which|is|are|does|do|did)\\b")
    // never steal a command that is really about something else
    private val UNRELATED = Regex("\\b(?:alarm|timer|remind|reminder|call|text|message|whatsapp|note|event|calendar)\\b")

    // ------------------------------------------------------------ toggles

    private val ALIASES = listOf(
        Rule(Regex("\\bdnd\\b"), "do not disturb"),
        Rule(Regex("\\bbt\\b"), "bluetooth"),
        Rule(Regex("\\baeroplane\\b"), "airplane")
    )

    private val TOGGLE_RULES = listOf(
        Rule(Regex("^(?:enable|activate|start|switch on|power on)\\s+(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver)$"), "turn on $1"),
        Rule(Regex("^(?:disable|deactivate|switch off|power off|shut off)\\s+(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver)$"), "turn off $1"),
        Rule(Regex("^(?:the\\s+)?(wi-?fi|bluetooth|flashlight|torch|flash|do not disturb|mobile data|airplane mode|dark mode|battery saver)\\s+(on|off)$"), "turn $2 $1")
    )

    // ------------------------------------------------------------- public

    /**
     * Returns the canonical phrasing, or the tidied text if nothing applied.
     * Never throws.
     */
    fun translate(raw: String): String {
        var t = tidy(raw)
        if (t.isEmpty()) return t
        t = digitize(t)
        t = PERCENT.replace(t, "$1%")
        t = SPACED_PCT.replace(t, "$1%")
        t = Rewriter.rewrite(t)
        if (t.isEmpty()) return t
        for (a in ALIASES) t = a.re.replace(t, a.to)

        adjustLevel(t)?.let { return it }

        for (r in TOGGLE_RULES) {
            if (r.re.containsMatchIn(t)) return r.re.replace(t, r.to).trim()
        }
        return t
    }

    // ------------------------------------------------------------- levels

    /**
     * Brightness and volume, in every way people ask for them.
     *
     * Three shapes come out:
     *   set <target> to N%
     *   increase|decrease <target> by N%
     *   increase|decrease <target>            (the router picks a default step)
     */
    internal fun adjustLevel(t: String): String? {
        if (QUESTION.containsMatchIn(t) || UNRELATED.containsMatchIn(t)) return null

        val bright = BRIGHT.containsMatchIn(t) || BRIGHT_IMPLICIT.containsMatchIn(t)
        val vol = VOLUME.containsMatchIn(t) || VOLUME_IMPLICIT.containsMatchIn(t)
        if (bright == vol) return null // neither, or ambiguous
        val target = if (bright) "brightness" else "volume"

        val upAt = DIR_UP.find(t)?.range?.first ?: -1
        val downAt = DIR_DOWN.find(t)?.range?.first ?: -1
        val dir = when {
            upAt >= 0 && downAt >= 0 -> if (upAt < downAt) 1 else -1
            upAt >= 0 -> 1
            downAt >= 0 -> -1
            else -> 0
        }

        val n = number(t)
        val toAbs = TO_ABS.containsMatchIn(t)
        val notches = NOTCH.find(t)?.groupValues?.get(1)?.toIntOrNull()

        return when {
            BY_HALF.containsMatchIn(t) && dir != 0 -> delta(target, dir, 50)
            notches != null && dir != 0 -> delta(target, dir, notches * if (bright) 10 else 7)
            MAXW.containsMatchIn(t) -> absolute(target, 100)
            MINW.containsMatchIn(t) -> absolute(target, if (bright) 5 else 0)
            HALF.containsMatchIn(t) -> absolute(target, 50)
            n != null && (toAbs || dir == 0) -> absolute(target, n)
            n != null -> delta(target, dir, n)
            dir != 0 -> delta(target, dir, qualitative(t))
            else -> null
        }
    }

    private fun number(t: String): Int? =
        (NUM_PCT.find(t) ?: NUM_PREP.find(t) ?: NUM_ANY.find(t))
            ?.groupValues?.get(1)?.toIntOrNull()

    private fun qualitative(t: String): Int? = when {
        SMALL.containsMatchIn(t) -> 10
        LARGE.containsMatchIn(t) -> 30
        else -> null
    }

    private fun absolute(target: String, pct: Int) = "set $target to ${pct.coerceIn(0, 100)}%"

    private fun delta(target: String, dir: Int, amount: Int?): String {
        val verb = if (dir > 0) "increase" else "decrease"
        return if (amount == null) "$verb $target" else "$verb $target by ${amount.coerceIn(1, 100)}%"
    }

    // ------------------------------------------------------------ helpers

    private fun tidy(s: String): String = s.lowercase(Locale.ROOT)
        .replace(Regex("[\u2018\u2019']"), "")
        .replace(Regex("[?!,;]+"), " ")
        .replace(Regex("\\.+\\s*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun kindOf(w: String): Int {
        if (w == "zero") return 5
        if (w == "hundred") return 4
        if (TENS.containsKey(w)) return 3
        val u = UNITS[w] ?: return 0
        return if (u >= 10) 2 else 1
    }

    // 1 unit, 2 teen, 3 tens, 4 hundred, 5 zero. Keeps "nine one one" as three
    // numbers instead of adding them up.
    private fun allowed(prev: Int, kind: Int): Boolean = when (kind) {
        1 -> prev == 0 || prev == 3 || prev == 4
        2, 3 -> prev == 0 || prev == 4
        4 -> prev == 0 || prev == 1
        5 -> prev == 0
        else -> false
    }

    /** "twenty five" -> "25", "a hundred" -> "100". A lone "one" is left alone. */
    internal fun digitize(s: String): String {
        val toks = HYPHEN_NUM.replace(s, "$1 $2").split(" ")
        val out = ArrayList<String>(toks.size)
        var i = 0
        while (i < toks.size) {
            val w = toks[i]
            val aHundred = w == "a" && toks.getOrNull(i + 1) == "hundred"
            if (!aHundred && kindOf(w) == 0) {
                out.add(w)
                i++
                continue
            }

            var cur = 0
            var prev = 0
            var j = i
            if (aHundred) {
                cur = 100
                prev = 4
                j = i + 2
            }
            while (j < toks.size) {
                val x = toks[j]
                val k = kindOf(x)
                if (k == 0 || !allowed(prev, k)) break
                if (k == 4) cur = if (cur == 0) 100 else cur * 100
                else if (k != 5) cur += (UNITS[x] ?: TENS[x] ?: 0)
                prev = k
                j++
            }

            if (j - i == 1 && w == "one") out.add(w) else out.add(cur.toString())
            i = j
        }
        return out.joinToString(" ")
    }
}
