package `in`.yantra.assistant.router

import java.net.URLEncoder
import java.util.Locale

/**
 * Where a piece of text should go on the web. This mirrors Valley's own smart
 * search (`routeSearch` in Valley's MainActivity), so that when Yantra tells
 * you "Opening maharashtraboardsolutions.com in Valley" that is where Valley
 * really goes. Valley stays the source of truth: Yantra sends it the text and
 * Valley decides. This copy only lets Yantra describe the result, and carry on
 * when Valley is not installed.
 *
 * Pure Kotlin, no Android imports.
 */
object WebRoute {

    enum class Kind { SITE, SEARCH, SHOP }

    /** [url] is where it goes; [site] is a short name for speech, like "flipkart.com". */
    data class Route(val kind: Kind, val url: String, val site: String)

    private val SCHEME = Regex("^[a-z][a-z0-9+.-]*://", RegexOption.IGNORE_CASE)
    private val BARE_HOST = Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE)
    private val NAV = Regex("^(?:open|go\\s+to|goto|visit|launch)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val QUESTION = Regex(
        "^(what|who|whom|whose|why|how|when|where|which|is|are|was|were|am|do|does|did|can|could|should|would|will|has|have|had)\\b",
        RegexOption.IGNORE_CASE
    )
    private const val BRAVE = "https://search.brave.com/search?q="

    private val SITES = linkedMapOf(
        "flipkart" to "https://www.flipkart.com/search?q=",
        "amazon" to "https://www.amazon.in/s?k=",
        "myntra" to "https://www.myntra.com/search?q=",
        "ajio" to "https://www.ajio.com/search/?text=",
        "croma" to "https://www.croma.com/searchB?q=",
        "snapdeal" to "https://www.snapdeal.com/search?keyword=",
        "meesho" to "https://www.meesho.com/search?q=",
        "nykaa" to "https://www.nykaa.com/search/result/?q=",
        "tatacliq" to "https://www.tatacliq.com/search/?searchCategory=all&text=",
        "reliancedigital" to "https://www.reliancedigital.in/search?q=",
        "swiggy" to "https://www.swiggy.com/search?query=",
        "zomato" to "https://www.zomato.com/search?q=",
        "bookmyshow" to "https://in.bookmyshow.com/explore/movies?q=",
        "paytm" to "https://paytm.com/",
        "github" to "https://github.com/search?q=",
        "wikipedia" to "https://en.wikipedia.org/w/index.php?search=",
        "youtube" to "https://www.youtube.com/results?search_query=",
        "reddit" to "https://www.reddit.com/search/?q=",
        "stackoverflow" to "https://stackoverflow.com/search?q=",
        "quora" to "https://www.quora.com/search?q=",
        "imdb" to "https://www.imdb.com/find?q=",
        "cricbuzz" to "https://www.cricbuzz.com/search?q=",
        "ndtv" to "https://www.ndtv.com/search?searchtext="
    )

    private val KNOWN = listOf(
        "google.com", "youtube.com", "facebook.com", "instagram.com", "whatsapp.com", "x.com", "twitter.com",
        "reddit.com", "wikipedia.org", "linkedin.com", "pinterest.com", "quora.com", "medium.com", "github.com",
        "gitlab.com", "stackoverflow.com", "npmjs.com", "vercel.com", "netlify.com", "amazon.in", "amazon.com",
        "flipkart.com", "myntra.com", "ajio.com", "meesho.com", "snapdeal.com", "nykaa.com", "croma.com",
        "reliancedigital.in", "tatacliq.com", "paytm.com", "phonepe.com", "swiggy.com", "zomato.com", "zepto.com",
        "blinkit.com", "bigbasket.com", "bookmyshow.com", "makemytrip.com", "irctc.co.in", "redbus.in", "uber.com",
        "ndtv.com", "thehindu.com", "hindustantimes.com", "indianexpress.com", "bbc.com", "cnn.com", "reuters.com",
        "theguardian.com", "nytimes.com", "netflix.com", "primevideo.com", "hotstar.com", "spotify.com",
        "soundcloud.com", "imdb.com", "cricbuzz.com", "espn.com", "apple.com", "microsoft.com", "samsung.com",
        "oneplus.in", "mi.com", "realme.com", "vivo.com", "adobe.com", "figma.com", "canva.com", "notion.so",
        "slack.com", "discord.com", "telegram.org", "chatgpt.com", "claude.ai", "perplexity.ai", "sarvam.ai",
        "accuweather.com", "timeanddate.com", "britannica.com", "dictionary.com", "archive.org", "wordpress.com",
        "substack.com"
    )

    fun resolve(input: String, smart: Boolean = true): Route {
        val q = input.trim()
        if (SCHEME.containsMatchIn(q)) return Route(Kind.SITE, q, hostOf(q))
        if (!q.contains(Regex("\\s")) && BARE_HOST.matches(q)) return Route(Kind.SITE, "https://$q", hostOf("https://$q"))

        NAV.matchEntire(q)?.let { m -> navTarget(m.groupValues[1])?.let { return Route(Kind.SITE, it, hostOf(it)) } }

        if (!smart || QUESTION.containsMatchIn(q) || q.endsWith("?")) return search(q)

        for ((name, endpoint) in SITES) {
            val word = Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE)
            if (word.containsMatchIn(q)) {
                val terms = q.replace(word, " ")
                    .replace(Regex("^\\s*(price of|prices|price|cost of|cost|buy|buying|best|where to buy|order)\\s+", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+\\b(on|from|at|in)\\s*$", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+"), " ").trim()
                val url = if (endpoint.endsWith("/") && name == "paytm") endpoint else endpoint + enc(terms.ifEmpty { q })
                return Route(Kind.SHOP, url, hostOf(endpoint))
            }
        }
        return search(q)
    }

    /** What speech should call a route: "flipkart.com", or "Brave" for a plain search. */
    fun describe(r: Route): String = if (r.kind == Kind.SEARCH) "Brave" else r.site

    private fun search(q: String) = Route(Kind.SEARCH, BRAVE + enc(q), "search.brave.com")

    private fun navTarget(raw: String): String? {
        val target = raw.trim().trimEnd('.', '\u3002', ',', '\'', '"').trim()
        if (target.isEmpty()) return null
        val key = target.lowercase(Locale.ROOT).replace(Regex("\\s+"), "")
        SITES[key]?.let { value ->
            return Regex("^(https?://[^/]+)").find(value)?.groupValues?.get(1)
        }
        if (Regex("^[a-z0-9-]+$", RegexOption.IGNORE_CASE).matches(target))
            return nearestSite(target) ?: "https://${target.lowercase(Locale.ROOT)}.com"
        if (BARE_HOST.matches(target)) return "https://$target"
        return null
    }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1)
            cur[0] = i + 1
            for (j in b.indices) cur[j + 1] = minOf(prev[j + 1] + 1, cur[j] + 1, prev[j] + if (a[i] == b[j]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    private fun nearestSite(word: String): String? {
        val w = word.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "")
        if (w.length < 3) return null
        var best: String? = null
        var bestD = Int.MAX_VALUE
        for (host in KNOWN) {
            val base = host.substringBefore('.').replace(Regex("[^a-z0-9]"), "")
            var d = distance(w, base)
            if (base.startsWith(w)) d = minOf(d, 1)
            if (d < bestD) { bestD = d; best = host }
        }
        val limit = if (w.length <= 4) 1 else if (w.length <= 7) 2 else 3
        return if (best != null && bestD <= limit) "https://$best" else null
    }

    private fun hostOf(url: String): String =
        Regex("^[a-z][a-z0-9+.-]*://(?:www\\.)?([^/?#]+)", RegexOption.IGNORE_CASE).find(url)?.groupValues?.get(1) ?: url

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
}
