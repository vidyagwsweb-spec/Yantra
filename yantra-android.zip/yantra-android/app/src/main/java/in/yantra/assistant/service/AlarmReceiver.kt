package `in`.yantra.assistant.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import `in`.yantra.assistant.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "Alarm"
        active.remove(intent.getLongExtra(EXTRA_AT, 0L))
        showNotification(ctx, label)
    }

    private fun showNotification(ctx: Context, label: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                    enableVibration(true)
                }
            )
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Yantra alarm")
            .setContentText(label)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { nm.notify(label.hashCode(), n) } catch (e: SecurityException) { /* no notification permission */ }
    }

    companion object {
        private const val CHANNEL = "yantra_alarms"
        private const val EXTRA_LABEL = "label"
        private const val EXTRA_AT = "at"

        /** Alarms this app set, so "show my alarms" has something to show. */
        val active = LinkedHashMap<Long, String>()

        fun register(at: Long, label: String) {
            active[at] = label
        }

        fun pending(ctx: Context, at: Long): PendingIntent {
            val i = Intent(ctx, AlarmReceiver::class.java).apply {
                putExtra(EXTRA_LABEL, SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date(at)))
                putExtra(EXTRA_AT, at)
            }
            return PendingIntent.getBroadcast(
                ctx, (at % Int.MAX_VALUE).toInt(), i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }
}
