package `in`.yantra.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Captures notifications so "read my notifications" can answer. */
class NotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val pkg = sbn.packageName ?: ""
        synchronized(cache) {
            cache.removeAll { it.pkg == pkg && it.title == title }
            cache.add(0, Item(pkg, title, text))
            while (cache.size > 30) cache.removeAt(cache.size - 1)
        }
    }

    data class Item(val pkg: String, val title: String, val text: String)

    companion object {
        val cache: MutableList<Item> = mutableListOf()
    }
}
