package `in`.yantra.assistant.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import `in`.yantra.assistant.MainActivity
import `in`.yantra.assistant.actions.ActionExecutor
import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.speech.Listener
import `in`.yantra.assistant.speech.Speaker
import `in`.yantra.assistant.ui.BlobView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The floating assistant.
 *
 * A draggable orb lives in an application-overlay window, so it stays on screen
 * above every other app — the same mechanism as Gemini's floating button and
 * chat heads. Tap it and a small panel opens: type or speak, get the answer,
 * without leaving whatever you were doing.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var blob: BlobView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private lateinit var executor: ActionExecutor
    private lateinit var speaker: Speaker
    private var recognizer: Listener? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var lastUser: String? = null
    private var lastBot: String? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        executor = ActionExecutor(this)
        speaker = Speaker(this)
        speaker.init()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        startForegroundSafely()
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        recognizer?.stop()
        speaker.shutdown()
        scope.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        bubble = null
        panel = null
    }

    // ------------------------------------------------------------- foreground

    private fun startForegroundSafely() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, "yantra_general")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Yantra is floating")
            .setContentText("Tap the orb to ask something")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            // some OEMs reject special-use; fall back to a plain foreground
            runCatching { startForeground(NOTIF_ID, notification) }
        }
    }

    // ------------------------------------------------------------------ bubble

    private fun addBubble() {
        val size = dp(64)
        val view = FrameLayout(this)
        val orb = BlobView(this).apply { palette = warmPalette() }
        view.addView(orb, FrameLayout.LayoutParams(size, size))
        blob = orb

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        bubbleParams = params

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragged = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).roundToInt()
                    val dy = (event.rawY - downY).roundToInt()
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) dragged = true
                    if (dragged) {
                        params.x = startX + dx
                        params.y = startY + dy
                        runCatching { wm.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) openPanel()
                    true
                }
                else -> false
            }
        }

        runCatching { wm.addView(view, params) }
        bubble = view
    }

    // ------------------------------------------------------------------- panel

    private fun openPanel() {
        if (panel != null) return
        blob?.listening = false

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#F5F2EC"))
                setStroke(dp(1), Color.parseColor("#1F1B1815"))
            }
        }

        val title = TextView(this).apply {
            text = "Yantra"
            setTextColor(Color.parseColor("#1B1815"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val reply = TextView(this).apply {
            text = "Ask me something."
            setTextColor(Color.parseColor("#6B625A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(8), 0, dp(10))
        }
        val input = EditText(this).apply {
            hint = "Type a command…"
            setTextColor(Color.parseColor("#1B1815"))
            setHintTextColor(Color.parseColor("#6B625A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(10), 0, 0)
        }
        val micBtn = pillButton("Speak", "#1B1815", "#F6F0E8")
        val sendBtn = pillButton("Send", "#E8622A", "#FFFFFF")
        val closeBtn = pillButton("Close", "#00000000", "#6B625A")
        row.addView(closeBtn)
        row.addView(micBtn)
        row.addView(sendBtn)

        card.addView(title)
        card.addView(reply)
        card.addView(input)
        card.addView(row)

        val width = (resources.displayMetrics.widthPixels * 0.9f).toInt()
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.35f
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        fun submit(text: String) {
            if (text.isBlank()) return
            input.setText("")
            reply.text = "…"
            scope.launch {
                val parsed = Router.route(text, Ctx(lastUser = lastUser, lastBot = lastBot))
                val result = runCatching { executor.run(parsed) }
                    .getOrElse { `in`.yantra.assistant.actions.ActResult("That failed: ${it.message}") }
                reply.text = result.text
                speaker.say(result.speak)
                lastUser = text
                lastBot = result.text
            }
        }

        sendBtn.setOnClickListener { submit(input.text.toString()) }
        input.setOnEditorActionListener { _, _, _ ->
            submit(input.text.toString()); true
        }
        closeBtn.setOnClickListener { closePanel() }
        micBtn.setOnClickListener {
            reply.text = "Listening…"
            blob?.listening = true
            recognizer?.stop()
            recognizer = Listener(
                this,
                onPartial = { reply.text = it },
                onResult = {
                    blob?.listening = false
                    submit(it)
                },
                onError = {
                    blob?.listening = false
                    reply.text = it
                }
            ).also { it.start() }
        }

        runCatching { wm.addView(card, params) }
        panel = card
    }

    private fun closePanel() {
        recognizer?.stop()
        blob?.listening = false
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    // ------------------------------------------------------------------ utils

    private fun pillButton(label: String, bg: String, fg: String): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.parseColor(fg))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(50).toFloat()
                setColor(Color.parseColor(bg))
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginStart = dp(8)
            layoutParams = lp
        }

    private fun warmPalette(): IntArray = intArrayOf(
        0xFFE8622A.toInt(),
        0xFFF6B955.toInt(),
        0xFF8FB0C4.toInt(),
        0xFF5C2A22.toInt()
    )

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).roundToInt()

    companion object {
        private const val NOTIF_ID = 4242
        const val ACTION_STOP = "in.yantra.assistant.STOP_OVERLAY"

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
