package `in`.yantra.assistant.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import `in`.yantra.assistant.util.Languages
import `in`.yantra.assistant.util.Prefs
import java.util.Locale

/**
 * Text to speech out.
 *
 * The default Android voice is often the smallest, most robotic one. This
 * picks the best English voice that is actually installed (offline first,
 * then highest quality), remembers a voice you choose, and lets you cycle
 * through the others by asking.
 */
class Speaker(private val ctx: Context) {

    private val prefs = Prefs(ctx)
    private var tts: TextToSpeech? = null
    private var ready = false

    /** Speaking speed, remembered. */
    var rate: Float = prefs.get("tts.rate", "1.0").toFloatOrNull() ?: 1.0f
        set(value) {
            field = value.coerceIn(0.5f, 1.8f)
            prefs.set("tts.rate", field.toString())
        }

    /** Voice pitch, remembered. */
    var pitch: Float = prefs.get("tts.pitch", "1.0").toFloatOrNull() ?: 1.0f
        set(value) {
            field = value.coerceIn(0.7f, 1.4f)
            prefs.set("tts.pitch", field.toString())
        }

    /** Off means replies are shown but never spoken. */
    var enabled: Boolean = prefs.get("speak", "1") == "1"

    /** BCP 47 tag, for example "en-GB". Spoken accent and the voices on offer follow it. */
    var languageTag: String = prefs.get("lang", Languages.DEFAULT)
        private set

    private fun locale(): Locale = Locale.forLanguageTag(languageTag)

    fun init(onReady: (() -> Unit)? = null) {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyLanguage()
                applyVoice()
                tts?.setSpeechRate(rate)
                tts?.setPitch(pitch)
                ready = true
                onReady?.invoke()
            }
        }
    }

    fun say(text: String) {
        if (!enabled || !ready || text.isBlank()) return
        tts?.stop()
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)
        tts?.speak(SpeechText.clean(text), TextToSpeech.QUEUE_FLUSH, null, "yantra")
    }

    /** Speaks [text] even when spoken replies are switched off: used for previews in Settings. */
    fun preview(text: String) {
        if (!ready) return
        tts?.stop()
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yantra-preview")
    }

    fun stop() { tts?.stop() }

    // ------------------------------------------------------------- voices

    /** Installed English voices of any accent. */
    private fun englishVoices(): List<Voice> {
        val all = (try { tts?.voices } catch (e: Exception) { null }) ?: return emptyList()
        return all.filter { v ->
            v.locale.language == "en" &&
                !v.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
    }

    private fun ranked(list: List<Voice>): List<Voice> = list.sortedWith(
        compareBy<Voice> { it.isNetworkConnectionRequired }
            .thenByDescending { it.quality }
            .thenBy { it.name }
    )

    /** True when the phone has at least one voice for the chosen accent. */
    fun hasVoicesForLanguage(): Boolean {
        val country = Languages.country(languageTag)
        return englishVoices().any { it.locale.country.equals(country, ignoreCase = true) }
    }

    /**
     * Voices to choose from, best first: voices that work offline before ones
     * that need internet, then by quality. Only the chosen accent when the
     * phone has any; otherwise every English voice, so the list is never empty
     * just because one accent is not downloaded.
     */
    fun voices(): List<Voice> {
        val all = englishVoices()
        val country = Languages.country(languageTag)
        val exact = all.filter { it.locale.country.equals(country, ignoreCase = true) }
        return ranked(if (exact.isNotEmpty()) exact else all)
    }

    /** What Settings shows for each voice. */
    fun voiceChoices(): List<VoiceChoice> = voices().mapIndexed { i, v ->
        VoiceChoice(
            name = v.name,
            label = "Voice ${i + 1}",
            detail = describeShort(v)
        )
    }

    fun currentVoiceName(): String? = try { tts?.voice?.name } catch (e: Exception) { null }

    private fun describeShort(v: Voice): String {
        val accent = Languages.ALL.firstOrNull { it.tag.endsWith("-" + v.locale.country) }?.label
            ?: v.locale.displayCountry.ifEmpty { v.locale.displayLanguage }
        val quality = when {
            v.quality >= Voice.QUALITY_VERY_HIGH -> "very high"
            v.quality >= Voice.QUALITY_HIGH -> "high"
            v.quality >= Voice.QUALITY_NORMAL -> "standard"
            else -> "basic"
        }
        return accent.removePrefix("English ").trim('(', ')') + " \u00B7 " + quality +
            (if (v.isNetworkConnectionRequired) " \u00B7 online" else "")
    }

    /** Picks a voice, remembers it, and says a short sample so you can hear it. */
    fun chooseVoice(name: String, sample: String? = "Hi, this is how I sound."): Boolean {
        val v = englishVoices().firstOrNull { it.name == name } ?: return false
        try { tts?.voice = v } catch (e: Exception) { return false }
        prefs.set("tts.voice", name)
        if (sample != null) {
            // a preview should be heard even when replies are muted
            tts?.stop()
            tts?.setSpeechRate(rate)
            tts?.setPitch(pitch)
            tts?.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "yantra-preview")
        }
        return true
    }

    /** Changes the accent: speech out, speech in, and the voice list. Returns false if the engine lacks it. */
    fun setLanguage(tag: String): Boolean {
        if (!Languages.isKnown(tag)) return false
        languageTag = Languages.find(tag).tag
        prefs.set("lang", languageTag)
        // the old voice belongs to the old accent
        prefs.set("tts.voice", "")
        val ok = applyLanguage()
        applyVoice()
        return ok
    }

    private fun applyLanguage(): Boolean {
        val t = tts ?: return false
        val result = try { t.setLanguage(locale()) } catch (e: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // keep speaking in something rather than going silent
            try { t.setLanguage(Locale.ENGLISH) } catch (e: Exception) { /* engine default */ }
            return false
        }
        return true
    }

    private fun applyVoice() {
        val list = voices()
        if (list.isEmpty()) return
        val saved = prefs.get("tts.voice")
        val pick = list.firstOrNull { it.name == saved } ?: list.first()
        try { tts?.voice = pick } catch (e: Exception) { /* keep the engine default */ }
    }

    fun voiceCount(): Int = voices().size

    /** Switches to the next voice and remembers it. Null if there is nothing to switch to. */
    fun nextVoice(): String? {
        val list = voices()
        if (list.size < 2) return null
        val current = tts?.voice?.name
        val next = list[(list.indexOfFirst { it.name == current } + 1) % list.size]
        try { tts?.voice = next } catch (e: Exception) { return null }
        prefs.set("tts.voice", next.name)
        return "Voice ${list.indexOf(next) + 1} of ${list.size}: ${describe(next)}."
    }

    fun voiceSummary(): String {
        val list = voices()
        if (list.isEmpty()) return "I cannot see any English voices yet. Say \"install a voice\" to get some."
        val now = tts?.voice
        val more = if (list.size < 3) " Say \"install a voice\" for more natural ones." else " Say \"change your voice\" to hear the next."
        return "I have ${list.size} English voice${if (list.size == 1) "" else "s"} installed. " +
            "Using ${if (now != null) describe(now) else "the default"}.$more"
    }

    private fun describe(v: Voice): String {
        val quality = when {
            v.quality >= Voice.QUALITY_VERY_HIGH -> "very high quality"
            v.quality >= Voice.QUALITY_HIGH -> "high quality"
            v.quality >= Voice.QUALITY_NORMAL -> "standard quality"
            else -> "basic quality"
        }
        val place = v.locale.displayCountry.ifEmpty { v.locale.displayLanguage }
        return "${v.locale.displayLanguage} ($place), $quality" +
            if (v.isNetworkConnectionRequired) ", needs internet" else ""
    }

    /** Opens the engine's voice downloads, or the text-to-speech settings. */
    fun openVoiceInstall(): Boolean {
        val tries = listOf(
            Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
            Intent("com.android.settings.TTS_SETTINGS")
        )
        for (i in tries) {
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) { /* try the next one */ }
        }
        return false
    }

    fun shiftPitch(by: Float) {
        pitch += by
    }

    /** Back to the automatic voice, normal pitch and normal speed. */
    fun resetVoice() {
        pitch = 1.0f
        rate = 1.0f
        prefs.set("tts.voice", "")
        applyVoice()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}

/** One voice as Settings shows it. */
data class VoiceChoice(val name: String, val label: String, val detail: String)

/** Speech to text in. Must be created and driven on the main thread. */
class Listener(
    private val ctx: Context,
    private val onPartial: (String) -> Unit,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onTranscript: (String) -> Unit = {}
) {

    private var recognizer: SpeechRecognizer? = null

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError("This phone has no speech recognition service.")
            return
        }
        stop()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = onPartial("Listening…")
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    onError(
                        when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "I did not catch that."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I heard nothing."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs a connection."
                            else -> "Speech error $error."
                        }
                    )
                }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) onError("I did not catch that.") else onResult(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!text.isNullOrBlank()) onTranscript(text)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs(ctx).get("lang", Languages.DEFAULT))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
    }

    fun stop() {
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
    }
}
