package `in`.yantra.assistant.speech

/**
 * Turns on-screen text into something that sounds like a person reading it.
 *
 * What looks fine in a chat bubble sounds robotic when read aloud verbatim:
 * "Brightness 30% → 80%" becomes "brightness thirty percent, arrow, eighty
 * percent" and a bulleted list becomes a run of unpunctuated words. This
 * rewrites symbols into words and line breaks into pauses.
 *
 * Pure Kotlin, no Android imports, so it is unit-tested on the JVM.
 */
object SpeechText {

    fun clean(text: String): String {
        var s = text
            .replace("\u2192", " to ")          // →
            .replace("\u2022", "")              // • bullets
            .replace("\u2014", ", ")            // — em dash
            .replace("\u2013", " to ")          // – ranges
            .replace("&", " and ")
            .replace(Regex("(\\d)\\s*%"), "$1 percent")
            .replace(Regex("(\\d)\\s*\u00B0\\s*C\\b"), "$1 degrees Celsius")
            .replace(Regex("(\\d)\\s*\u00B0\\s*F\\b"), "$1 degrees Fahrenheit")
            .replace(Regex("[*_`#]+"), "")
            .replace(Regex("\\.{2,}|\u2026"), ", ")

        // a line break is a breath: after punctuation it is just a space,
        // otherwise it becomes a full stop
        s = s.replace(Regex("([.:;!?])\\s*\\n+\\s*"), "$1 ")
        s = s.replace(Regex("\\s*\\n+\\s*"), ". ")

        return s
            .replace(Regex("\\s+,"), ",")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }
}
