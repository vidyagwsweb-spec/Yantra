package `in`.yantra.assistant.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg

/**
 * The orb, matched to the reference: a warm gold sphere with a pale sweep
 * crossing it. The "ground" is the gold; the clouds are cream, white and two
 * golds, so as they orbit the sweep drifts across the surface.
 */
private val ORB_CLOUDS = intArrayOf(
    0xFFFFFFFF.toInt(), // the pale sweep
    0xFFFFF0B8.toInt(), // cream
    0xFFFAD24A.toInt(), // gold
    0xFFF3B93A.toInt()  // deeper gold
)
private val ORB_GROUND = intArrayOf(0xFFF9D54F.toInt(), 0xFFF2BE3F.toInt())
private val ORB_GLOW = 0xFFF9D54F.toInt()

/** The panel is always dark: it sits on a fade to black, so its ink is always light. */
private val InkOnDark = Color.White
private val InkOnDarkDim = Color.White.copy(alpha = 0.62f)

/** Phrased the way people talk, so the examples teach what works. */
private val CHIPS = listOf(
    "make the screen brighter",
    "turn the flashlight on",
    "set a timer for ten minutes",
    "who is the prime minister of india"
)

private enum class Mode { Listening, Working, Answer, Idle }

/**
 * The summon screen.
 *
 * Whatever you were doing stays visible behind it, blurred (see
 * AssistActivity) and fading to black toward the bottom. Everything Yantra
 * says sits on that black, and one bar holds the controls:
 *
 *     +        (orb)        x
 *
 * `+` opens the typing field, the orb is the microphone, `x` closes.
 *
 * Above the bar it shows exactly one thing at a time:
 *
 *   Listening  the words as you say them
 *   Working    the command it heard
 *   Answer     the reply, and where it came from
 *   Idle       a prompt, any error, and a few things to try
 */
@Composable
fun AssistPanel(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    transcript: String,
    notice: String,
    blurred: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenLink: (String) -> Unit,
    onClose: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    var typing by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    // messages[0] is the app's greeting; it is not part of this summon.
    val last = messages.lastOrNull()
    val inSession = messages.size > 1
    val pending = inSession && last?.fromUser == true
    val reply = if (inSession && last?.fromUser == false) last else null
    val lastUser = messages.lastOrNull { it.fromUser }

    val mode = when {
        listening -> Mode.Listening
        busy || pending -> Mode.Working
        reply != null -> Mode.Answer
        else -> Mode.Idle
    }

    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    val noRipple = remember { MutableInteractionSource() }

    fun submit() {
        val text = input.trim()
        if (text.isNotEmpty()) {
            input = ""
            onSend(text)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ------------------------------------------------------------ scrim
        // Clear at the top, so the app behind is still recognisable, then a
        // fade to solid black for the bottom third. When the system cannot blur
        // what is behind (older Android, battery saver) the top is dimmed more
        // so the text stays readable on a busy screen.
        val top = if (blurred) 0.12f else 0.50f
        val mid = if (blurred) 0.26f else 0.62f
        AnimatedVisibility(
            visibleState = visible,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(tween(240))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.00f to Color.Black.copy(alpha = top),
                            0.52f to Color.Black.copy(alpha = mid),
                            0.70f to Color.Black.copy(alpha = 0.82f),
                            0.84f to Color.Black
                        )
                    )
                    .clickable(interactionSource = noRipple, indication = null) { onClose() }
            )
        }

        // -------------------------------------------------- everything lower
        AnimatedVisibility(
            visibleState = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it / 3 } +
                fadeIn(tween(220))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(bottom = 18.dp)
            ) {
                // ------------------------------------------- the one thing
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 330.dp)
                        // taps on the answer must not fall through to the scrim and close the panel
                        .clickable(interactionSource = noRipple, indication = null) { }
                        .padding(horizontal = 28.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Crossfade(
                        targetState = mode,
                        animationSpec = tween(200),
                        label = "mode"
                    ) { m ->
                        when (m) {
                            Mode.Listening -> Text(
                                text = transcript.ifEmpty { "Listening\u2026" },
                                style = MaterialTheme.typography.headlineMedium,
                                color = if (transcript.isEmpty()) InkOnDarkDim else InkOnDark,
                                maxLines = 5,
                                overflow = TextOverflow.Ellipsis
                            )

                            Mode.Working -> Text(
                                text = lastUser?.text.orEmpty(),
                                style = MaterialTheme.typography.headlineMedium,
                                color = InkOnDarkDim,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )

                            Mode.Answer -> {
                                val text = reply?.text.orEmpty()
                                val short = text.length <= 72 && !text.contains('\n')
                                Column(
                                    modifier = Modifier
                                        .heightIn(max = 300.dp)
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    Text(
                                        text = lastUser?.text.orEmpty(),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = InkOnDarkDim,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = text,
                                        style = if (short) MaterialTheme.typography.headlineMedium
                                        else MaterialTheme.typography.bodyLarge,
                                        color = InkOnDark
                                    )
                                    val src = reply?.source.orEmpty()
                                    val link = reply?.link.orEmpty()
                                    if (src.isNotEmpty() && link.isNotEmpty()) {
                                        Spacer(Modifier.height(14.dp))
                                        Text(
                                            text = "$src \u2197",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = ORB_GLOW_COLOR,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(50))
                                                .background(Color.White.copy(alpha = 0.10f))
                                                .clickable { onOpenLink(link) }
                                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }

                            Mode.Idle -> Column {
                                if (notice.isNotEmpty()) {
                                    Text(
                                        text = notice,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = ORB_GLOW_COLOR
                                    )
                                    Spacer(Modifier.height(8.dp))
                                }
                                Text(
                                    text = "What can I do for you?",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = InkOnDark
                                )
                                Spacer(Modifier.height(18.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CHIPS.forEach { c -> Chip(c) { onSend(c) } }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                // ------------------------------- the typing pill, faint until used
                val pillAlpha = if (typing || input.isNotEmpty()) 0.14f else 0.07f
                Row(
                    modifier = Modifier
                        .padding(horizontal = 24.dp)
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = pillAlpha))
                        .clickable(interactionSource = noRipple, indication = null) {
                            typing = true
                            focus.requestFocus()
                        }
                        .padding(start = 20.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focus)
                            // typing and talking do not mix: focusing the field stops the mic
                            .onFocusChanged {
                                typing = it.isFocused
                                if (it.isFocused && listening) onMic()
                            },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = InkOnDark),
                        cursorBrush = SolidColor(InkOnDark),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { submit() }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (input.isEmpty()) {
                                    Text(
                                        text = "Type a command",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.40f)
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    if (input.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .clickable { submit() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowUpward,
                                contentDescription = "Send",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                // ------------------------------------------------ the bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 26.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BarButton(
                        icon = Icons.Rounded.Add,
                        description = "Type a command",
                        onClick = {
                            typing = true
                            focus.requestFocus()
                        }
                    )
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Orb(listening = listening, working = busy || pending, onClick = onMic)
                    }
                    BarButton(
                        icon = Icons.Rounded.Close,
                        description = "Close",
                        onClick = onClose
                    )
                }
            }
        }
    }
}

private val ORB_GLOW_COLOR = Color(0xFFFAD24A)

@Composable
private fun BarButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = InkOnDark,
            modifier = Modifier.size(30.dp)
        )
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = InkOnDark,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

/**
 * The orb is the microphone. It breathes on its own; while listening it
 * breathes faster and fills out, and while working it holds that livelier
 * state so you can see it thinking.
 */
@Composable
private fun Orb(listening: Boolean, working: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(104.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { ctx ->
                BlobView(ctx).apply {
                    palette = ORB_CLOUDS
                    ground = ORB_GROUND
                    glowColor = ORB_GLOW
                    maxFps = 60
                }
            },
            modifier = Modifier.size(104.dp),
            update = { view -> view.listening = listening || working }
        )
    }
}
