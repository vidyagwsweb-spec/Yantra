package `in`.yantra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg

/** Warm palette for the summon orb: amber to cream, matching the app icon. */
private val ORB_WARM = intArrayOf(
    0xFFF6C368.toInt(),
    0xFFFFF3D0.toInt(),
    0xFFE8A33D.toInt(),
    0xFFFFE9B0.toInt()
)

/**
 * The summon screen.
 *
 * Full-bleed dimmed backdrop, a black bar along the bottom, one large orb in the
 * middle with a plus on the left and a cross on the right. Nothing else — the
 * mic is already listening when this opens.
 */
@Composable
fun AssistPanel(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onClose: () -> Unit
) {
    var typing by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val last = messages.lastOrNull()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.45f), Color.Black.copy(alpha = 0.88f))
                )
            )
            .clickable { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                // swallow taps so they do not reach the scrim behind
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (last != null) {
                Text(
                    text = last.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (last.fromUser) Color.White.copy(alpha = 0.55f) else Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    modifier = Modifier.padding(horizontal = 40.dp, vertical = 16.dp)
                )
            }

            if (typing) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    placeholder = {
                        Text(
                            "Ask anything\u2026",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyMedium,
                    singleLine = true,
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.White.copy(alpha = 0.5f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
                        focusedContainerColor = Color.Black.copy(alpha = 0.5f),
                        unfocusedContainerColor = Color.Black.copy(alpha = 0.5f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White
                    )
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "send",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color.White.copy(alpha = 0.15f))
                            .clickable {
                                val t = input
                                input = ""
                                typing = false
                                onSend(t)
                            }
                            .padding(horizontal = 22.dp, vertical = 10.dp)
                    )
                }
            }

            // ------------------------------------------------------- bottom bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // plus: type instead of speak
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .clickable { typing = !typing },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "+",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White
                    )
                }

                // the orb is the microphone
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx -> BlobView(ctx).apply { palette = ORB_WARM } },
                        modifier = Modifier.size(110.dp),
                        update = { view ->
                            view.palette = ORB_WARM
                            view.listening = listening || busy
                        }
                    )
                }

                // cross: dismiss
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "\u00d7",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White
                    )
                }
            }
        }
    }
}
