package `in`.yantra.assistant.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg

/** The app's own warm set: ember, amber, sky, plum. Reads well on paper and on night. */
private val ORB_WARM = intArrayOf(
    0xFFE8622A.toInt(),
    0xFFF6B955.toInt(),
    0xFF8FB0C4.toInt(),
    0xFF5C2A22.toInt()
)

/** Phrased the way people talk, so the examples teach what works. */
private val CHIPS = listOf(
    "make the screen brighter",
    "turn the flashlight on",
    "set a timer for ten minutes",
    "what's on my calendar"
)

private enum class Mode { Listening, Working, Answer, Idle }

/**
 * The summon sheet.
 *
 * A floating card that rises over whatever app you were in. It shows exactly
 * one thing at a time:
 *
 *   Listening  the words as you say them
 *   Working    the command it heard
 *   Answer     the command, and the reply
 *   Idle       a prompt, any error, and a few things to try
 *
 * Below that: a text field for typing, and the orb, which is the mic.
 */
@Composable
fun AssistPanel(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    transcript: String,
    notice: String,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onClose: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var input by remember { mutableStateOf("") }

    // messages[0] is the app's greeting; it is not part of this summon.
    val last = messages.lastOrNull()
    val inSession = messages.size > 1
    val pending = inSession && last?.fromUser == true
    val reply = if (inSession && last?.fromUser == false) last else null
    val lastUser = messages.lastOrNull { it.fromUser }

    val mode = when {
        listening -> Mode.Listening
        busy || pending -> Mode.Working
        reply != null -> Mode.Answer
        else -> Mode.Idle
    }

    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    val noRipple = remember { MutableInteractionSource() }
    val noRipple2 = remember { MutableInteractionSource() }
    val sheetShape = RoundedCornerShape(36.dp)

    fun submit() {
        val text = input.trim()
        if (text.isNotEmpty()) {
            input = ""
            onSend(text)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ------------------------------------------------------------ scrim
        AnimatedVisibility(
            visibleState = visible,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(tween(260))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.28f),
                                Color(0xFF120E0B).copy(alpha = 0.86f)
                            )
                        )
                    )
                    // a warm glow rising from behind the sheet
                    .drawBehind {
                        drawRect(
                            Brush.radialGradient(
                                colors = listOf(Ember.copy(alpha = 0.30f), Color.Transparent),
                                center = Offset(size.width / 2f, size.height),
                                radius = size.width * 0.95f
                            )
                        )
                    }
                    .clickable(interactionSource = noRipple, indication = null) { onClose() }
            )
        }

        // ------------------------------------------------------------ sheet
        AnimatedVisibility(
            visibleState = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it } +
                fadeIn(tween(200))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(20.dp, sheetShape)
                        .clip(sheetShape)
                        .background(colors.surface)
                        .border(1.dp, colors.outline, sheetShape)
                        // taps on the sheet must not fall through to the scrim
                        .clickable(interactionSource = noRipple2, indication = null) { }
                        .padding(start = 22.dp, end = 16.dp, top = 10.dp, bottom = 16.dp)
                ) {
                    // grab handle
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(36.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(colors.onSurfaceVariant.copy(alpha = 0.30f))
                    )

                    // identity + close
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Yantra",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.onSurfaceVariant
                        )
                        Spacer(Modifier.weight(1f))
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(colors.surfaceVariant)
                                .clickable { onClose() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = colors.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // ------------------------------------------- the one thing
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 132.dp)
                            .padding(top = 6.dp, end = 6.dp)
                    ) {
                        Crossfade(
                            targetState = mode,
                            animationSpec = tween(200),
                            label = "mode"
                        ) { m ->
                            when (m) {
                                Mode.Listening -> Column {
                                    StatusLabel("Listening", colors.primary)
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = transcript.ifEmpty { "Go ahead, I\u2019m listening" },
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = if (transcript.isEmpty()) colors.onSurfaceVariant
                                        else colors.onSurface,
                                        maxLines = 4,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Mode.Working -> Column {
                                    StatusLabel("Working on it", colors.primary)
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = lastUser?.text.orEmpty(),
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = colors.onSurfaceVariant,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Mode.Answer -> {
                                    val text = reply?.text.orEmpty()
                                    val short = text.length <= 72 && !text.contains('\n')
                                    Column {
                                        Text(
                                            text = "\u201C${lastUser?.text.orEmpty()}\u201D",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = colors.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Column(
                                            modifier = Modifier
                                                .heightIn(max = 240.dp)
                                                .verticalScroll(rememberScrollState())
                                        ) {
                                            Text(
                                                text = text,
                                                style = if (short) MaterialTheme.typography.headlineMedium
                                                else MaterialTheme.typography.bodyLarge,
                                                color = colors.onSurface
                                            )
                                        }
                                    }
                                }

                                Mode.Idle -> Column {
                                    if (notice.isNotEmpty()) {
                                        Text(
                                            text = notice,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = colors.primary
                                        )
                                        Spacer(Modifier.height(6.dp))
                                    }
                                    Text(
                                        text = "What can I do for you?",
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = colors.onSurface
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    Row(
                                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        CHIPS.forEach { c -> Chip(c) { onSend(c) } }
                                    }
                                }
                            }
                        }
                    }

                    // -------------------------------------------------- controls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(colors.surfaceVariant)
                                .padding(start = 20.dp, end = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier
                                    .weight(1f)
                                    // typing and talking do not mix: focusing the field stops the mic
                                    .onFocusChanged { if (it.isFocused && listening) onMic() },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = colors.onSurface),
                                cursorBrush = SolidColor(colors.primary),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = { submit() }),
                                decorationBox = { inner ->
                                    Box(contentAlignment = Alignment.CenterStart) {
                                        if (input.isEmpty()) {
                                            Text(
                                                text = "Type a command",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = colors.onSurfaceVariant
                                            )
                                        }
                                        inner()
                                    }
                                }
                            )
                            if (input.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(colors.primary)
                                        .clickable { submit() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ArrowUpward,
                                        contentDescription = "Send",
                                        tint = colors.onPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.width(8.dp))

                        MicOrb(listening = listening, working = busy || pending, onClick = onMic)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusLabel(text: String, color: Color) {
    Text(text = text, style = MaterialTheme.typography.labelMedium, color = color)
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(colors.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(start = 8.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(Brush.radialGradient(listOf(Amber, Clay)), CircleShape)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = colors.onSurface
        )
    }
}

/** The orb is the microphone. Rings ripple outward only while it is listening. */
@Composable
private fun MicOrb(listening: Boolean, working: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (listening) Rings()
        AndroidView(
            factory = { ctx -> BlobView(ctx).apply { palette = ORB_WARM } },
            modifier = Modifier.size(58.dp),
            update = { view ->
                view.palette = ORB_WARM
                view.listening = listening || working
            }
        )
    }
}

@Composable
private fun Rings() {
    val infinite = rememberInfiniteTransition(label = "rings")
    val p by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1700, easing = LinearEasing)),
        label = "p"
    )
    Canvas(modifier = Modifier.fillMaxSize()) {
        val maxR = size.minDimension / 2f
        val minR = maxR * 0.76f
        for (k in 0..1) {
            val q = (p + k * 0.5f) % 1f
            drawCircle(
                color = Ember.copy(alpha = (1f - q) * 0.45f),
                radius = minR + (maxR - minR) * q,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}
