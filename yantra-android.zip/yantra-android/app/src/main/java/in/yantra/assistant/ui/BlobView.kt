package `in`.yantra.assistant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.provider.Settings
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * The animated blob.
 *
 * Four colour clouds orbit inside a circular clip, each drawn as a radial
 * gradient that fades to fully transparent at its rim, which gives the soft
 * "liquid" edge without needing a blur pass, so it stays cheap on old phones.
 *
 * **It breathes.** The whole orb swells and settles on a slow sine, like a
 * chest at rest: about a 4.8 second breath while idle, quickening to about 2.2
 * seconds while the mic is open. Every moving value is integrated from the
 * frame time, not read from a looping animator, so switching between idle and
 * listening eases instead of jumping, and the breath never skips a beat when
 * the speed changes.
 *
 * Used both inside Compose (via AndroidView) and in the floating overlay.
 */
class BlobView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Livelier while the mic is open: faster breath, faster orbit, fuller orb. Eased, not snapped. */
    var listening: Boolean = false
        set(value) {
            field = value
            kick()
        }

    /** Swap these four for the warm Valley set if you want it to match the UI. */
    var palette: IntArray = intArrayOf(
        0xFF4285F4.toInt(), // blue
        0xFFEA4335.toInt(), // red
        0xFFFBBC05.toInt(), // yellow
        0xFF34A853.toInt()  // green
    )
        set(value) {
            field = value
            invalidate()
        }

    /** The orb's ground, centre then rim. The default is a cool near-white so colours read cleanly. */
    var ground: IntArray = intArrayOf(Color.WHITE, 0xFFF1EEEA.toInt())
        set(value) {
            field = value
            invalidate()
        }

    /**
     * A soft halo that swells with each breath. 0 means none. When it is set the
     * orb is drawn at 80% of the view so the halo has room inside the bounds.
     */
    var glowColor: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    /** Off holds the orb still at full size, for the places that want it calm. */
    var breathing: Boolean = true
        set(value) {
            field = value
            kick()
        }

    /** Upper bound on redraws per second. A few small blobs are happy at 30; a hero orb at 60. */
    var maxFps: Int = 30

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()

    // all three are integrated from the frame time in onDraw
    private var orbit = 0f      // radians
    private var breath = 0f     // radians
    private var level = 0f      // 0 idle .. 1 listening, eased

    private var lastFrameAt = 0L
    private var running = false
    private var motionOk = true

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isShown) resume()
    }

    override fun onDetachedFromWindow() {
        pause()
        super.onDetachedFromWindow()
    }

    // Never animate a view nobody can see: backgrounded app, collapsed sheet,
    // another screen on top.
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resume() else pause()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resume() else pause()
    }

    private fun resume() {
        if (running) return
        running = true
        lastFrameAt = 0L
        // "Remove animations" in developer options or accessibility: draw once, stay still
        motionOk = try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
        } catch (e: Exception) {
            true
        }
        invalidate()
    }

    private fun pause() {
        running = false
    }

    /** A state flipped: make sure frames are being drawn so the change eases in. */
    private fun kick() {
        if (isAttachedToWindow && isShown) resume()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val frameStart = SystemClock.uptimeMillis()
        val dt = if (lastFrameAt == 0L) 16L else (frameStart - lastFrameAt).coerceIn(1L, 100L)
        lastFrameAt = frameStart

        val target = if (listening) 1f else 0f
        if (motionOk) {
            // exponential ease, about 140 ms to settle
            level += (target - level) * (1f - exp(-dt / 140f))
            orbit += dt * (2f * PI.toFloat() / 7000f) * (1f + 0.9f * level)
            val breathMs = 4800f - 2600f * level
            if (breathing) breath += dt * (2f * PI.toFloat() / breathMs)
        } else {
            level = target
        }

        paintOrb(canvas)

        if (running && motionOk) {
            if (maxFps >= 60) {
                postInvalidateOnAnimation()
            } else {
                val interval = 1000L / maxFps.coerceIn(10, 60)
                val spent = SystemClock.uptimeMillis() - frameStart
                postInvalidateDelayed((interval - spent).coerceAtLeast(0L))
            }
        }
    }

    private fun paintOrb(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val half = min(width, height) / 2f
        if (half <= 0f) return

        // 0 at the bottom of the breath, 1 at the top; eased at both ends
        val inhale = if (breathing && motionOk) 0.5f - 0.5f * cos(breath) else 1f

        val base = half * (if (glowColor != 0) 0.80f else 1.0f)
        // idle: 88%..100% of the room, listening: 95%..100%
        val scale = lerp(0.88f, 0.95f, level) + lerp(0.12f, 0.05f, level) * inhale
        val r = base * scale
        if (r <= 0f) return

        // ---- halo, outside the clip
        if (glowColor != 0) {
            val a = ((70f + 70f * inhale) * (0.7f + 0.3f * level)).toInt()
            paint.shader = RadialGradient(
                cx, cy, half,
                intArrayOf(withAlpha(glowColor, a), withAlpha(glowColor, a), withAlpha(glowColor, 0)),
                floatArrayOf(0f, (r / half).coerceIn(0.05f, 0.99f), 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, half, paint)
        }

        canvas.save()
        clip.reset()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        canvas.clipPath(clip)

        paint.shader = RadialGradient(
            cx, cy, r * 1.05f,
            intArrayOf(ground[0], ground.getOrElse(1) { ground[0] }),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        val orbitR = r * lerp(0.34f, 0.40f, level)
        // the clouds swell a little with the breath too, so the inside moves with the outside
        val cloud = 0.96f + 0.08f * inhale

        for (i in 0..3) {
            val p = orbit + i * (2f * PI.toFloat() / 4f)
            val bx = cx + cos(p) * orbitR
            val by = cy + sin(p * 1.27f) * orbitR * 0.92f
            val br = r * (0.62f + 0.14f * sin(p * 2.1f + i)) * cloud

            val core = palette[i % palette.size]
            paint.shader = RadialGradient(
                bx, by, br,
                intArrayOf(
                    withAlpha(core, 250),
                    withAlpha(core, 185),
                    withAlpha(core, 0)
                ),
                floatArrayOf(0f, 0.42f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(bx, by, br, paint)
        }

        // glassy highlight, top-left
        paint.shader = RadialGradient(
            cx - r * 0.34f, cy - r * 0.36f, r * 0.62f,
            intArrayOf(withAlpha(Color.WHITE, (70f + 30f * inhale).toInt()), 0x00FFFFFF),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        canvas.restore()
        paint.shader = null
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
