package `in`.yantra.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The animated blob.
 *
 * Four colour clouds orbit inside a circular clip, each drawn as a radial
 * gradient that fades to fully transparent at its rim — which gives the soft
 * "liquid" edge without needing a blur pass, so it stays cheap on old phones.
 *
 * Used both inside Compose (via AndroidView) and in the floating overlay.
 */
class BlobView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Bigger and livelier while the mic is open. */
    var listening: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    /** Swap these four for the warm Valley set if you want it to match the UI. */
    var palette: IntArray = intArrayOf(
        0xFF4285F4.toInt(), // blue
        0xFFEA4335.toInt(), // red
        0xFFFBBC05.toInt(), // yellow
        0xFF34A853.toInt()  // green
    )
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private var phase = 0f

    // A slow-moving gradient does not need 60fps. 24 halves the draw calls and
    // is indistinguishable on screen.
    private var lastFrameAt = 0L
    private val frameIntervalMs = 1000L / 24L

    private val animator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 7000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameAt >= frameIntervalMs) {
                lastFrameAt = now
                invalidate()
            }
        }
    }

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isShown) resumeAnimation()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    // Never animate a view nobody can see: backgrounded app, collapsed sheet,
    // another screen on top.
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resumeAnimation() else pauseAnimation()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) resumeAnimation() else pauseAnimation()
    }

    private fun resumeAnimation() {
        if (!animator.isStarted) animator.start()
        else if (animator.isPaused) animator.resume()
    }

    private fun pauseAnimation() {
        if (animator.isStarted && !animator.isPaused) animator.pause()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f
        val r = base * if (listening) 1.0f else 0.94f
        if (r <= 0f) return

        canvas.save()
        clip.reset()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        canvas.clipPath(clip)

        // cool, near-white ground so the colours read cleanly
        paint.shader = RadialGradient(
            cx, cy, r * 1.05f,
            intArrayOf(Color.WHITE, 0xFFF1EEEA.toInt()),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        val orbit = r * (if (listening) 0.40f else 0.34f)
        val speed = if (listening) 1.9f else 1f

        for (i in 0..3) {
            val p = phase * speed + i * (2 * PI.toFloat() / 4f)
            val bx = cx + cos(p) * orbit
            val by = cy + sin(p * 1.27f) * orbit * 0.92f
            val br = r * (0.62f + 0.14f * sin(p * 2.1f + i))

            val core = palette[i % palette.size]
            paint.shader = RadialGradient(
                bx, by, br,
                intArrayOf(
                    withAlpha(core, 250),
                    withAlpha(core, 185),
                    withAlpha(core, 0)
                ),
                floatArrayOf(0f, 0.42f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(bx, by, br, paint)
        }

        // glassy highlight, top-left, like the reference orb
        paint.shader = RadialGradient(
            cx - r * 0.34f, cy - r * 0.36f, r * 0.62f,
            intArrayOf(0x55FFFFFF, 0x00FFFFFF),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)

        canvas.restore()
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}
