package `in`.yantra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.ChatMsg
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext

// Phrased the way people talk, so the examples teach what works.
private val SUGGESTIONS = listOf(
    "turn the flashlight on",
    "make the screen a bit dimmer",
    "turn the volume up to 40",
    "set a timer for ten minutes",
    "call mom",
    "what's on my calendar",
    "battery"
)

@Composable
fun ChatScreen(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    timerLeft: String,
    transcript: String = "",
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenSettings: () -> Unit = {}
) {
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val colors = MaterialTheme.colorScheme

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // ------------------------------------------------ floating header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(colors.surface.copy(alpha = 0.92f))
                    .border(1.dp, colors.outline, RoundedCornerShape(28.dp))
                    .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 10.dp)
            ) {
                // row 1: identity
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AndroidView(
                        factory = { ctx -> BlobView(ctx) },
                        modifier = Modifier.size(26.dp),
                        update = { it.listening = listening || busy }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Yantra",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.onSurface
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when {
                            busy -> "working"
                            listening -> "listening"
                            else -> "on device"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurfaceVariant
                    )

                    Spacer(Modifier.weight(1f))

                    if (timerLeft.isNotEmpty()) {
                        Text(
                            text = timerLeft,
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.primary,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable { onOpenSettings() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Settings",
                            tint = colors.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable { onToggleTheme() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (dark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            contentDescription = if (dark) "Switch to light theme" else "Switch to dark theme",
                            tint = colors.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // ------------------------------------------------------------- hero
            if (messages.size <= 1) {
                Column(modifier = Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
                    Text(
                        text = "Ask for\nanything.",
                        style = MaterialTheme.typography.displayLarge,
                        color = colors.onBackground
                    )
                    Spacer(Modifier.size(12.dp))
                    Text(
                        text = "Say it however you like \u2014 \u201cmake it a bit louder\u201d, \u201cdim the screen by 30%\u201d, \u201cturn the flashlight on\u201d. Say \u201chelp\u201d for everything I can do.\n\nTo summon me over other apps, add the \u201cAsk Yantra\u201d Quick Settings tile, or set Yantra as your assistant app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.onSurfaceVariant
                    )
                }
            }

            // -------------------------------------------------------- transcript
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg -> Bubble(msg) }
                item { Spacer(Modifier.size(4.dp)) }
            }

            // --------------------------------------------------- suggestion pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SUGGESTIONS.forEach { s ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(colors.surface)
                            .border(1.dp, colors.outline, RoundedCornerShape(50))
                            .clickable { onSend(s) }
                            .padding(start = 8.dp, end = 16.dp, top = 9.dp, bottom = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .background(
                                    Brush.radialGradient(listOf(Amber, Clay)),
                                    CircleShape
                                )
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = s,
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.onSurface
                        )
                    }
                }
            }

            // ----------------------------------------------------------- composer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text(
                            "Type a command\u2026",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.onSurfaceVariant
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyMedium,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        val t = input.trim()
                        if (t.isNotEmpty()) {
                            input = ""
                            onSend(t)
                        }
                    }),
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.primary,
                        unfocusedBorderColor = colors.outline,
                        focusedContainerColor = colors.surface,
                        unfocusedContainerColor = colors.surface
                    )
                )

                Spacer(Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            if (input.isNotBlank()) colors.primary
                            else colors.onSurfaceVariant.copy(alpha = 0.25f)
                        )
                        .clickable {
                            val t = input.trim()
                            if (t.isNotEmpty()) {
                                input = ""
                                onSend(t)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowUpward,
                        contentDescription = "Send",
                        tint = colors.onPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(Modifier.width(8.dp))

                // the orb is the microphone
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx -> BlobView(ctx) },
                        modifier = Modifier.size(52.dp),
                        update = { it.listening = listening }
                    )
                }
            }
        }

        // ---------------------------------------------- listening, full screen
        if (listening) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(colors.background.copy(alpha = 0.93f))
                    .clickable { onMic() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AndroidView(
                        factory = { ctx -> BlobView(ctx) },
                        modifier = Modifier.size(168.dp),
                        update = { it.listening = true }
                    )
                    Spacer(Modifier.size(28.dp))
                    Text(
                        text = "Listening\u2026",
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.onBackground
                    )
                    if (transcript.isNotEmpty()) {
                        Spacer(Modifier.size(14.dp))
                        Text(
                            text = transcript,
                            style = MaterialTheme.typography.headlineMedium,
                            color = colors.onBackground,
                            textAlign = TextAlign.Center,
                            maxLines = 4,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "tap anywhere to stop",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun Bubble(msg: ChatMsg) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 24.dp,
                        topEnd = 24.dp,
                        bottomStart = if (msg.fromUser) 24.dp else 6.dp,
                        bottomEnd = if (msg.fromUser) 6.dp else 24.dp
                    )
                )
                .background(if (msg.fromUser) colors.onBackground else colors.surface)
                .then(
                    if (msg.fromUser) Modifier
                    else Modifier.border(
                        1.dp, colors.outline,
                        RoundedCornerShape(
                            topStart = 24.dp, topEnd = 24.dp,
                            bottomStart = 6.dp, bottomEnd = 24.dp
                        )
                    )
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Column {
                Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (msg.fromUser) colors.background else colors.onSurface
                )
                if (!msg.fromUser && msg.source.isNotEmpty() && msg.link.isNotEmpty()) {
                    val context = LocalContext.current
                    Text(
                        text = "${msg.source} \u2197",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.primary,
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .clickable {
                                try {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse(msg.link))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) { /* no browser */ }
                            }
                    )
                }
            }
        }
    }
}
