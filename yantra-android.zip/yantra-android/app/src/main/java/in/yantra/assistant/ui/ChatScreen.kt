package `in`.yantra.assistant.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import `in`.yantra.assistant.ChatMsg

// Phrased the way people talk, so the examples teach what works.
private val SUGGESTIONS = listOf(
    "turn the flashlight on",
    "make the screen a bit dimmer",
    "set a timer for ten minutes",
    "who is the prime minister of india",
    "call mom",
    "what's on my calendar",
    "battery"
)

/**
 * The main screen, in the same language as the wake-up screen: one orb (the
 * app icon) as the microphone, replies as large plain text instead of boxed
 * bubbles, and a pill for typing.
 *
 *   empty    a big breathing orb, a greeting, a few things to try
 *   talking  your lines as ink pills on the right, Yantra's replies as text
 *   listening  the same dark fade as the wake-up screen, with your words on it
 */
@Composable
fun ChatScreen(
    messages: List<ChatMsg>,
    listening: Boolean,
    busy: Boolean,
    timerLeft: String,
    transcript: String = "",
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onOpenSettings: () -> Unit = {}
) {
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val colors = MaterialTheme.colorScheme
    val hero = messages.size <= 1

    LaunchedEffect(messages.size) {
        if (!hero) listState.animateScrollToItem(messages.size - 1)
    }

    fun submit() {
        val t = input.trim()
        if (t.isNotEmpty()) {
            input = ""
            onSend(t)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // a warm wash from the top: the icon's glow, spread across the screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(360.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Ember.copy(alpha = if (dark) 0.14f else 0.09f), Color.Transparent)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            TopBar(
                listening = listening,
                busy = busy,
                timerLeft = timerLeft,
                dark = dark,
                onOpenSettings = onOpenSettings,
                onToggleTheme = onToggleTheme
            )

            if (hero) {
                Hero(
                    greeting = messages.firstOrNull()?.text.orEmpty(),
                    listening = listening || busy,
                    onSend = onSend,
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    item { Spacer(Modifier.height(8.dp)) }
                    items(messages) { msg -> Message(msg) }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }

            // ---------------------------------------------------- composer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 12.dp, top = 6.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(colors.surface)
                        .border(1.dp, colors.outline, RoundedCornerShape(28.dp))
                        .padding(start = 20.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = colors.onSurface),
                        cursorBrush = SolidColor(colors.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { submit() }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (input.isEmpty()) {
                                    Text(
                                        text = "Type a command",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = colors.onSurfaceVariant.copy(alpha = 0.75f)
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    if (input.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(colors.primary)
                                .clickable { submit() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowUpward,
                                contentDescription = "Send",
                                tint = colors.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.width(6.dp))

                // the orb is the microphone
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .semantics { contentDescription = "Microphone" }
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    YantraOrb(listening = listening || busy, size = 68.dp)
                }
            }
        }

        if (listening) ListeningOverlay(transcript = transcript, onStop = onMic)
    }
}

// ----------------------------------------------------------------- pieces

@Composable
private fun TopBar(
    listening: Boolean,
    busy: Boolean,
    timerLeft: String,
    dark: Boolean,
    onOpenSettings: () -> Unit,
    onToggleTheme: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        YantraOrb(listening = listening || busy, size = 34.dp, glow = false)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                text = "Yantra",
                style = MaterialTheme.typography.titleMedium,
                color = colors.onBackground
            )
            Text(
                text = when {
                    busy -> "working"
                    listening -> "listening"
                    else -> "on device"
                },
                style = MaterialTheme.typography.labelMedium,
                color = colors.onSurfaceVariant
            )
        }
        Spacer(Modifier.weight(1f))
        if (timerLeft.isNotEmpty()) {
            Text(
                text = timerLeft,
                style = MaterialTheme.typography.labelMedium,
                color = colors.primary,
                modifier = Modifier
                    .padding(end = 6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(colors.primary.copy(alpha = 0.12f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        IconAction(Icons.Rounded.Settings, "Settings", onOpenSettings)
        IconAction(
            icon = if (dark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
            description = if (dark) "Switch to light theme" else "Switch to dark theme",
            onClick = onToggleTheme
        )
    }
}

@Composable
private fun IconAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
private fun Hero(
    greeting: String,
    listening: Boolean,
    onSend: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = MaterialTheme.colorScheme
    // centred when it fits, scrolls when it does not (small phones, big fonts)
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
    Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            YantraOrb(listening = listening, size = 176.dp, fps = 60)
        }
        Spacer(Modifier.height(20.dp))
        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            Text(
                text = "Ask for\nanything.",
                style = MaterialTheme.typography.displayLarge,
                color = colors.onBackground
            )
            Spacer(Modifier.height(12.dp))
            if (greeting.isNotEmpty()) {
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
            }
            Text(
                text = "Say \u201Chelp\u201D for everything I can do. To summon me over other apps, add the \u201CAsk Yantra\u201D Quick Settings tile or set Yantra as your assistant app.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(20.dp))
        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SUGGESTIONS.forEach { s ->
                Text(
                    text = s,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurface,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.surface)
                        .border(1.dp, colors.outline, RoundedCornerShape(50))
                        .clickable { onSend(s) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }
    }
}
}

/** Your lines are ink pills; Yantra's replies are plain text, large when short, like the wake-up screen. */
@Composable
private fun Message(msg: ChatMsg) {
    val colors = MaterialTheme.colorScheme
    if (msg.fromUser) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.background,
                modifier = Modifier
                    .padding(start = 56.dp)
                    .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomStart = 22.dp, bottomEnd = 6.dp))
                    .background(colors.onBackground)
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            )
        }
    } else {
        val short = msg.text.length <= 72 && !msg.text.contains('\n')
        Column(modifier = Modifier.padding(end = 20.dp)) {
            Text(
                text = msg.text,
                style = if (short) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.bodyLarge,
                color = colors.onBackground
            )
            if (msg.source.isNotEmpty() && msg.link.isNotEmpty()) {
                val context = LocalContext.current
                Text(
                    text = "${msg.source} \u2197",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.primary,
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(colors.primary.copy(alpha = 0.12f))
                        .clickable {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(msg.link))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) { /* no browser */ }
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

/** The wake-up screen's dark fade, with your words on it. Always dark, like the original. */
@Composable
private fun ListeningOverlay(transcript: String, onStop: () -> Unit) {
    val noRipple = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0.00f to Color.Black.copy(alpha = 0.62f),
                    0.50f to Color.Black.copy(alpha = 0.86f),
                    0.78f to Color.Black
                )
            )
            .clickable(interactionSource = noRipple, indication = null) { onStop() }
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 18.dp)
        ) {
            Text(
                text = transcript.ifEmpty { "Listening\u2026" },
                style = MaterialTheme.typography.headlineMedium,
                color = if (transcript.isEmpty()) Color.White.copy(alpha = 0.62f) else Color.White,
                maxLines = 5,
                modifier = Modifier.padding(horizontal = 28.dp)
            )
            Spacer(Modifier.height(32.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 26.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.size(52.dp))
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    YantraOrb(listening = true, size = 104.dp, fps = 60)
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .clickable { onStop() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Stop listening",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
