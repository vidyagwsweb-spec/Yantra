package `in`.yantra.assistant.ui

import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The orb is the app icon: the same warm ground and the same four clouds
 * (ember, amber, sky, plum), so the launcher icon, the summon screen and the
 * app are recognisably one thing. Keep these in step with tools/build-icon.py.
 */
internal val OrbClouds = intArrayOf(
    0xFFE8622A.toInt(), // ember
    0xFFF6B955.toInt(), // amber
    0xFF8FB0C4.toInt(), // sky
    0xFF5C2A22.toInt()  // plum
)
internal val OrbGround = intArrayOf(0xFFFFF1D6.toInt(), 0xFFF2B04A.toInt())
internal val OrbGlow = 0xFFE8622A.toInt()

/** The breathing orb. [glow] adds the soft halo; small orbs in a header look cleaner without. */
@Composable
internal fun YantraOrb(
    listening: Boolean,
    size: Dp,
    modifier: Modifier = Modifier,
    glow: Boolean = true,
    fps: Int = 30
) {
    AndroidView(
        factory = { ctx ->
            BlobView(ctx).apply {
                palette = OrbClouds
                ground = OrbGround
                glowColor = if (glow) OrbGlow else 0
                maxFps = fps
            }
        },
        modifier = modifier.size(size),
        update = { it.listening = listening }
    )
}
