package `in`.yantra.assistant.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.yantra.assistant.speech.VoiceChoice
import `in`.yantra.assistant.util.AppSettings
import `in`.yantra.assistant.util.Languages

/**
 * Settings: voice (a swipeable row of blobs, one per installed voice), accent,
 * speed and pitch, theme, spoken replies, the mini brain, and your name.
 *
 * It is drawn over the chat rather than navigated to, so there is no
 * navigation library; the activity handles the back button.
 */
@Composable
fun SettingsScreen(
    language: String,
    themeMode: String,
    speakReplies: Boolean,
    smartReplies: Boolean,
    lookupAnswers: Boolean,
    rate: Float,
    pitch: Float,
    voices: List<VoiceChoice>,
    selectedVoice: String,
    languageHasVoices: Boolean,
    shortcutCount: Int,
    name: String,
    useModel: Boolean,
    modelStatus: String,
    modelInstalled: Boolean,
    modelBusy: Boolean,
    memoryCount: Int,
    onBack: () -> Unit,
    onLanguage: (String) -> Unit,
    onTheme: (String) -> Unit,
    onSpeak: (Boolean) -> Unit,
    onSmart: (Boolean) -> Unit,
    onLookup: (Boolean) -> Unit,
    onRate: (Float) -> Unit,
    onPitch: (Float) -> Unit,
    onPreviewSpeech: () -> Unit,
    onVoice: (String) -> Unit,
    onInstallVoices: () -> Unit,
    onName: (String) -> Unit,
    onForgetShortcuts: () -> Unit,
    onUseModel: (Boolean) -> Unit,
    onImportModel: (Uri) -> Unit,
    onRemoveModel: () -> Unit,
    onForgetMemory: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImportModel(uri)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            // swallow taps so they never reach the chat underneath
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {}
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ------------------------------------------------------ top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = colors.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.displayMedium,
                    color = colors.onBackground
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {

                // ------------------------------------------------------ voice
                SettingsCard(
                    title = "Voice",
                    subtitle = "Swipe through the voices and tap a blob to hear it."
                ) {
                    if (voices.isEmpty()) {
                        Text(
                            text = "No English voices found yet. The speech engine may still be starting, or none is installed.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.onSurfaceVariant
                        )
                    } else {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            itemsIndexed(voices, key = { _, v -> v.name }) { _, v ->
                                VoiceBlob(
                                    choice = v,
                                    selected = v.name == selectedVoice,
                                    onClick = { onVoice(v.name) }
                                )
                            }
                        }
                        if (!languageHasVoices) {
                            Text(
                                text = "No voice for this accent is installed, so every English voice is shown.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.onSurfaceVariant
                            )
                        }
                    }

                    LabelledSlider(
                        label = "Speed",
                        valueText = "%.1fx".format(rate),
                        value = rate,
                        range = 0.5f..1.8f,
                        onChange = onRate,
                        onFinished = onPreviewSpeech
                    )
                    LabelledSlider(
                        label = "Pitch",
                        valueText = "%.1f".format(pitch),
                        value = pitch,
                        range = 0.7f..1.4f,
                        onChange = onPitch,
                        onFinished = onPreviewSpeech
                    )

                    TextButton(onClick = onInstallVoices) {
                        Text("Get more voices", style = MaterialTheme.typography.labelLarge)
                    }
                }

                // -------------------------------------------------- language
                SettingsCard(
                    title = "Language",
                    subtitle = "Sets the accent I listen for and speak in. I understand commands in English."
                ) {
                    Languages.ALL.forEach { lang ->
                        val selected = lang.tag.equals(language, ignoreCase = true)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (selected) colors.primary.copy(alpha = 0.10f) else Color.Transparent)
                                .clickable { onLanguage(lang.tag) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = lang.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colors.onSurface
                                )
                                Text(
                                    text = lang.note,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.onSurfaceVariant
                                )
                            }
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "Selected",
                                    tint = colors.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // --------------------------------------------------- general
                SettingsCard(title = "General") {
                    Text(
                        text = "Theme",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.onSurface
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemePill("System", themeMode == AppSettings.THEME_SYSTEM, Modifier.weight(1f)) {
                            onTheme(AppSettings.THEME_SYSTEM)
                        }
                        ThemePill("Light", themeMode == AppSettings.THEME_LIGHT, Modifier.weight(1f)) {
                            onTheme(AppSettings.THEME_LIGHT)
                        }
                        ThemePill("Dark", themeMode == AppSettings.THEME_DARK, Modifier.weight(1f)) {
                            onTheme(AppSettings.THEME_DARK)
                        }
                    }

                    SwitchRow(
                        title = "Speak replies aloud",
                        subtitle = "Off keeps replies on screen only.",
                        checked = speakReplies,
                        onChange = onSpeak
                    )

                    var typed by remember { mutableStateOf(name) }
                    Text(
                        text = "Your name",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.onSurface
                    )
                    OutlinedTextField(
                        value = typed,
                        onValueChange = {
                            typed = it
                            onName(it)
                        },
                        singleLine = true,
                        placeholder = { Text("What should I call you?") },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // --------------------------------------------------- answers
                SettingsCard(title = "Answers") {
                    SwitchRow(
                        title = "Look up answers",
                        subtitle = "Questions like \u201Cwho is\u2026\u201D, \u201Cwhat is\u2026\u201D and \u201Cdefine\u2026\u201D are answered here from Wikipedia and a free dictionary. Off, or when nothing is found, opens Google. Only the question leaves the phone.",
                        checked = lookupAnswers,
                        onChange = onLookup
                    )
                }

                // ------------------------------------------------ intelligence
                SettingsCard(
                    title = "Thinking",
                    subtitle = "An optional language model that runs on this phone. No account, no key, nothing leaves the device."
                ) {
                    SwitchRow(
                        title = "Use the language model",
                        subtitle = "Understands free-form requests and Hinglish, answers questions in your words, and keeps the conversation in mind. Messages, calls and deletions still wait for your yes.",
                        checked = useModel,
                        onChange = onUseModel
                    )
                    Text(
                        text = modelStatus,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            enabled = !modelBusy,
                            onClick = { modelPicker.launch(arrayOf("*/*")) }
                        ) {
                            Text(
                                if (modelInstalled) "Replace model file" else "Choose model file",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        if (modelInstalled) {
                            TextButton(enabled = !modelBusy, onClick = onRemoveModel) {
                                Text("Remove", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                    Text(
                        text = "Pick a MediaPipe .task file, such as Gemma 3 1B (about 550 MB) or Qwen 2.5 0.5B. Get one from the LiteRT Community on Hugging Face. A phone with 6 GB of RAM or more is best.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (memoryCount == 1) "1 thing remembered" else "$memoryCount things remembered",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.onSurface
                            )
                            Text(
                                text = "Try \u201Cremember that I am vegetarian\u201D or \u201Cmy birthday is 3 March\u201D. Stored only here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.onSurfaceVariant
                            )
                        }
                        if (memoryCount > 0) {
                            TextButton(onClick = onForgetMemory) {
                                Text("Forget all", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }

                // ----------------------------------------------------- brain
                SettingsCard(title = "Mini brain") {
                    SwitchRow(
                        title = "Smart replies",
                        subtitle = "Small talk, a few facts, \u201Cdid you mean\u2026?\u201D for odd phrasing, and shortcuts you teach me. All on this phone.",
                        checked = smartReplies,
                        onChange = onSmart
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (shortcutCount == 1) "1 shortcut taught" else "$shortcutCount shortcuts taught",
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.onSurface
                            )
                            Text(
                                text = "Try saying \u201Cwhen I say movie time, open netflix\u201D.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.onSurfaceVariant
                            )
                        }
                        if (shortcutCount > 0) {
                            TextButton(onClick = onForgetShortcuts) {
                                Text("Forget all", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }

                Text(
                    text = "Yantra \u00B7 everything runs on this phone",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ------------------------------------------------------------------ pieces

@Composable
private fun SettingsCard(
    title: String,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(colors.surface)
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = colors.onSurface
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant
                )
            }
        }
        content()
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = colors.primary,
                uncheckedThumbColor = colors.onSurfaceVariant,
                uncheckedTrackColor = colors.surfaceVariant,
                uncheckedBorderColor = colors.outline
            )
        )
    }
}

@Composable
private fun LabelledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = colors.onSurface,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium,
                color = colors.onSurfaceVariant
            )
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            onValueChangeFinished = onFinished,
            colors = SliderDefaults.colors(
                thumbColor = colors.primary,
                activeTrackColor = colors.primary,
                inactiveTrackColor = colors.surfaceVariant
            )
        )
    }
}

@Composable
private fun ThemePill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) colors.primary else colors.surfaceVariant)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) colors.onPrimary else colors.onSurface
        )
    }
}

/**
 * One voice. The blob is the same animated orb used in the header, painted in
 * colours derived from the voice's name so each voice keeps its own look. The
 * chosen one grows, gets a ring, and swirls faster.
 */
@Composable
private fun VoiceBlob(choice: VoiceChoice, selected: Boolean, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val orbSize by animateDpAsState(if (selected) 96.dp else 70.dp, label = "voice-blob-size")
    val palette = remember(choice.name) { blobPalette(choice.name) }

    Column(
        modifier = Modifier
            .width(108.dp)
            .clip(RoundedCornerShape(24.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.size(96.dp), contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(orbSize)
            ) {
                AndroidView(
                    factory = { ctx -> BlobView(ctx) },
                    modifier = Modifier.fillMaxSize(),
                    update = {
                        it.palette = palette
                        it.glowColor = if (selected) palette[0] else 0
                        it.listening = selected
                    }
                )
            }
        }
        Text(
            text = choice.label,
            style = MaterialTheme.typography.titleMedium,
            color = if (selected) colors.primary else colors.onSurface
        )
        Text(
            text = choice.detail,
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 6.dp)
        )
    }
}

/** Four related colours from a name, so a voice always gets the same look. */
internal fun blobPalette(seed: String): IntArray {
    val hue = ((seed.hashCode() % 360) + 360) % 360
    fun hsv(offset: Int, saturation: Float, value: Float): Int =
        android.graphics.Color.HSVToColor(
            floatArrayOf(((hue + offset) % 360).toFloat(), saturation, value)
        )
    return intArrayOf(
        hsv(0, 0.78f, 0.96f),
        hsv(55, 0.70f, 0.98f),
        hsv(140, 0.62f, 0.95f),
        hsv(220, 0.72f, 0.92f)
    )
}
