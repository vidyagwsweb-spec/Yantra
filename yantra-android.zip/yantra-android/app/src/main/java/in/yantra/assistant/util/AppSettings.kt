package `in`.yantra.assistant.util

/**
 * The few settings that live in Settings, over [Prefs]. Voice, speed and
 * pitch are stored by the speaker itself (`tts.*` keys), so they are not here.
 */
class AppSettings(private val prefs: Prefs) {

    companion object {
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
    }

    var language: String
        get() = prefs.get("lang", Languages.DEFAULT).let { if (Languages.isKnown(it)) it else Languages.DEFAULT }
        set(value) { prefs.set("lang", value) }

    var theme: String
        get() = prefs.get("theme", THEME_SYSTEM)
        set(value) { prefs.set("theme", value) }

    /** Read replies out loud. */
    var speakReplies: Boolean
        get() = prefs.get("speak", "1") == "1"
        set(value) { prefs.set("speak", if (value) "1" else "0") }

    /** Use the mini brain: small talk, "did you mean", taught shortcuts. */
    var smartReplies: Boolean
        get() = prefs.get("smart", "1") == "1"
        set(value) { prefs.set("smart", if (value) "1" else "0") }
}
