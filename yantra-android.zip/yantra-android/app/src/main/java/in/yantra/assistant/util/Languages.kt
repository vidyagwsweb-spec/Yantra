package `in`.yantra.assistant.util

/** One spoken-language choice: the BCP 47 tag Android uses, and what to show. */
data class Lang(val tag: String, val label: String, val note: String)

/**
 * English varieties offered in Settings. Commands are always understood in
 * English; the choice changes how Yantra is heard (speech recognition) and
 * which voices it speaks with (text to speech).
 *
 * Pure Kotlin, so it can be unit-tested.
 */
object Languages {

    const val DEFAULT = "en-IN"

    val ALL: List<Lang> = listOf(
        Lang("en-IN", "English (India)", "Indian accent"),
        Lang("en-GB", "English (UK)", "British accent"),
        Lang("en-US", "English (US)", "American accent"),
        Lang("en-AU", "English (Australia)", "Australian accent"),
        Lang("en-CA", "English (Canada)", "Canadian accent"),
        Lang("en-IE", "English (Ireland)", "Irish accent"),
        Lang("en-ZA", "English (South Africa)", "South African accent")
    )

    fun find(tag: String): Lang = ALL.firstOrNull { it.tag.equals(tag, ignoreCase = true) } ?: ALL[0]

    fun isKnown(tag: String): Boolean = ALL.any { it.tag.equals(tag, ignoreCase = true) }

    /** "en-GB" -> "GB" */
    fun country(tag: String): String = tag.substringAfter('-', "")
}
