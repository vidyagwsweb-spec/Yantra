package `in`.yantra.assistant.util

import android.content.Context

/** Tiny wrapper over SharedPreferences: preferences plus the named lists. */
class Prefs(ctx: Context) {

    private val sp = ctx.applicationContext.getSharedPreferences("yantra", Context.MODE_PRIVATE)

    fun name(): String = sp.getString("name", "") ?: ""

    fun set(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun get(key: String, fallback: String = ""): String = sp.getString(key, fallback) ?: fallback

    private fun key(list: String) = "list." + list.lowercase()

    fun list(name: String): MutableList<String> {
        val raw = sp.getString(key(name), "") ?: ""
        if (raw.isEmpty()) return mutableListOf()
        return raw.split("\u001F").filter { it.isNotEmpty() }.toMutableList()
    }

    fun saveList(name: String, items: List<String>) {
        sp.edit().putString(key(name), items.joinToString("\u001F")).apply()
    }

    fun addToList(name: String, item: String): List<String> {
        val l = list(name)
        l.add(item)
        saveList(name, l)
        return l
    }

    fun removeFromList(name: String, item: String): List<String> {
        val l = list(name)
        l.removeAll { it.contains(item, ignoreCase = true) }
        saveList(name, l)
        return l
    }

    fun clearList(name: String): Int {
        val n = list(name).size
        saveList(name, emptyList())
        return n
    }
}
