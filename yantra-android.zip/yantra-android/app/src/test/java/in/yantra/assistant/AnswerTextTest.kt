package `in`.yantra.assistant

import `in`.yantra.assistant.actions.AnswerText
import `in`.yantra.assistant.actions.AnswerText.Kind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The pure half of direct answers: what is worth looking up, and what to keep. */
class AnswerTextTest {

    private fun topic(q: String) = AnswerText.plan(q)?.topic

    @Test
    fun definitionalQuestionsGetAPlan() {
        assertEquals("photosynthesis", topic("what is photosynthesis"))
        assertEquals("photosynthesis", topic("What is photosynthesis?"))
        assertEquals("elon musk", topic("who is elon musk"))
        assertEquals("black holes", topic("what are black holes"))
        assertEquals("eiffel tower", topic("where is the eiffel tower"))
        assertEquals("quantum computing", topic("explain quantum computing"))
        assertEquals("the roman empire", topic("tell me about the roman empire"))
        assertEquals("elon musk", topic("hey yantra, can you tell me who's elon musk"))
    }

    @Test
    fun dictionaryQuestions() {
        val p = AnswerText.plan("define serendipity")!!
        assertEquals(Kind.DEFINE, p.kind)
        assertEquals("serendipity", p.topic)
        assertEquals(Kind.DEFINE, AnswerText.plan("meaning of ephemeral")!!.kind)
        assertEquals(Kind.DEFINE, AnswerText.plan("the definition of irony")!!.kind)
    }

    @Test
    fun officeQuestionsAreFlaggedAsRoles() {
        val p = AnswerText.plan("who is the prime minister of india")!!
        assertTrue(p.role)
        assertEquals("prime minister of india", p.topic)
        // "current" is noise
        assertEquals("president of the united states", topic("who is the current president of the united states"))
        // a person is not a role
        assertFalse(AnswerText.plan("who is elon musk")!!.role)
    }

    @Test
    fun explicitSearchIsStrict() {
        val p = AnswerText.plan("search for eiffel tower")!!
        assertTrue(p.strict)
        assertEquals("eiffel tower", p.topic)
    }

    @Test
    fun thingsAnEncyclopediaCannotAnswerAreLeftToGoogle() {
        assertNull(AnswerText.plan("how do I make the screen brighter"))
        assertNull(AnswerText.plan("why is the sky blue"))
        assertNull(AnswerText.plan("what is the population of india"))
        assertNull(AnswerText.plan("what is the weather"))
        assertNull(AnswerText.plan("search for train timings"))
        assertNull(AnswerText.plan("what is your name"))
        assertNull(AnswerText.plan("who is the latest champion of the world cup in cricket this year"))
        assertNull(AnswerText.plan(""))
    }

    @Test
    fun onlyPagesThatAreReallyAboutItAreAccepted() {
        assertTrue(AnswerText.accepts("black holes", "Black hole", false))
        assertTrue(AnswerText.accepts("prime minister of india", "Prime Minister of India", false))
        assertTrue(AnswerText.accepts("python", "Python (programming language)", false))
        assertTrue(AnswerText.accepts("sachin", "Sachin Tendulkar", false))
        assertTrue(AnswerText.accepts("volume of a sphere", "Sphere", false))
        // "search for train timings" must not become the article "Train"
        assertFalse(AnswerText.accepts("train timings", "Train", true))
        // a page about something else
        assertFalse(AnswerText.accepts("eiffel tower", "Paris", false))
        // too many extra words: not the same question
        assertFalse(AnswerText.accepts("how tall was the old eiffel tower in paris", "Eiffel Tower", false))
    }

    @Test
    fun stripRemovesPronunciationsAndBrackets() {
        val raw = "Albert Einstein (/\u02C8a\u026Ast\u0061\u026An/; German: [\u02C8alb\u025B\u0281t]; 14 March 1879 \u2013 18 April 1955) was a physicist.[1]"
        assertEquals("Albert Einstein was a physicist.", AnswerText.strip(raw))
    }

    @Test
    fun sentencesDoNotBreakOnInitialsOrAbbreviations() {
        val s = AnswerText.sentences("Harry Potter is a series by British author J. K. Rowling. It has seven books. Dr. Who is unrelated.")
        assertEquals(3, s.size)
        assertEquals("Harry Potter is a series by British author J. K. Rowling.", s[0])
        assertEquals("It has seven books.", s[1])
        assertEquals("Dr. Who is unrelated.", s[2])
    }

    @Test
    fun tidyKeepsAPhoneScreenOfText() {
        val long = (1..10).joinToString(" ") { "Sentence number $it is here and says something." }
        val t = AnswerText.tidy(long)
        assertTrue(t.length <= 400)
        assertTrue(t.startsWith("Sentence number 1"))
        assertFalse(t.contains("Sentence number 4"))
        // one huge sentence is cut on a word, with an ellipsis
        val huge = "word ".repeat(200).trim() + "."
        val c = AnswerText.tidy(huge)
        assertTrue(c.length <= 522)
        assertTrue(c.endsWith("\u2026"))
    }

    @Test
    fun whereQuestionsAreFlaggedAndTrimmed() {
        val p = AnswerText.plan("where is the United Nations located")!!
        assertTrue(p.where)
        assertEquals("united nations", p.topic)
        assertFalse(AnswerText.plan("what is the united nations")!!.where)
        val s = AnswerText.whereSentence("It is an organization. It is headquartered in New York City. It has members.")
        assertEquals("It is headquartered in New York City.", s)
        assertNull(AnswerText.whereSentence("It is an organization founded in 1945."))
    }

    @Test
    fun aLongFirstSentenceIsSpokenInFull() {
        val long = "The thing " + "that goes on and on ".repeat(30) + "finally ends."
        assertEquals(long, AnswerText.speakable("$long Another short one."))
    }

    @Test
    fun speakableIsTwoSentences() {
        val spoken = AnswerText.speakable("One is first. Two is second. Three is third.")
        assertEquals("One is first. Two is second.", spoken)
        assertNotNull(AnswerText.speakable("Only one sentence"))
    }
}
