package `in`.yantra.assistant

import `in`.yantra.assistant.brain.Brain
import `in`.yantra.assistant.brain.Thought
import `in`.yantra.assistant.util.Languages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

/** The brain is pure Kotlin, so this runs on the JVM with `gradle test`. */
class BrainTest {

    private fun brain() = Brain(Random(7))

    private fun reply(t: Thought): String {
        assertTrue("expected a reply, got $t", t is Thought.Reply)
        return (t as Thought.Reply).text
    }

    @Test
    fun smallTalk() {
        val b = brain()
        assertTrue(b.think("tell me a joke") is Thought.Reply)
        assertTrue(b.think("make me laugh please") is Thought.Reply)
        assertTrue(b.think("tell me something interesting") is Thought.Reply)
        assertTrue(reply(b.think("who created you")).contains("Kotlin"))
        assertTrue(reply(b.think("are you alive")).startsWith("No."))
        assertTrue(reply(b.think("what does yantra mean")).contains("Sanskrit"))
    }

    @Test
    fun wordOrderAndFillerDoNotMatter() {
        val b = brain()
        assertTrue(b.think("joke tell me") is Thought.Reply)
        assertTrue(b.think("hey yantra can you please tell me a joke bhai") is Thought.Reply)
        assertTrue(b.think("tell me a jokes") is Thought.Reply)
    }

    @Test
    fun facts() {
        val b = brain()
        assertTrue(reply(b.think("how many planets are there")).startsWith("Eight"))
        assertTrue(reply(b.think("national animal of india")).contains("tiger"))
        assertTrue(reply(b.think("what temperature does water boil at")).contains("100"))
    }

    @Test
    fun capitals() {
        val b = brain()
        assertEquals("The capital of France is Paris.", reply(b.think("what is the capital of france")))
        assertEquals("The capital of Karnataka is Bengaluru.", reply(b.think("capital of karnataka")))
        assertEquals("The capital of UK is London.", reply(b.think("whats the capital of the uk")))
        // not in the table: stay quiet so the web search runs
        assertEquals(Thought.Pass, b.think("capital of atlantis"))
    }

    @Test
    fun leavesOtherQuestionsAlone() {
        val b = brain()
        assertEquals(Thought.Pass, b.think("make me a sandwich"))
        assertEquals(Thought.Pass, b.think("who is the prime minister of india"))
        assertEquals(Thought.Pass, b.think("what is the price of gold today"))
        assertEquals(Thought.Pass, b.think("how old is the eiffel tower"))
        assertEquals(Thought.Pass, b.think("why is the sky blue"))
        assertEquals(Thought.Pass, b.think(""))
        assertEquals(Thought.Pass, b.think("???"))
    }

    @Test
    fun oddPhrasingBecomesACommand() {
        val b = brain()
        val t = b.think("its dark in here")
        assertTrue("got $t", t is Thought.Run || t is Thought.Confirm)
        val cmd = if (t is Thought.Run) t.command else (t as Thought.Confirm).command
        assertEquals("turn on flashlight", cmd)

        val t2 = b.think("the screen is too bright")
        val cmd2 = if (t2 is Thought.Run) t2.command else (t2 as Thought.Confirm).command
        assertEquals("decrease brightness", cmd2)
    }

    @Test
    fun sideEffectsAlwaysAsk() {
        val b = brain()
        val t = b.think("im in a meeting")
        assertTrue("got $t", t is Thought.Confirm)
        assertEquals("turn on do not disturb", (t as Thought.Confirm).command)
        assertTrue(b.hasPending())

        // "yes" runs it
        val yes = b.answerPending("yeah")
        assertEquals(Thought.Run("turn on do not disturb"), yes)
        assertFalse(b.hasPending())
    }

    @Test
    fun pendingNoAndOtherAnswers() {
        val b = brain()
        b.think("im in a meeting")
        assertEquals("Okay, leaving it.", reply(b.answerPending("nope")!!))
        assertFalse(b.hasPending())

        // an unrelated sentence drops the question and carries on
        b.think("im in a meeting")
        assertEquals(null, b.answerPending("what time is it"))
        assertFalse(b.hasPending())
    }

    @Test
    fun lowMoodOffersABreather() {
        val b = brain()
        val t = b.think("i feel lonely")
        assertTrue("got $t", t is Thought.Confirm)
        assertEquals("set a timer for 5 minutes", (t as Thought.Confirm).command)
        assertTrue(t.prompt.contains("someone you trust"))
    }

    @Test
    fun anotherOne() {
        val b = brain()
        val first = reply(b.think("tell me a joke"))
        val second = reply(b.more("another one")!!)
        assertNotEquals(first, second)
        assertTrue(b.more("another one") is Thought.Reply)

        // after something else, "another one" means nothing
        b.forgetTopic()
        assertEquals(null, b.more("another one"))
    }

    @Test
    fun usesTheNameWhenKnown() {
        val b = brain()
        b.userName = "Vidya"
        var found = false
        repeat(6) { if (reply(b.think("good night")).contains("Vidya")) found = true }
        assertTrue(found)

        val anon = brain()
        repeat(6) {
            val r = reply(anon.think("good night"))
            assertFalse(r.contains("{"))
            assertFalse(r.contains(" ."))
        }
    }

    // ------------------------------------------------------------- teaching

    private val knowsOpen: (String) -> Boolean = { it.startsWith("open ") }

    @Test
    fun teachingACommand() {
        val b = brain()
        var saved = 0
        b.onTaughtChanged = { saved++ }

        val r = reply(b.learn("When I say movie time, open netflix", knowsOpen)!!)
        assertTrue(r.contains("movie time"))
        assertEquals(1, b.taughtCount())
        assertEquals(1, saved)

        assertEquals(Thought.Run("open netflix"), b.recall("movie time"))
        assertEquals(Thought.Run("open netflix"), b.recall("Movie Time!"))
        // a small slip on a longer phrase is forgiven
        assertEquals(Thought.Run("open netflix"), b.recall("movie tine"))
        assertEquals(null, b.recall("something else"))
    }

    @Test
    fun teachingAReply() {
        val b = brain()
        b.learn("when I say good vibes, say Thank you so much", knowsOpen)
        assertEquals("Thank you so much", reply(b.recall("good vibes")!!))
    }

    @Test
    fun refusesCommandsItDoesNotUnderstand() {
        val b = brain()
        val r = reply(b.learn("when I say party, do launch the rocket", knowsOpen)!!)
        assertTrue(r.contains("did not save"))
        assertEquals(0, b.taughtCount())
    }

    @Test
    fun listAndForget() {
        val b = brain()
        assertTrue(reply(b.learn("what have I taught you", knowsOpen)!!).startsWith("Nothing yet"))

        b.learn("when I say movie time, open netflix", knowsOpen)
        b.learn("when I say tunes, open spotify", knowsOpen)
        assertEquals(2, b.taughtCount())
        assertTrue(reply(b.learn("what have I taught you", knowsOpen)!!).contains("movie time"))

        assertTrue(reply(b.learn("forget the shortcut tunes", knowsOpen)!!).contains("Forgot"))
        assertEquals(1, b.taughtCount())
        assertTrue(reply(b.learn("forget all shortcuts", knowsOpen)!!).contains("Forgot all 1"))
        assertEquals(0, b.taughtCount())
        assertEquals(null, b.learn("tell me a joke", knowsOpen))
    }

    @Test
    fun taughtShortcutsSurviveARestart() {
        val a = brain()
        a.learn("when I say movie time, open netflix", knowsOpen)
        a.learn("when I say good vibes, say Thanks", knowsOpen)

        val b = brain()
        b.loadTaught(a.taughtItems())
        assertEquals(2, b.taughtCount())
        assertEquals(Thought.Run("open netflix"), b.recall("movie time"))
        assertEquals("Thanks", reply(b.recall("good vibes")!!))
    }

    // --------------------------------------------------------------- safety

    @Test
    fun crisisIsMetWithCareNotAJoke() {
        val r = Brain.crisis("i want to die")
        assertTrue(r != null)
        assertTrue(r!!.text.contains("14416"))
        assertTrue(r.text.contains("emergency"))
        assertTrue(Brain.crisis("I don't want to live anymore") != null)
        assertTrue(Brain.crisis("how do I kill myself") != null)
        // media and searches are not a person in distress
        assertEquals(null, Brain.crisis("play suicide squad trailer"))
        assertEquals(null, Brain.crisis("what is the capital of france"))
        assertEquals(null, Brain.crisis("tell me a joke"))
    }

    // ------------------------------------------------------------ internals

    @Test
    fun stemmingAndTypos() {
        assertEquals(Brain.stem("jokes"), Brain.stem("joke"))
        assertEquals(Brain.stem("making"), Brain.stem("make"))
        assertEquals(Brain.stem("feelings"), Brain.stem("feel"))
        assertEquals(0, Brain.editDistance("flashlight", "flashlight", 1))
        assertEquals(1, Brain.editDistance("flashlight", "flashlighs", 2))
        assertEquals(3, Brain.editDistance("abcdef", "uvwxyz", 2))
    }

    @Test
    fun languages() {
        assertEquals("en-IN", Languages.DEFAULT)
        assertEquals("English (UK)", Languages.find("en-GB").label)
        assertEquals("GB", Languages.country("en-GB"))
        assertEquals("English (India)", Languages.find("fr-FR").label)
        assertTrue(Languages.isKnown("en-us"))
        assertFalse(Languages.isKnown("xx-YY"))
        assertEquals(Languages.ALL.size, Languages.ALL.map { it.tag }.toSet().size)
    }
}
