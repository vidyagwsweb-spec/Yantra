package `in`.yantra.assistant

import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Rewriter
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.router.Translator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The router is pure Kotlin with no Android imports, so it runs as a plain JVM
 * test. `gradle test` executes this on every CI build.
 */
class RouterTest {

    private fun r(text: String, ctx: Ctx = Ctx()) = Router.route(text, ctx)

    private fun assertAction(expected: String, text: String, ctx: Ctx = Ctx()) {
        assertEquals("for \"$text\"", expected, r(text, ctx).action)
    }

    @Test
    fun meta() {
        assertAction("help", "help")
        assertAction("help", "what can you do")
        assertAction("say", "hello")
        assertAction("stop", "stop")
        assertAction("empty", "")
        assertAction("unknown", "make me a sandwich")
    }

    @Test
    fun deviceToggles() {
        assertAction("wifi", "turn on wi-fi")
        assertAction("wifi", "turn off wifi")
        assertEquals(true, r("turn on wi-fi").on)
        assertEquals(false, r("turn off wi-fi").on)

        assertAction("bluetooth", "turn on bluetooth")
        assertAction("airplane", "enable airplane mode")
        assertAction("mobile-data", "turn off mobile data")
        assertAction("flashlight", "turn on the flashlight")
        assertEquals(true, r("turn on the flashlight").on)

        assertAction("dnd", "turn on do not disturb")
        assertAction("dark-mode", "enable dark mode")
        assertAction("battery-saver", "turn on battery saver")
    }

    @Test
    fun screenAndSound() {
        val b = r("set brightness to 50%")
        assertAction("brightness", "set brightness to 50%")
        assertEquals(50, b.pct)

        assertAction("brightness-delta", "increase my screen brightness")
        assertAction("brightness-delta", "decrease brightness")
        assertEquals(100, r("max brightness").pct)

        assertAction("volume", "set the volume to 30%")
        assertEquals(30, r("volume 30").pct)
        assertAction("volume", "mute")
        assertEquals(0, r("mute").pct)
        assertAction("volume-delta", "increase the volume")
    }

    @Test
    fun status() {
        assertAction("battery", "battery")
        assertAction("battery", "what's my current battery percentage")
        assertAction("storage", "how much free storage do I have")
        assertAction("network", "check my internet connection")
        assertAction("device", "show my device information")
        assertAction("location", "where am I")
    }

    @Test
    fun apps() {
        assertAction("open-app", "open youtube")
        assertEquals("youtube", r("open youtube").a)
        assertAction("open-app", "open whatsapp")
        assertAction("home", "go home")
        assertAction("list-apps", "show my apps")
    }

    @Test
    fun people() {
        assertAction("call", "call 9876543210")
        assertEquals("9876543210", r("call 9876543210").a)
        assertAction("call-contact", "call mom")
        assertEquals("mom", r("call mom").a)

        val sms = r("text 9876543210 saying I am late")
        assertAction("sms", "text 9876543210 saying I am late")
        assertEquals("9876543210", sms.a)
        assertTrue(sms.b.contains("late"))

        assertAction("whatsapp", "whatsapp 9876543210 saying I am late")
        assertAction("find-contact", "find mom's contact")
        assertAction("read-notifications", "read my notifications")
    }

    @Test
    fun alarmsAndTimers() {
        val a = r("set an alarm for 6:30 am")
        assertAction("alarm", "set an alarm for 6:30 am")
        assertEquals(6L, a.num)
        assertEquals(30, a.pct)

        val pm = r("alarm at 7 pm")
        assertEquals(19L, pm.num)

        assertAction("timer", "set a timer for 10 minutes")
        assertEquals(600_000L, r("set a timer for 10 minutes").num)
        assertEquals(45_000L, r("timer for 45 seconds").num)
        assertEquals(90_000L, r("set a timer for 1 minute 30 seconds").num)
        assertEquals(7_200_000L, r("set a timer for two hours").num)

        assertAction("timer-pause", "pause the timer")
        assertAction("timer-resume", "resume the timer")
        assertAction("timer-cancel", "cancel the timer")
        assertAction("timer-status", "how much time is left")
        assertAction("alarm-list", "show my alarms")
    }

    @Test
    fun mathsAndUnits() {
        assertAction("say", "15% of 2400")
        assertTrue(r("15% of 2400").say.contains("360"))
        assertTrue(r("12 * 34").say.contains("408"))
        assertTrue(r("square root of 729").say.contains("27"))
        assertTrue(r("5 km to miles").say.contains("3.10"))
        assertTrue(r("100 f to c").say.contains("37.7"))
    }

    @Test
    fun listsAndCalendar() {
        val add = r("add milk to shopping")
        assertAction("list-add", "add milk to shopping")
        assertEquals("shopping", add.a)
        assertEquals("milk", add.b)

        assertAction("list-show", "show my shopping")
        assertAction("list-remove", "remove milk from shopping")
        assertAction("list-add", "note that I parked on level 2")
        assertAction("list-show", "show my notes")

        val ev = r("add event dentist tomorrow at 5pm")
        assertAction("calendar-add", "add event dentist tomorrow at 5pm")
        assertEquals("dentist", ev.a)
        assertTrue(ev.at > 0)

        assertAction("agenda", "what's on my calendar")
    }

    @Test
    fun web() {
        assertAction("search", "search for train timings")
        assertAction("navigate", "navigate to Pune airport")
        assertAction("nearby", "find the nearest ATM")
        assertAction("weather", "weather in Pune")
        assertAction("weather", "will it rain")
    }

    @Test
    fun memoryAndPrefs() {
        val ctx = Ctx(lastBot = "Pune: 29C and partly cloudy.", lastUser = "weather in Pune")
        assertEquals("Pune: 29C and partly cloudy.", r("repeat that", ctx).say)
        assertTrue(r("what did I ask", ctx).say.contains("weather in Pune"))
        assertAction("pref-name", "call me Vidya")
        assertAction("pref", "use metric units")
    }

    @Test
    fun messagingSplitsRecipientFromBody() {
        val party = r("Send a message to X to come to the party at 3 o'clock")
        assertAction("sms-contact", "Send a message to X to come to the party at 3 o'clock")
        assertEquals("x", party.a)
        assertEquals("come to the party at 3 oclock", party.b)

        val mom = r("text mom saying I am late")
        assertEquals("mom", mom.a)
        assertEquals("i am late", mom.b)

        val num = r("send a message to 9876543210 saying I am late")
        assertAction("sms", "send a message to 9876543210 saying I am late")
        assertEquals("9876543210", num.a)

        // no recipient: the executor asks who
        assertAction("say", "send a message saying I am on my way")
    }

    @Test
    fun casualPhrasingIsRewritten() {
        // the rewriter alone
        assertEquals("turn on flashlight", Rewriter.rewrite("turn the flashlight on"))
        assertEquals("set brightness to 50%", Rewriter.rewrite("put the brightness to 50%"))
        assertEquals("increase volume", Rewriter.rewrite("make it louder"))
        assertEquals("decrease brightness", Rewriter.rewrite("dim the screen"))
        assertEquals("set an alarm for 6 am", Rewriter.rewrite("set an alarm for 6 in the morning"))

        // and the router picks them up through the fallback
        assertAction("flashlight", "turn the flashlight on")
        assertAction("brightness", "put the brightness to 50%")
        assertAction("volume-delta", "make it louder")
        assertAction("volume-delta", "turn it down")
        assertAction("brightness-delta", "dim the screen")
        assertAction("flashlight", "hey yantra, turn on the flashlight")
        assertAction("flashlight", "can you please turn the flashlight on")

        // a rewrite must never damage something that already worked
        assertEquals("add milk to shopping", Rewriter.rewrite("add milk to shopping"))
        assertAction("unknown", "make me a sandwich")
    }

    @Test
    fun normalisation() {
        assertEquals("15% of 2400", Router.normalize("15% of 2,400"))
        assertEquals("whats the time", Router.normalize("What's the time?"))
        assertEquals(600_000L, Router.durationMs("ten minutes"))
    }

    // ------------------------------------------------------------------
    // Relative amounts. "increase the brightness by 50%" used to fall through
    // to "unknown" because only "set brightness to N" had a pattern.
    // ------------------------------------------------------------------

    @Test
    fun relativeAmountsGoStraightThroughTheRouter() {
        val up = r("Increase the brightness by 50%")
        assertEquals("brightness-delta", up.action)
        assertEquals(50L, up.num)

        assertEquals(-30L, r("lower the brightness by 30").num)
        assertEquals(20L, r("turn up the volume by 20%").num)
        assertEquals(-25L, r("reduce the volume by 25").num)

        // no amount: the old default steps still apply
        assertEquals(20L, r("increase brightness").num)
        assertEquals(-15L, r("decrease the volume").num)
    }

    @Test
    fun translatorUnderstandsNaturalLevelRequests() {
        // relative
        assertEquals("increase brightness by 50%", Translator.translate("increase the brightness by fifty percent"))
        assertEquals("decrease brightness by 30%", Translator.translate("make it 30 percent dimmer"))
        assertEquals("decrease brightness by 10%", Translator.translate("make the screen a bit dimmer"))
        assertEquals("increase volume by 30%", Translator.translate("make the music a lot louder"))
        assertEquals("decrease volume by 50%", Translator.translate("bring the volume down by half"))
        assertEquals("decrease volume by 14%", Translator.translate("turn the sound down by 2 notches"))
        // absolute
        assertEquals("set volume to 40%", Translator.translate("turn the volume up to forty"))
        assertEquals("set brightness to 25%", Translator.translate("set brightness to twenty-five percent"))
        assertEquals("set volume to 100%", Translator.translate("set the volume to a hundred"))
        // politeness and fluff around it
        assertEquals("turn on flashlight", Translator.translate("hey yantra, can you turn the flashlight on please"))
    }

    @Test
    fun naturalLevelRequestsRouteToTheRightAction() {
        assertAction("brightness-delta", "increase the brightness by fifty percent")
        assertEquals(50L, r("increase the brightness by fifty percent").num)

        assertAction("brightness-delta", "make the screen 20% brighter")
        assertEquals(20L, r("make the screen 20% brighter").num)

        assertAction("brightness-delta", "make the screen a bit dimmer")
        assertEquals(-10L, r("make the screen a bit dimmer").num)

        assertAction("brightness", "turn the brightness up to 80")
        assertEquals(80, r("turn the brightness up to 80").pct)

        assertAction("brightness", "set the brightness to half")
        assertEquals(50, r("set the brightness to half").pct)

        assertAction("volume", "turn the volume up to forty")
        assertEquals(40, r("turn the volume up to forty").pct)

        assertAction("volume-delta", "a bit louder")
        assertEquals(10L, r("a bit louder").num)

        assertAction("volume-delta", "bring the volume down by half")
        assertEquals(-50L, r("bring the volume down by half").num)

        assertAction("wifi", "wifi off")
        assertEquals(false, r("wifi off").on)
        assertAction("bluetooth", "enable bluetooth")
        assertEquals(true, r("enable bluetooth").on)
        assertAction("dnd", "turn dnd on")
    }

    @Test
    fun translatorLeavesQuestionsAndUnrelatedCommandsAlone() {
        // a question about brightness is not an order to change it
        assertAction("unknown", "how do I make the screen brighter")
        assertAction("unknown", "what is the volume of a sphere")
        assertAction("unknown", "remind me to turn the volume down")
        // direct matches never reach the translator
        assertAction("list-add", "add milk to shopping")
    }

    @Test
    fun spelledOutNumbers() {
        assertEquals("25 and 100", Translator.digitize("twenty five and a hundred"))
        assertEquals("25", Translator.digitize("twenty-five"))
        assertEquals("105", Translator.digitize("one hundred five"))
        assertEquals("set an alarm for 6 am", Translator.translate("set an alarm for six in the morning"))
        // a lone "one" is a word, not a number
        assertEquals("one more thing", Translator.digitize("one more thing"))
    }
}
