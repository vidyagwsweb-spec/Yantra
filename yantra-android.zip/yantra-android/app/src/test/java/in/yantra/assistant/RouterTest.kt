package `in`.yantra.assistant

import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Rewriter
import `in`.yantra.assistant.router.Router
import `in`.yantra.assistant.router.Translator
import `in`.yantra.assistant.speech.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/**
 * The router is pure Kotlin with no Android imports, so it runs as a plain JVM
 * test. `gradle test` executes this on every CI build.
 */
class RouterTest {

    private fun r(text: String, ctx: Ctx = Ctx()) = Router.route(text, ctx)

    private fun assertAction(expected: String, text: String, ctx: Ctx = Ctx()) {
        assertEquals("for \"$text\"", expected, r(text, ctx).action)
    }

    @Test
    fun meta() {
        assertAction("help", "help")
        assertAction("help", "what can you do")
        assertAction("say", "hello")
        assertAction("stop", "stop")
        assertAction("empty", "")
        assertAction("unknown", "make me a sandwich")
    }

    @Test
    fun deviceToggles() {
        assertAction("wifi", "turn on wi-fi")
        assertAction("wifi", "turn off wifi")
        assertEquals(true, r("turn on wi-fi").on)
        assertEquals(false, r("turn off wi-fi").on)

        assertAction("bluetooth", "turn on bluetooth")
        assertAction("airplane", "enable airplane mode")
        assertAction("mobile-data", "turn off mobile data")
        assertAction("flashlight", "turn on the flashlight")
        assertEquals(true, r("turn on the flashlight").on)

        assertAction("dnd", "turn on do not disturb")
        assertAction("dark-mode", "enable dark mode")
        assertAction("battery-saver", "turn on battery saver")
    }

    @Test
    fun screenAndSound() {
        val b = r("set brightness to 50%")
        assertAction("brightness", "set brightness to 50%")
        assertEquals(50, b.pct)

        assertAction("brightness-delta", "increase my screen brightness")
        assertAction("brightness-delta", "decrease brightness")
        assertEquals(100, r("max brightness").pct)

        assertAction("volume", "set the volume to 30%")
        assertEquals(30, r("volume 30").pct)
        assertAction("volume", "mute")
        assertEquals(0, r("mute").pct)
        assertAction("volume-delta", "increase the volume")
    }

    @Test
    fun status() {
        assertAction("battery", "battery")
        assertAction("battery", "what's my current battery percentage")
        assertAction("storage", "how much free storage do I have")
        assertAction("network", "check my internet connection")
        assertAction("device", "show my device information")
        assertAction("location", "where am I")
    }

    @Test
    fun apps() {
        assertAction("open-app", "open youtube")
        assertEquals("youtube", r("open youtube").a)
        assertAction("open-app", "open whatsapp")
        assertAction("home", "go home")
        assertAction("list-apps", "show my apps")
    }

    @Test
    fun people() {
        assertAction("call", "call 9876543210")
        assertEquals("9876543210", r("call 9876543210").a)
        assertAction("call-contact", "call mom")
        assertEquals("mom", r("call mom").a)

        val sms = r("text 9876543210 saying I am late")
        assertAction("sms", "text 9876543210 saying I am late")
        assertEquals("9876543210", sms.a)
        assertTrue(sms.b.contains("late"))

        assertAction("whatsapp", "whatsapp 9876543210 saying I am late")
        assertAction("find-contact", "find mom's contact")
        assertAction("read-notifications", "read my notifications")
    }

    @Test
    fun alarmsAndTimers() {
        val a = r("set an alarm for 6:30 am")
        assertAction("alarm", "set an alarm for 6:30 am")
        assertEquals(6L, a.num)
        assertEquals(30, a.pct)

        val pm = r("alarm at 7 pm")
        assertEquals(19L, pm.num)

        assertAction("timer", "set a timer for 10 minutes")
        assertEquals(600_000L, r("set a timer for 10 minutes").num)
        assertEquals(45_000L, r("timer for 45 seconds").num)
        assertEquals(90_000L, r("set a timer for 1 minute 30 seconds").num)
        assertEquals(7_200_000L, r("set a timer for two hours").num)

        assertAction("timer-pause", "pause the timer")
        assertAction("timer-resume", "resume the timer")
        assertAction("timer-cancel", "cancel the timer")
        assertAction("timer-status", "how much time is left")
        assertAction("alarm-list", "show my alarms")
    }

    @Test
    fun mathsAndUnits() {
        assertAction("say", "15% of 2400")
        assertTrue(r("15% of 2400").say.contains("360"))
        assertTrue(r("12 * 34").say.contains("408"))
        assertTrue(r("square root of 729").say.contains("27"))
        assertTrue(r("5 km to miles").say.contains("3.10"))
        assertTrue(r("100 f to c").say.contains("37.7"))
    }

    @Test
    fun listsAndCalendar() {
        val add = r("add milk to shopping")
        assertAction("list-add", "add milk to shopping")
        assertEquals("shopping", add.a)
        assertEquals("milk", add.b)

        assertAction("list-show", "show my shopping")
        assertAction("list-remove", "remove milk from shopping")
        assertAction("list-add", "note that I parked on level 2")
        assertAction("list-show", "show my notes")

        val ev = r("add event dentist tomorrow at 5pm")
        assertAction("calendar-add", "add event dentist tomorrow at 5pm")
        assertEquals("dentist", ev.a)
        assertTrue(ev.at > 0)

        assertAction("agenda", "what's on my calendar")
    }

    @Test
    fun searchOpensBrowserOnlyWhenAskedTo() {
        // explicit "google" / "the web" means the browser
        assertEquals("browser", r("google cats").b)
        assertEquals("cats", r("google cats").a)
        assertEquals("browser", r("search the web for cats").b)
        assertEquals("cats", r("search the web for cats").a)
        // everything else may be answered in place
        assertEquals("", r("search for cats").b)
        assertEquals("", r("look up photosynthesis").b)
        assertEquals("", r("who is the prime minister of india").b)
    }

    @Test
    fun web() {
        assertAction("search", "search for train timings")
        assertAction("navigate", "navigate to Pune airport")
        assertAction("nearby", "find the nearest ATM")
        assertAction("weather", "weather in Pune")
        assertAction("weather", "will it rain")
    }

    @Test
    fun memoryAndPrefs() {
        val ctx = Ctx(lastBot = "Pune: 29C and partly cloudy.", lastUser = "weather in Pune")
        assertEquals("Pune: 29C and partly cloudy.", r("repeat that", ctx).say)
        assertTrue(r("what did I ask", ctx).say.contains("weather in Pune"))
        assertAction("pref-name", "call me Vidya")
        assertAction("pref", "use metric units")
    }

    @Test
    fun messagingSplitsRecipientFromBody() {
        val party = r("Send a message to X to come to the party at 3 o'clock")
        assertAction("sms-contact", "Send a message to X to come to the party at 3 o'clock")
        assertEquals("x", party.a)
        assertEquals("come to the party at 3 oclock", party.b)

        val mom = r("text mom saying I am late")
        assertEquals("mom", mom.a)
        assertEquals("i am late", mom.b)

        val num = r("send a message to 9876543210 saying I am late")
        assertAction("sms", "send a message to 9876543210 saying I am late")
        assertEquals("9876543210", num.a)

        // no recipient: the executor asks who
        assertAction("say", "send a message saying I am on my way")
    }

    @Test
    fun casualPhrasingIsRewritten() {
        // the rewriter alone
        assertEquals("turn on flashlight", Rewriter.rewrite("turn the flashlight on"))
        assertEquals("set brightness to 50%", Rewriter.rewrite("put the brightness to 50%"))
        assertEquals("increase volume", Rewriter.rewrite("make it louder"))
        assertEquals("decrease brightness", Rewriter.rewrite("dim the screen"))
        assertEquals("set an alarm for 6 am", Rewriter.rewrite("set an alarm for 6 in the morning"))

        // and the router picks them up through the fallback
        assertAction("flashlight", "turn the flashlight on")
        assertAction("brightness", "put the brightness to 50%")
        assertAction("volume-delta", "make it louder")
        assertAction("volume-delta", "turn it down")
        assertAction("brightness-delta", "dim the screen")
        assertAction("flashlight", "hey yantra, turn on the flashlight")
        assertAction("flashlight", "can you please turn the flashlight on")

        // a rewrite must never damage something that already worked
        assertEquals("add milk to shopping", Rewriter.rewrite("add milk to shopping"))
        assertAction("unknown", "make me a sandwich")
    }

    @Test
    fun normalisation() {
        assertEquals("15% of 2400", Router.normalize("15% of 2,400"))
        assertEquals("whats the time", Router.normalize("What's the time?"))
        assertEquals(600_000L, Router.durationMs("ten minutes"))
    }

    // ------------------------------------------------------------------
    // Relative amounts. "increase the brightness by 50%" used to fall through
    // to "unknown" because only "set brightness to N" had a pattern.
    // ------------------------------------------------------------------

    @Test
    fun relativeAmountsGoStraightThroughTheRouter() {
        val up = r("Increase the brightness by 50%")
        assertEquals("brightness-delta", up.action)
        assertEquals(50L, up.num)

        assertEquals(-30L, r("lower the brightness by 30").num)
        assertEquals(20L, r("turn up the volume by 20%").num)
        assertEquals(-25L, r("reduce the volume by 25").num)

        // no amount: the old default steps still apply
        assertEquals(20L, r("increase brightness").num)
        assertEquals(-15L, r("decrease the volume").num)
    }

    @Test
    fun translatorUnderstandsNaturalLevelRequests() {
        // relative
        assertEquals("increase brightness by 50%", Translator.translate("increase the brightness by fifty percent"))
        assertEquals("decrease brightness by 30%", Translator.translate("make it 30 percent dimmer"))
        assertEquals("decrease brightness by 10%", Translator.translate("make the screen a bit dimmer"))
        assertEquals("increase volume by 30%", Translator.translate("make the music a lot louder"))
        assertEquals("decrease volume by 50%", Translator.translate("bring the volume down by half"))
        assertEquals("decrease volume by 14%", Translator.translate("turn the sound down by 2 notches"))
        // absolute
        assertEquals("set volume to 40%", Translator.translate("turn the volume up to forty"))
        assertEquals("set brightness to 25%", Translator.translate("set brightness to twenty-five percent"))
        assertEquals("set volume to 100%", Translator.translate("set the volume to a hundred"))
        // politeness and fluff around it
        assertEquals("turn on flashlight", Translator.translate("hey yantra, can you turn the flashlight on please"))
    }

    @Test
    fun naturalLevelRequestsRouteToTheRightAction() {
        assertAction("brightness-delta", "increase the brightness by fifty percent")
        assertEquals(50L, r("increase the brightness by fifty percent").num)

        assertAction("brightness-delta", "make the screen 20% brighter")
        assertEquals(20L, r("make the screen 20% brighter").num)

        assertAction("brightness-delta", "make the screen a bit dimmer")
        assertEquals(-10L, r("make the screen a bit dimmer").num)

        assertAction("brightness", "turn the brightness up to 80")
        assertEquals(80, r("turn the brightness up to 80").pct)

        assertAction("brightness", "set the brightness to half")
        assertEquals(50, r("set the brightness to half").pct)

        assertAction("volume", "turn the volume up to forty")
        assertEquals(40, r("turn the volume up to forty").pct)

        assertAction("volume-delta", "a bit louder")
        assertEquals(10L, r("a bit louder").num)

        assertAction("volume-delta", "bring the volume down by half")
        assertEquals(-50L, r("bring the volume down by half").num)

        assertAction("wifi", "wifi off")
        assertEquals(false, r("wifi off").on)
        assertAction("bluetooth", "enable bluetooth")
        assertEquals(true, r("enable bluetooth").on)
        assertAction("dnd", "turn dnd on")
    }

    @Test
    fun translatorLeavesQuestionsAndUnrelatedCommandsAlone() {
        // a question about brightness is not an order to change it: it becomes a search
        assertAction("search", "how do I make the screen brighter")
        assertAction("search", "what is the volume of a sphere")
        // a reminder with no time asks for one instead of guessing
        assertAction("ask", "remind me to turn the volume down")
        // direct matches never reach the translator
        assertAction("list-add", "add milk to shopping")
    }

    @Test
    fun spelledOutNumbers() {
        assertEquals("25 and 100", Translator.digitize("twenty five and a hundred"))
        assertEquals("25", Translator.digitize("twenty-five"))
        assertEquals("105", Translator.digitize("one hundred five"))
        assertEquals("set an alarm for 6 am", Translator.translate("set an alarm for six in the morning"))
        // a lone "one" is a word, not a number
        assertEquals("one more thing", Translator.digitize("one more thing"))
    }

    // ------------------------------------------------------------------
    // Round two: more commands, and a translator that forgives.
    // Clock for everything below: Thursday 12 Nov 2026, 2:00 pm.
    // ------------------------------------------------------------------

    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int): Long =
        Calendar.getInstance().apply { clear(); set(y, mo, d, h, mi) }.timeInMillis

    private val now = at(2026, Calendar.NOVEMBER, 12, 14, 0)
    private val clock = Ctx(now = now)

    @Test
    fun mediaKeys() {
        assertEquals("pause", r("pause the music").a)
        assertEquals("play", r("resume").a)
        assertEquals("play", r("play some music").a)
        assertEquals("next", r("next song").a)
        assertEquals("next", r("skip").a)
        assertEquals("previous", r("previous track").a)
        assertEquals("stop", r("stop the music").a)
        // timers keep their own pause and resume
        assertAction("timer-pause", "pause the timer")
        assertAction("timer-resume", "resume the timer")
        // "play X" goes to a search
        assertEquals("despacito", r("play despacito").a)
        assertEquals("youtube", r("play despacito").b)
        assertEquals("spotify", r("play lofi on spotify").b)
    }

    @Test
    fun soundAndScreenSwitches() {
        assertEquals("silent", r("silent mode").a)
        assertEquals("vibrate", r("put my phone on vibrate").a)
        assertEquals("normal", r("ring mode").a)
        assertAction("ringer", "silent")             // via the translator

        assertAction("rotate", "turn off auto rotate")
        assertEquals(false, r("turn off auto rotate").on)
        assertEquals(true, r("unlock rotation").on)
        assertAction("auto-brightness", "turn on auto brightness")
        assertEquals(120_000L, r("set screen timeout to 2 minutes").num)
        assertEquals(300_000L, r("keep the screen on for 5 minutes").num)
    }

    @Test
    fun settingsPages() {
        assertEquals("wifi", r("open wifi settings").a)
        assertEquals("display", r("display settings").a)
        // Android will not flip these silently, so the toggle opens the page
        val loc = r("turn on location")
        assertEquals("settings", loc.action)
        assertEquals("location", loc.a)
        assertEquals("on", loc.b)
        assertEquals("hotspot", r("turn off the hotspot").a)
        // plain "open settings" is still the app
        assertAction("open-app", "open settings")
    }

    @Test
    fun appsAndWeb() {
        assertEquals("bbc.com", r("go to bbc.com").a)
        assertAction("url", "open nytimes.com")
        assertAction("open-app", "open youtube")
        assertEquals("twitter", r("uninstall twitter").a)
        assertEquals("chrome", r("app info for chrome").a)
        assertEquals("chrome", r("chrome app info").a)
        assertAction("clear-notifications", "clear my notifications")
        assertAction("video", "record a video")
        // copy keeps the original capitalisation
        assertEquals("Hello World", r("copy Hello World").a)
        assertAction("clipboard-read", "read my clipboard")
        assertEquals("good morning", r("translate good morning to hindi").a)
        assertEquals("hindi", r("translate good morning to hindi").b)
        assertEquals("define serendipity", r("define serendipity").a)
    }

    @Test
    fun email() {
        val e = r("email priya at example dot com saying running late")
        assertEquals("email", e.action)
        assertEquals("priya@example.com", e.a)
        assertEquals("running late", e.b)
        assertEquals("", r("send an email").a)
        assertEquals("priya@example.com", Router.spokenEmail("priya at example dot com"))
        assertEquals(null, Router.spokenEmail("mom"))
        // a name is not an address: the draft opens, the body is kept
        assertEquals("", r("email mom saying hello").a)
        assertEquals("hello", r("email mom saying hello").b)
    }

    @Test
    fun remindersWithATime() {
        val a = r("remind me to call mom at 5 pm", clock)
        assertEquals("remind", a.action)
        assertEquals("call mom", a.a)
        assertEquals(at(2026, Calendar.NOVEMBER, 12, 17, 0), a.at)

        // the time can come first
        assertEquals("call mom", r("remind me at 5 pm to call mom", clock).a)

        val b = r("remind me to take medicine tomorrow at 8 am", clock)
        assertEquals("take medicine", b.a)
        assertEquals(at(2026, Calendar.NOVEMBER, 13, 8, 0), b.at)

        assertEquals(at(2026, Calendar.NOVEMBER, 13, 9, 0), r("remind me to water the plants tomorrow morning", clock).at)
        assertEquals(at(2026, Calendar.NOVEMBER, 12, 21, 0), r("remind me to call the bank tonight", clock).at)
        assertEquals(at(2026, Calendar.NOVEMBER, 13, 19, 0), r("remind me to pack at 7 tomorrow evening", clock).at)

        // relative
        assertEquals(now + 600_000L, r("remind me to stretch in 10 minutes", clock).at)
        val c = r("remind me in an hour to stretch", clock)
        assertEquals("stretch", c.a)
        assertEquals(now + 3_600_000L, c.at)

        // 1 pm has already gone today, so it means tomorrow
        assertEquals(at(2026, Calendar.NOVEMBER, 13, 13, 0), r("remind me to call mom at 1 pm", clock).at)

        // no task: still a plain timer. No time: ask.
        assertAction("timer", "remind me in 10 minutes", clock)
        assertAction("ask", "remind me to call mom", clock)
        assertAction("alarm-cancel", "cancel my reminders")
    }

    @Test
    fun whenFromSplitsTaskAndMoment() {
        val (task, due) = Router.whenFrom("call mom at 5 pm tomorrow", now)
        assertEquals("call mom", task)
        assertEquals(at(2026, Calendar.NOVEMBER, 13, 17, 0), due)
        assertEquals(0L, Router.whenFrom("call mom", now).second)
    }

    @Test
    fun dateAndTimeMaths() {
        assertEquals("Tomorrow is Friday, 13 November 2026.", r("what day is it tomorrow", clock).say)
        assertEquals("Yesterday is Wednesday, 11 November 2026.", r("what is the date yesterday", clock).say)
        assertEquals("That is Sunday, 22 November 2026.", r("what day will it be in 10 days", clock).say)
        assertEquals("It will be 5:00 PM.", r("what time will it be in 3 hours", clock).say)
    }

    @Test
    fun moneyAndMaths() {
        assertEquals("A 15% tip on 840 is 126. Total 966.", r("tip on 840 at 15%").say)
        assertEquals("A 10% tip on 840 is 84. Total 924.", r("tip on 840").say)
        assertEquals("Each person pays 300.", r("split 1200 between 4").say)
        assertEquals("Final price 1200. You save 300.", r("20% off 1500").say)
        assertEquals("That is 25%.", r("what percent is 30 of 120").say)
        assertEquals("That is 1024.", r("2 to the power of 10").say)
        assertEquals("That is 8.", r("5 plus 3").say)
        assertEquals("That is 84.", r("what is 12 times 7").say)
        assertEquals("That is 81.", r("9 squared").say)
        assertEquals("The cube root is 3.", r("cube root of 27").say)
        assertEquals("3 hours is 180 minutes.", r("3 hours to minutes").say)
        assertEquals("2 gb is 2048 mb.", r("2 gb to mb").say)
        assertEquals("3 hours is 180 minutes.", r("how many minutes in 3 hours").say)
    }

    @Test
    fun chanceAndSmallTalk() {
        assertAction("coin", "flip a coin")
        val d = r("roll a dice")
        assertEquals(6L, d.num)
        assertEquals(1, d.pct)
        assertEquals(3, r("roll 3 dice").pct)
        assertEquals(20L, r("roll a d20").num)
        val n = r("pick a number between 1 and 50")
        assertEquals("1", n.a)
        assertEquals("50", n.b)
        assertEquals("pizza|pasta", r("pick pizza or pasta").a)
        assertAction("say", "tell me a joke")
        assertAction("say", "how are you")
    }

    @Test
    fun listsAsQuestions() {
        assertEquals("shopping", r("what's on my shopping list").a)
        assertAction("list-show", "what's on my shopping list")
        // the calendar is not a list
        assertAction("agenda", "what's on my calendar")
    }

    @Test
    fun forgivesTypos() {
        assertEquals("set brightness to 40%", Translator.translate("brigtness to 40"))
        assertEquals("increase volume by 20%", Translator.translate("increse the volum by 20"))
        assertEquals("turn on bluetooth", Translator.translate("turn on blutooth"))
        assertEquals("set a timer for 5 minutes", Translator.translate("set a timmer for 5 minutes"))
        assertEquals("open calendar", Translator.translate("open calender"))
        assertEquals(1, Translator.distance("brigtness", "brightness"))
        assertEquals(1, Translator.distance("calendar", "calender"))
        // names and everyday words are left alone
        assertEquals("text priyanka hello", Translator.translate("text priyanka hello"))
        assertEquals("what is 12 times 7", Translator.fixTypos("what is 12 times 7"))
        // under five letters is never touched
        assertEquals("dwon", Translator.fixTypos("dwon"))
        // and it works end to end
        assertAction("brightness", "brigtness to 40")
    }

    @Test
    fun indirectRequests() {
        assertEquals("decrease volume", Translator.translate("it's too loud"))
        assertEquals("decrease volume by 10%", Translator.translate("it's a bit too loud"))
        assertEquals("decrease brightness by 30%", Translator.translate("way too bright in here"))
        assertEquals("increase brightness", Translator.translate("i can't see anything"))
        assertEquals("increase volume", Translator.translate("i can't hear it"))
        assertEquals(-15L, r("it's too loud").num)
        assertAction("brightness-delta", "the screen is too dark")
    }

    @Test
    fun followUpsRememberWhatYouLastChanged() {
        val vol = Ctx(lastTarget = "volume")
        val bri = Ctx(lastTarget = "brightness")
        assertEquals("volume-delta", r("a bit more", vol).action)
        assertEquals(10L, r("a bit more", vol).num)
        assertEquals("brightness-delta", r("a little less", bri).action)
        assertEquals(-10L, r("a little less", bri).num)
        assertEquals(20L, r("20 more", vol).num)
        assertEquals(40, r("set it to 40", bri).pct)
        assertEquals("brightness", r("set it to 40", bri).action)
        // a word that names its own target wins over the context
        assertEquals("volume-delta", r("louder", bri).action)
        // with nothing to follow, there is nothing to guess
        assertAction("unknown", "a bit more")
        // "again" repeats the last command
        assertEquals(30, r("again", Ctx(lastUser = "set brightness to 30%")).pct)
        assertAction("unknown", "again")
    }

    @Test
    fun spokenTimes() {
        assertEquals("set an alarm for 6:30", Translator.translate("set an alarm for half past six"))
        assertEquals("alarm at 6:45", Translator.translate("alarm at quarter to seven"))
        assertEquals("wake me up at 12 pm", Translator.translate("wake me up at noon"))
        assertEquals("alarm for 10:30 pm", Translator.translate("alarm for ten thirty pm"))
        assertEquals("go to youtube.com", Translator.translate("go to youtube dot com"))
        val a = r("set an alarm for half past six")
        assertEquals("alarm", a.action)
        assertEquals(6L, a.num)
        assertEquals(30, a.pct)
        // a bare hour is enough
        assertEquals(7L, r("set alarm for 7").num)
    }

    @Test
    fun phrasingVariants() {
        assertAction("battery", "how much charge do I have")
        assertAction("storage", "how much space is left")
        assertAction("weather", "what's the weather like outside")
        assertEquals("pune", r("weather forecast for pune").a)
        assertEquals("rain", r("do I need an umbrella").b)
        assertEquals("the airport", r("how do I get to the airport").a)
        assertEquals("pharmacy", r("find a pharmacy near me").a)
        assertEquals("spotify", r("launch spotify").a)
        assertAction("call-contact", "ring mom")
        assertAction("flashlight", "turn the light on")
        assertAction("airplane", "flight mode on")
        assertAction("dark-mode", "night mode off")
        assertAction("wifi", "wifi off")
        assertAction("timer", "set a 10 minute timer")
        assertEquals(600_000L, r("set a 10 minute timer").num)
        assertAction("timer", "time me for 20 seconds")
    }

    @Test
    fun chainedCommands() {
        val two = Router.routeAll("turn on wifi and bluetooth")
        assertEquals(listOf("wifi", "bluetooth"), two.map { it.action })
        assertTrue(two.all { it.on })

        assertEquals(
            listOf("brightness", "volume"),
            Router.routeAll("set brightness to 50% and volume to 30%").map { it.action }
        )
        assertEquals(
            listOf("volume-delta", "brightness-delta"),
            Router.routeAll("turn the volume down and the brightness up").map { it.action }
        )
        val apps = Router.routeAll("open youtube and whatsapp")
        assertEquals(listOf("youtube", "whatsapp"), apps.map { it.a })
        assertEquals(
            listOf("alarm", "timer"),
            Router.routeAll("set an alarm for 6 am and a timer for 5 minutes").map { it.action }
        )
        assertEquals(
            listOf("flashlight", "camera"),
            Router.routeAll("turn on the flashlight then open the camera").map { it.action }
        )

        // one command that happens to contain "and" stays one command
        assertEquals(1, Router.routeAll("add milk and eggs to shopping").size)
        // if any part is not understood, nothing is split
        val odd = Router.routeAll("turn on wifi and fly to the moon")
        assertEquals(1, odd.size)
        assertEquals("unknown", odd[0].action)
    }

    @Test
    fun questionsNothingElseClaimedBecomeSearches() {
        assertAction("search", "who is the prime minister of india")
        assertEquals("who is the prime minister of india", r("who is the prime minister of india?").a)
        // too short to be a real question
        assertAction("unknown", "what")
    }

    @Test
    fun preferences() {
        assertEquals("vidya", r("call me Vidya").a)
        assertAction("pref-name", "call me Vidya")
        assertEquals("slow", r("speak slowly").b)
        assertEquals("fast", r("speak faster").b)
        assertEquals("metric", r("use metric units").b)
    }

    // ------------------------------------------------------------------
    // The voice
    // ------------------------------------------------------------------

    @Test
    fun voiceCommands() {
        for (phrase in listOf(
            "change your voice", "try another voice", "use a different voice",
            "give me a less robotic voice", "next voice", "switch voice"
        )) assertEquals("for \"$phrase\"", "next", r(phrase).a)
        assertAction("voice", "change your voice")

        // "list voices" must not be read as a list called "voices"
        assertEquals("list", r("list voices").a)
        assertEquals("list", r("what voices do you have").a)
        assertEquals("install", r("install a voice").a)
        assertEquals("install", r("get more voices").a)
        assertEquals("deeper", r("speak deeper").a)
        assertEquals("higher", r("use a higher voice").a)
        assertEquals("reset", r("reset your voice").a)
        // real lists are unaffected
        assertAction("list-show", "show my shopping list")
    }

    @Test
    fun complainingAboutTheVoiceChangesIt() {
        assertEquals("change voice", Translator.translate("you sound robotic"))
        assertEquals("change voice", Translator.translate("make you sound more human"))
        assertEquals("change voice", Translator.translate("your voice sounds robot-like"))
        assertEquals("change voice", Translator.translate("i don't like this voice"))
        assertEquals("next", r("you sound robotic").a)
        // "sound" and "more" still mean volume everywhere else
        assertEquals("increase volume", Translator.translate("make the music louder"))
    }

    @Test
    fun speechTextReadsLikeAPerson() {
        assertEquals("Brightness 30 percent to 80 percent.", SpeechText.clean("Brightness 30% \u2192 80%."))
        assertEquals("Alarms: 6:30 AM. 7:00 AM", SpeechText.clean("Alarms:\n\u2022 6:30 AM\n\u2022 7:00 AM"))
        assertEquals("Tomorrow, 5 pm", SpeechText.clean("Tomorrow \u2014 5 pm"))
        assertEquals("Tom and Jerry", SpeechText.clean("Tom & Jerry"))
        assertEquals("It is 25 degrees Celsius outside", SpeechText.clean("It is 25\u00B0C outside"))
        assertEquals("Done", SpeechText.clean("**Done**"))
        assertEquals("", SpeechText.clean("   "))
    }
}
