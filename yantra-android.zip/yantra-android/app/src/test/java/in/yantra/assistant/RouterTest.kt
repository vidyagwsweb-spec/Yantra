package `in`.yantra.assistant

import `in`.yantra.assistant.router.Ctx
import `in`.yantra.assistant.router.Router
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The router is pure Kotlin with no Android imports, so it runs as a plain JVM
 * test. `gradle test` executes this on every CI build.
 */
class RouterTest {

    private fun r(text: String, ctx: Ctx = Ctx()) = Router.route(text, ctx)

    private fun assertAction(expected: String, text: String, ctx: Ctx = Ctx()) {
        assertEquals("for \"$text\"", expected, r(text, ctx).action)
    }

    @Test
    fun meta() {
        assertAction("help", "help")
        assertAction("help", "what can you do")
        assertAction("say", "hello")
        assertAction("stop", "stop")
        assertAction("empty", "")
        assertAction("unknown", "make me a sandwich")
    }

    @Test
    fun deviceToggles() {
        assertAction("wifi", "turn on wi-fi")
        assertAction("wifi", "turn off wifi")
        assertEquals(true, r("turn on wi-fi").on)
        assertEquals(false, r("turn off wi-fi").on)

        assertAction("bluetooth", "turn on bluetooth")
        assertAction("airplane", "enable airplane mode")
        assertAction("mobile-data", "turn off mobile data")
        assertAction("flashlight", "turn on the flashlight")
        assertEquals(true, r("turn on the flashlight").on)

        assertAction("dnd", "turn on do not disturb")
        assertAction("dark-mode", "enable dark mode")
        assertAction("battery-saver", "turn on battery saver")
    }

    @Test
    fun screenAndSound() {
        val b = r("set brightness to 50%")
        assertAction("brightness", "set brightness to 50%")
        assertEquals(50, b.pct)

        assertAction("brightness-delta", "increase my screen brightness")
        assertAction("brightness-delta", "decrease brightness")
        assertEquals(100, r("max brightness").pct)

        assertAction("volume", "set the volume to 30%")
        assertEquals(30, r("volume 30").pct)
        assertAction("volume", "mute")
        assertEquals(0, r("mute").pct)
        assertAction("volume-delta", "increase the volume")
    }

    @Test
    fun status() {
        assertAction("battery", "battery")
        assertAction("battery", "what's my current battery percentage")
        assertAction("storage", "how much free storage do I have")
        assertAction("network", "check my internet connection")
        assertAction("device", "show my device information")
        assertAction("location", "where am I")
    }

    @Test
    fun apps() {
        assertAction("open-app", "open youtube")
        assertEquals("youtube", r("open youtube").a)
        assertAction("open-app", "open whatsapp")
        assertAction("home", "go home")
        assertAction("list-apps", "show my apps")
    }

    @Test
    fun people() {
        assertAction("call", "call 9876543210")
        assertEquals("9876543210", r("call 9876543210").a)
        assertAction("call-contact", "call mom")
        assertEquals("mom", r("call mom").a)

        val sms = r("text 9876543210 saying I am late")
        assertAction("sms", "text 9876543210 saying I am late")
        assertEquals("9876543210", sms.a)
        assertTrue(sms.b.contains("late"))

        assertAction("whatsapp", "whatsapp 9876543210 saying I am late")
        assertAction("find-contact", "find mom's contact")
        assertAction("read-notifications", "read my notifications")
    }

    @Test
    fun alarmsAndTimers() {
        val a = r("set an alarm for 6:30 am")
        assertAction("alarm", "set an alarm for 6:30 am")
        assertEquals(6L, a.num)
        assertEquals(30, a.pct)

        val pm = r("alarm at 7 pm")
        assertEquals(19L, pm.num)

        assertAction("timer", "set a timer for 10 minutes")
        assertEquals(600_000L, r("set a timer for 10 minutes").num)
        assertEquals(45_000L, r("timer for 45 seconds").num)
        assertEquals(90_000L, r("set a timer for 1 minute 30 seconds").num)
        assertEquals(7_200_000L, r("set a timer for two hours").num)

        assertAction("timer-pause", "pause the timer")
        assertAction("timer-resume", "resume the timer")
        assertAction("timer-cancel", "cancel the timer")
        assertAction("timer-status", "how much time is left")
        assertAction("alarm-list", "show my alarms")
    }

    @Test
    fun mathsAndUnits() {
        assertAction("say", "15% of 2400")
        assertTrue(r("15% of 2400").say.contains("360"))
        assertTrue(r("12 * 34").say.contains("408"))
        assertTrue(r("square root of 729").say.contains("27"))
        assertTrue(r("5 km to miles").say.contains("3.10"))
        assertTrue(r("100 f to c").say.contains("37.7"))
    }

    @Test
    fun listsAndCalendar() {
        val add = r("add milk to shopping")
        assertAction("list-add", "add milk to shopping")
        assertEquals("shopping", add.a)
        assertEquals("milk", add.b)

        assertAction("list-show", "show my shopping")
        assertAction("list-remove", "remove milk from shopping")
        assertAction("list-add", "note that I parked on level 2")
        assertAction("list-show", "show my notes")

        val ev = r("add event dentist tomorrow at 5pm")
        assertAction("calendar-add", "add event dentist tomorrow at 5pm")
        assertEquals("dentist", ev.a)
        assertTrue(ev.at > 0)

        assertAction("agenda", "what's on my calendar")
    }

    @Test
    fun web() {
        assertAction("search", "search for train timings")
        assertAction("navigate", "navigate to Pune airport")
        assertAction("nearby", "find the nearest ATM")
        assertAction("weather", "weather in Pune")
        assertAction("weather", "will it rain")
    }

    @Test
    fun memoryAndPrefs() {
        val ctx = Ctx(lastBot = "Pune: 29C and partly cloudy.", lastUser = "weather in Pune")
        assertEquals("Pune: 29C and partly cloudy.", r("repeat that", ctx).say)
        assertTrue(r("what did I ask", ctx).say.contains("weather in Pune"))
        assertAction("pref-name", "call me Vidya")
        assertAction("pref", "use metric units")
    }

    @Test
    fun messagingSplitsRecipientFromBody() {
        val party = r("Send a message to X to come to the party at 3 o'clock")
        assertAction("sms-contact", "Send a message to X to come to the party at 3 o'clock")
        assertEquals("x", party.a)
        assertEquals("come to the party at 3 oclock", party.b)

        val mom = r("text mom saying I am late")
        assertEquals("mom", mom.a)
        assertEquals("i am late", mom.b)

        val num = r("send a message to 9876543210 saying I am late")
        assertAction("sms", "send a message to 9876543210 saying I am late")
        assertEquals("9876543210", num.a)

        // no recipient: the executor asks who
        assertAction("say", "send a message saying I am on my way")
    }

    @Test
    fun normalisation() {
        assertEquals("15% of 2400", Router.normalize("15% of 2,400"))
        assertEquals("whats the time", Router.normalize("What's the time?"))
        assertEquals(600_000L, Router.durationMs("ten minutes"))
    }
}
