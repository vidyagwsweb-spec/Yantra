#!/usr/bin/env python3
"""
Replays the mini brain's matching in Python, reading the phrase data straight
from BrainData.kt, so the thresholds in Brain.kt can be checked without a JDK.

  python3 tools/tune-brain.py            # run the built-in checks
  python3 tools/tune-brain.py "its dark" # score one sentence

Keep the constants and functions below in step with Brain.kt.
"""
import math, re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java/in/yantra/assistant/brain"
DATA = (ROOT / "BrainData.kt").read_text(encoding="utf-8")
BRAIN = (ROOT / "Brain.kt").read_text(encoding="utf-8")

def const(name):
    return float(re.search(r"const val %s = ([0-9.]+)" % name, BRAIN).group(1))

CHAT_MIN, ASK_MIN, RUN_MIN, SURE, MARGIN = (const(n) for n in ("CHAT_MIN", "ASK_MIN", "RUN_MIN", "SURE", "MARGIN"))

stop_block = re.search(r"private val STOP = hashSetOf\((.*?)\)\n", BRAIN, re.S).group(1)
STOP = set(re.findall(r'"([^"]+)"', stop_block))
syn_block = re.search(r"private val SYNONYMS = mapOf\((.*?)\)\n", BRAIN, re.S).group(1)
SYN = dict(re.findall(r'"([^"]+)" to "([^"]+)"', syn_block))

def norm(s):
    s = s.lower().replace("\u2018", "").replace("\u2019", "").replace("'", "")
    s = re.sub(r"[^a-z0-9\u00b0 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def stem(w):
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"): w = w[:-1]
    if len(w) > 5 and w.endswith("ing"): w = w[:-3]
    elif len(w) > 4 and w.endswith("ed"): w = w[:-2]
    if len(w) > 3 and w.endswith("e"): w = w[:-1]
    return w

def tokens(s):
    return [stem(SYN.get(w, w)) for w in norm(s).split(" ") if w and w not in STOP]

def edit(a, b, limit):
    if a == b: return 0
    if abs(len(a) - len(b)) > limit: return limit + 1
    prev = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]))
        if min(cur) > limit: return limit + 1
        prev = cur
    return prev[-1]

def tsim(a, b):
    if a == b: return 1.0
    if len(a) >= 5 and len(b) >= 5 and edit(a, b, 1) <= 1: return 0.85
    if len(a) >= 8 and len(b) >= 8 and edit(a, b, 2) <= 2: return 0.7
    return 0.0

# ---- load data
entries = []   # (kind, id, tokens)
for m in re.finditer(r'Intent\(\s*"([^"]+)",\s*examples = listOf\((.*?)\),\s*replies', DATA, re.S):
    for ex in re.findall(r'"([^"]+)"', m.group(2)): entries.append(("intent", m.group(1), tokens(ex)))
for m in re.finditer(r'CommandEntry\(\s*"([^"]+)",\s*examples = listOf\((.*?)\),\s*ask = "[^"]*"(,\s*alwaysAsk = true)?', DATA, re.S):
    for ex in re.findall(r'"([^"]+)"', m.group(2)): entries.append(("cmd" + ("!" if m.group(3) else ""), m.group(1), tokens(ex)))

df = {}
for _, _, t in entries:
    for x in set(t): df[x] = df.get(x, 0) + 1
N = len(entries)
IDF = {t: math.log(1 + N / d) for t, d in df.items()}
MAXIDF = math.log(1 + N)
W = lambda t: IDF.get(t, MAXIDF)

def sim(q, d):
    if not q or not d: return 0.0
    qw = qm = dw = dm = 0.0
    for a in q:
        qw += W(a); qm += W(a) * max(tsim(a, b) for b in d)
    for b in d:
        dw += W(b); dm += W(b) * max(tsim(a, b) for a in q)
    return math.sqrt((qm / qw) * (dm / dw))

VOCAB = list(IDF)
def known(t):
    return t in IDF or any(tsim(t, v) >= 0.7 for v in VOCAB)

def think(text):
    q = tokens(text)
    if not q: return ("pass", None, 0.0)
    if sum(1 for t in q if not known(t)) * 3 >= len(q): return ("pass", "unknown words", 0.0)
    best = {}
    for kind, id_, t in entries:
        s = sim(q, t)
        if s > best.get((kind, id_), 0): best[(kind, id_)] = s
    ranked = sorted(best.items(), key=lambda kv: -kv[1])
    if not ranked: return ("pass", None, 0.0)
    (kind, id_), top = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0.0
    if top - second < MARGIN and top < SURE: return ("pass", "ambiguous " + id_, top)
    if kind == "intent":
        return ("reply", id_, top) if top >= CHAT_MIN else ("pass", id_, top)
    if top >= RUN_MIN and kind == "cmd": return ("run", id_, top)
    if top >= ASK_MIN: return ("confirm", id_, top)
    return ("pass", id_, top)

CHECKS = [
    # (sentence, expected kind, expected id or None)
    ("tell me a joke", "reply", "joke"), ("make me laugh please", "reply", "joke"),
    ("can you tell me a funny joke", "reply", "joke"), ("got a joke for me", "reply", "joke"),
    ("tell me a fun fact", "reply", "fact"), ("tell me something interesting", "reply", "fact"),
    ("who created you", "reply", "creator"), ("who made you yaar", "reply", "creator"),
    ("do you have feelings", "reply", "feelings"), ("are you alive", "reply", "feelings"),
    ("i am feeling really sad today", "reply", "low"), ("i feel lonely", "reply", "low"),
    ("im so stressed", "reply", "low"), ("i am bored", "reply", "bored"),
    ("what should i eat tonight", "reply", "hungry"), ("good night", "reply", "good-night"),
    ("you are awesome", "reply", "compliment"), ("you are so stupid", "reply", "insult"),
    ("i love you", "reply", "love"), ("what does yantra mean", "reply", "yantra-meaning"),
    ("how fast is light", "reply", "k-light"), ("how many planets are there", "reply", "k-planets"),
    ("national animal of india", "reply", "k-animal"), ("how many states does india have", "reply", "k-states"),
    ("what temperature does water boil at", "reply", "k-boil"), ("can you learn", "reply", "can-learn"),
    ("its dark in here", ("run", "confirm"), "turn on flashlight"),
    ("i cant see anything its so dark", ("run", "confirm", "pass"), None),
    ("the screen is too bright", ("run", "confirm"), "decrease brightness"),
    ("my screen is too dim", ("run", "confirm"), "increase brightness"),
    ("i cant hear you", ("run", "confirm"), "increase volume"),
    ("that is too loud", ("run", "confirm"), "decrease volume"),
    ("im in a meeting", "confirm", "turn on do not disturb"),
    ("how is the weather today", ("run", "confirm"), "weather"),
    ("is it going to rain", ("run", "confirm"), "weather"),
    ("how much charge is left", ("run", "confirm"), "battery"),
    ("my wifi is not working", ("run", "confirm"), "open wifi settings"),
    ("skip this song", ("run", "confirm"), "next song"),
    ("got the time", ("run", "confirm"), "what time is it"),
    # must NOT be claimed
    ("make me a sandwich", "pass", None), ("who is the prime minister of india", "pass", None),
    ("what is the population of mumbai", "pass", None), ("how do i bake a cake", "pass", None),
    ("why is the sky blue", "pass", None), ("what is the price of gold today", "pass", None),
    ("book a cab to the airport", "pass", None), ("tell me about the french revolution", "pass", None),
    ("the joke was not funny at all", "pass", None), ("how old is the eiffel tower", "pass", None),
    ("translate hello to french", "pass", None), ("play some jazz", "pass", None),
    ("what is the gdp of india", "pass", None), ("who won the match yesterday", "pass", None),
    ("what is the meaning of life", "pass", None), ("how does a car engine work", "pass", None),
    ("tell me about mahatma gandhi", "pass", None), ("how many people live in delhi", "pass", None),
    ("i want to buy a laptop", "pass", None), ("what is machine learning", "pass", None),
    # typos and word order
    ("tel me a joke", ("reply", "pass"), None), ("tell me a jokes", "reply", "joke"),
    ("joke tell me", "reply", "joke"), ("favorite color", "reply", "favourite"),
    ("how many planets are in the solar system", "reply", "k-planets"),
    ("flashlite please", ("run", "confirm"), "turn on flashlight"),
    ("screen is very bright", ("run", "confirm"), "decrease brightness"),
    ("the volume is too low", ("run", "confirm"), "increase volume"),
    ("sorry bhai", "reply", "sorry"), ("bye bye", "reply", "bye"),
    ("who is your developer", "reply", "creator"), ("how old are you", "reply", "age"),
]

def main():
    if len(sys.argv) > 1 and sys.argv[1] != "-v":
        for s in sys.argv[1:]: print(s, "->", think(s))
        return
    bad = 0
    for text, kind, id_ in CHECKS:
        got_kind, got_id, score = think(text)
        kinds = kind if isinstance(kind, tuple) else (kind,)
        ok = got_kind in kinds and (id_ is None or got_id == id_)
        if "-v" in sys.argv: print("%-6s %-45s %s %s %.2f" % ("ok" if ok else "FAIL", text, got_kind, got_id, score))
        if not ok:
            bad += 1
            print("FAIL %-45s want %s %s  got %s %s (%.2f)" % (text, kinds, id_, got_kind, got_id, score))
    print("%d entries, %d checks, %d failed" % (N, len(CHECKS), bad))
    sys.exit(1 if bad else 0)

main()
