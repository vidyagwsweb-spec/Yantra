#!/usr/bin/env node
/*
 * Verifies the thinking layer (app/.../mind) without a JDK.
 *
 * Every regex is pulled straight out of the Kotlin source, so a typo in a
 * pattern fails here. The control flow of PlanParser, Memory and Reasoner is
 * ported by hand and mirrors the Kotlin. The command forms taught to the
 * language model are replayed through the router's patterns (via
 * verify-translator.js), so the model can only be taught commands the app
 * understands.
 *
 *   node tools/verify-mind.js
 */
const fs = require('fs');
const path = require('path');
const MIND = path.join(__dirname, '..', 'app/src/main/java/in/yantra/assistant/mind') + '/';
const read = f => fs.readFileSync(MIND + f, 'utf8');
const router = require('./verify-translator.js');

// ------------------------------------------------------------ extraction
const unesc = body => body.replace(/\\(u[0-9a-fA-F]{4}|.)/g, (_, c) =>
  c[0] === 'u' && c.length === 5 ? String.fromCharCode(parseInt(c.slice(1), 16)) : c === 'n' ? '\n' : c === 't' ? '\t' : c);
const callText = (src, from) => { // text of Regex( ... ) starting at index of "Regex("
  let i = from + 6, depth = 1, inStr = false, out = '';
  for (; i < src.length && depth > 0; i++) {
    const c = src[i];
    if (inStr) { out += c; if (c === '\\') { out += src[++i]; } else if (c === '"') inStr = false; continue; }
    out += c;
    if (c === '"') inStr = true; else if (c === '(') depth++; else if (c === ')') depth--;
  }
  return out;
};
function kt(src, name, consts = {}) {
  const at = src.search(new RegExp('val ' + name + ' = Regex\\('));
  if (at < 0) throw new Error('no regex ' + name);
  const call = callText(src, src.indexOf('Regex(', at));
  let body = [...call.matchAll(/"((?:[^"\\]|\\.)*)"/g)].map(m => unesc(m[1])).join('');
  for (const [k, v] of Object.entries(consts)) body = body.split('$' + k).join(v);
  let flags = '';
  if (/IGNORE_CASE/.test(call) || body.startsWith('(?i)')) flags += 'i';
  body = body.replace(/\(\?i\)/g, '');
  return new RegExp(body, flags);
}
const PLAN = read('Plan.kt'), MEM = read('Memory.kt'), REA = read('Reasoner.kt'), PRO = read('Prompts.kt');

// ----------------------------------------------------------- PlanParser
const DO = kt(PLAN, 'DO'), SAY = kt(PLAN, 'SAY'), NOTHING = kt(PLAN, 'NOTHING'), END_TOKENS = new RegExp(kt(PLAN, 'END_TOKENS').source, 'g');
function speech(s) {
  let t = s.replace(/[*_#>`]+/g, '').replace(/\[(.*?)]\(.*?\)/g, '$1').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  if (t.length > 600) { const cut = t.slice(0, 600); const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('? '), cut.lastIndexOf('! '));
    t = end > 200 ? cut.slice(0, end + 1) : cut.trimEnd() + '\u2026'; }
  return t;
}
const tidyCommand = s => s.trim().replace(/[.;]+$/, '').trim().replace(/^["\u201C\u201D'`]+|["\u201C\u201D'`]+$/g, '').trim().replace(/[.;]+$/, '').trim();
function parsePlan(raw) {
  const text = raw.replace(END_TOKENS, '').replace(/```/g, '').replace(/\*\*/g, '').replace(/\r/g, '');
  const commands = []; let say = ''; let inSay = false, saw = false;
  for (const line of text.split('\n')) {
    let m = DO.exec(line);
    if (m) { saw = true; inSay = false; const c = tidyCommand(m[1]); if (c && !NOTHING.test(c) && !commands.includes(c) && commands.length < 3) commands.push(c); continue; }
    m = SAY.exec(line);
    if (m) { saw = true; inSay = true; say += m[1] + '\n'; continue; }
    if (inSay) say += line + '\n';
  }
  if (!saw) say += text;
  return { commands, say: speech(say) };
}

// --------------------------------------------------------------- Memory
const C = { REL_WORDS: MEM.match(/const val REL_WORDS = "([^"]*)"/)[1] };
const R = {};
for (const n of ['SECRET', 'LONG_DIGITS', 'FORGET_ALL', 'FORGET_MY', 'FORGET_THAT', 'LIST_ALL', 'WHERE_LIVE', 'ASK_MY', 'REMEMBER', 'MY_IS', 'REL', 'PROP', 'LIVE', 'WORK', 'FROM', 'DIET']) R[n] = kt(MEM, n, C);
const whole = (re, s) => { const m = new RegExp('^(?:' + re.source + ')$', re.flags).exec(s); return m; };
const RELATIONS = new Set(['mom', 'mother', 'mum', 'dad', 'father', 'wife', 'husband', 'brother', 'sister', 'boss', 'friend', 'best friend', 'partner', 'son', 'daughter', 'girlfriend', 'boyfriend', 'roommate']);
class Memory {
  constructor() { this.f = new Map(); }
  topicOf(s) { let t = s.toLowerCase().replace(/[\u2018\u2019']/g, '').trim(); t = t.replace(/^(?:the|my)\s+/, '').replace(/\s+name$/, '').trim();
    if (t.length > 3 && t.endsWith('s') && RELATIONS.has(t.slice(0, -1))) t = t.slice(0, -1); return t; }
  sameTopic(a, b) { const A = new Set(a.split(' ').filter(Boolean)), B = new Set(b.split(' ').filter(Boolean));
    return A.size && B.size && ([...B].every(x => A.has(x)) || [...A].every(x => B.has(x))); }
  sentence(k, v) { return k.startsWith('note:') ? v : `Your ${k} is ${v}.`; }
  secondPerson(s) { let t = ' ' + s.trim() + ' ';
    for (const [a, b] of [['i am', 'you are'], ["i'm", 'you are'], ['im', 'you are'], ['i was', 'you were'], ['i have', 'you have'], ['i', 'you'], ['my', 'your'], ['me', 'you'], ['mine', 'yours'], ['myself', 'yourself']])
      t = t.replace(new RegExp('(?<=\\W)' + a + '(?=\\W)', 'gi'), b);
    t = t.trim(); t = t[0].toUpperCase() + t.slice(1); return t.endsWith('.') ? t : t + '.'; }
  refuse(s) { if (R.SECRET.test(s.toLowerCase()) || R.LONG_DIGITS.test(s.replace(/[ -]/g, ''))) return 'I will not store that.'; return null; }
  put(topic, value) { if (!topic || !value) return 'I could not tell what to remember there.'; const r = this.refuse(topic + ' ' + value); if (r) return r;
    this.f.set(topic, value); return `Okay, your ${topic} is ${value}.`; }
  note(sentence) { const r = this.refuse(sentence); if (r) return r; this.f.set('note:' + sentence.toLowerCase().slice(0, 48), sentence); return 'Okay, I will remember that.'; }
  clean(s) { return s.trim().replace(/^["\u201C\u201D]+|["\u201C\u201D]+$/g, '').trim().replace(/\.+$/, ''); }
  handle(raw) {
    const text = raw.trim().replace(/[.!?]+$/, '').trim(); if (!text || text.length > 200) return null;
    const low = text.toLowerCase().replace(/[\u2018\u2019']/g, ''); let m;
    if (whole(R.FORGET_ALL, text)) { const n = this.f.size; this.f.clear(); return n === 0 ? 'I was not holding anything about you.' : `Forgot all ${n} ${n === 1 ? 'thing' : 'things'} I knew about you.`; }
    if ((m = whole(R.FORGET_MY, text))) { const key = this.topicOf(m[1]); if (key.startsWith('shortcut') || !key) return null;
      const hit = [...this.f.keys()].find(k => k.startsWith('note:') ? k.includes(key) : this.sameTopic(k, key));
      if (hit) { this.f.delete(hit); return `Forgot your ${key}.`; } return `I do not have anything saved about your ${key}.`; }
    if ((m = whole(R.FORGET_THAT, text))) { const needle = this.secondPerson(m[1]).toLowerCase().replace(/\.+$/, '');
      if (needle.length < 4 || needle.startsWith('shortcut') || needle.startsWith('all ')) return null;
      const word = new RegExp('\\b' + needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b');
      const hit = [...this.f.entries()].find(([k, v]) => word.test(this.sentence(k, v).toLowerCase()));
      if (hit) { this.f.delete(hit[0]); return 'Forgot that.'; } return null; }
    if (whole(R.LIST_ALL, low)) return this.f.size ? 'Here is what you told me:\n' + [...this.f].slice(-15).map(([k, v]) => '\u2022 ' + this.sentence(k, v)).join('\n') : 'Nothing yet.';
    if (whole(R.WHERE_LIVE, low)) return this.f.has('home') ? `You live in ${this.f.get('home')}.` : null;
    if ((m = whole(R.ASK_MY, low))) { const key = this.topicOf(m[1]); const hit = [...this.f].find(([k]) => !k.startsWith('note:') && this.sameTopic(k, key)); return hit ? `Your ${hit[0]} is ${hit[1]}.` : null; }
    if ((m = whole(R.REMEMBER, text))) { const body = m[1].trim(); if (!body) return null; if (body.toLowerCase().startsWith('to ')) return null;
      const my = whole(R.MY_IS, body); if (my) return this.put(this.topicOf(my[1]), this.clean(my[2])); return this.note(this.secondPerson(body)); }
    if ((m = whole(R.REL, text))) return this.put(m[1].toLowerCase(), this.clean(m[2]));
    if ((m = whole(R.PROP, text))) return this.put(this.topicOf(m[1]), this.clean(m[2]));
    if ((m = whole(R.LIVE, text))) return this.put('home', this.clean(m[1]));
    if ((m = whole(R.WORK, text))) return this.note(`You work ${m[1].toLowerCase()} ${this.clean(m[2])}.`);
    if ((m = whole(R.FROM, text))) return this.note(`You are from ${this.clean(m[1])}.`);
    if ((m = whole(R.DIET, text))) return this.note(`You are ${m[1].toLowerCase()}.`);
    return null;
  }
}

// ------------------------------------------------------------- Reasoner
const LEAD = kt(REA, 'LEAD'), TAIL = kt(REA, 'TAIL'), ADD_PCT = kt(REA, 'ADD_PCT'), DATE_LIKE = kt(REA, 'DATE_LIKE'), ALLOWED = new RegExp(kt(REA, 'ALLOWED').source, 'g');
const WORDS = [...REA.slice(REA.indexOf('val WORDS'), REA.indexOf('/** "2500')).matchAll(/Regex\("((?:[^"\\]|\\.)*)"\) to "((?:[^"\\]|\\.)*)"/g)].map(m => [new RegExp(unesc(m[1]), 'g'), unesc(m[2])]);
function calc(src) {
  const toks = []; let p = 0;
  while (p < src.length) { const c = src[p];
    if (c === ' ') p++;
    else if (/[\d.]/.test(c)) { let q = p; while (q < src.length && /[\d.]/.test(src[q])) q++; toks.push(src.slice(p, q)); p = q; }
    else if (/[a-z]/i.test(c)) { let q = p; while (q < src.length && /[a-z]/i.test(src[q])) q++; toks.push(src.slice(p, q)); p = q; }
    else { toks.push(c); p++; } }
  let i = 0; const peek = () => toks[i];
  const err = m => { const e = new Error(m); e.arith = true; return e; };
  const bad = m => { const e = new Error(m); e.bad = true; return e; };
  function expr() { let v = term(); for (;;) { if (peek() === '+') { i++; v += term(); } else if (peek() === '-') { i++; v -= term(); } else return v; } }
  function term() { let v = unary(); for (;;) { const t = peek();
    if (t === '*') { i++; v *= unary(); } else if (t === '/') { i++; const d = unary(); if (d === 0) throw err('I cannot divide by zero.'); v /= d; }
    else if (t === 'mod') { i++; const d = unary(); if (d === 0) throw err('I cannot divide by zero.'); v %= d; } else return v; } }
  function unary() { if (peek() === '-') { i++; return -unary(); } if (peek() === '+') { i++; return unary(); } return power(); }
  function power() { const b = postfix(); if (peek() === '^') { i++; return Math.pow(b, unary()); } return b; }
  function postfix() { let v = primary(); while (peek() === '%') { i++; v /= 100; } return v; }
  function primary() { const t = peek(); if (t === undefined) throw bad('end'); i++;
    if (t === '(') { const v = expr(); if (peek() !== ')') throw bad('paren'); i++; return v; }
    if (t === 'pi') return Math.PI;
    if (/^[\d.]/.test(t)) { const n = Number(t); if (Number.isNaN(n)) throw bad('number'); return n; }
    if (['sqrt', 'abs', 'round', 'floor', 'ceil'].includes(t)) { if (peek() !== '(') throw bad('call'); i++; const v = expr(); if (peek() !== ')') throw bad('paren'); i++;
      if (t === 'sqrt') { if (v < 0) throw err('There is no real square root of a negative number.'); return Math.sqrt(v); }
      return t === 'abs' ? Math.abs(v) : t === 'round' ? Math.round(v) : t === 'floor' ? Math.floor(v) : Math.ceil(v); }
    throw bad('unexpected ' + t); }
  const v = expr(); if (i !== toks.length) throw bad('trailing'); return v;
}
const fmt = v => v.toLocaleString('en-US', { maximumFractionDigits: 6 });
function evaluate(raw) {
  let t = raw.toLowerCase().replace(/[\u2018\u2019']/g, '').trim(); if (!t || t.length > 160) return null;
  t = t.replace(LEAD, '').replace(TAIL, '').replace(/(?<=\d),(?=\d{3})/g, '');
  for (const [re, to] of WORDS) t = t.replace(re, to);
  t = t.replace(/\b(sqrt|abs|round|floor|ceil)\s+(\d+(?:\.\d+)?)/g, '$1($2)');
  t = t.replace(ADD_PCT, (_, a, op, b) => `${a} ${op} (${a}*${b}/100)`).replace(/\s+/g, ' ').trim();
  if (DATE_LIKE.test(t)) return null;
  if (t.replace(ALLOWED, '').trim()) return null;
  if (!/\d/.test(t)) return null;
  if (!/[+\-*/^%()]|sqrt|abs|round|floor|ceil|pi|mod/.test(t.replace(/^-+/, ''))) return null;
  try { const v = calc(t); return Number.isFinite(v) ? `It is ${fmt(v)}.` : 'That does not work out to a number.'; }
  catch (e) { return e.arith ? e.message : null; }
}

// ----------------------------------------------------------------- tests
let pass = 0, fail = 0;
const eq = (label, got, want) => { const ok = JSON.stringify(got) === JSON.stringify(want); if (ok) pass++; else { fail++; console.log('FAIL', label, '\n   got ', JSON.stringify(got), '\n   want', JSON.stringify(want)); } };

// plan parser
eq('do+say', parsePlan('DO: turn off wifi\nSAY: Turning Wi-Fi off.'), { commands: ['turn off wifi'], say: 'Turning Wi-Fi off.' });
eq('say only', parsePlan('SAY: When should I remind you?'), { commands: [], say: 'When should I remind you?' });
eq('no markers', parsePlan('The sky looks blue because air scatters blue light most.'), { commands: [], say: 'The sky looks blue because air scatters blue light most.' });
eq('end tokens', parsePlan('SAY: Hello there.<end_of_turn>'), { commands: [], say: 'Hello there.' });
eq('none', parsePlan('DO: none\nSAY: Okay.'), { commands: [], say: 'Okay.' });
eq('quotes', parsePlan('DO: "open spotify".\nSAY: Opening it.'), { commands: ['open spotify'], say: 'Opening it.' });
eq('dupes and cap', parsePlan('DO: mute\nDO: mute\nDO: play\nDO: pause\nDO: next song\nSAY: ok').commands, ['mute', 'play', 'pause']);
eq('bold markers', parsePlan('**DO:** turn on flashlight\n**SAY:** Done.'), { commands: ['turn on flashlight'], say: 'Done.' });
eq('bullets', parsePlan('- DO: pause\n- SAY: Paused.'), { commands: ['pause'], say: 'Paused.' });
eq('multiline say', parsePlan('SAY: First line.\nSecond line.'), { commands: [], say: 'First line.\nSecond line.' });
eq('lowercase markers', parsePlan('do: mute\nsay: Muted.'), { commands: ['mute'], say: 'Muted.' });
eq('chatml', parsePlan('SAY: Hi.<|im_end|>'), { commands: [], say: 'Hi.' });
eq('markdown stripped', parsePlan('SAY: This is **bold** and `code`.').say, 'This is bold and code.');
eq('calc command survives', parsePlan('DO: what is 12 * 7').commands, ['what is 12 * 7']);

// memory
{
  const m = new Memory();
  eq('birthday', m.handle('my birthday is 3 March'), 'Okay, your birthday is 3 March.');
  eq('ask birthday', m.handle("what's my birthday?"), 'Your birthday is 3 March.');
  eq('when birthday', m.handle('when is my birthday'), 'Your birthday is 3 March.');
  eq('relation', m.handle("my mom's name is Sunita"), 'Okay, your mom is Sunita.');
  eq('who is mom', m.handle('who is my mom'), 'Your mom is Sunita.');
  eq('relation2', m.handle('my sister is Priya.'), 'Okay, your sister is Priya.');
  eq('live', m.handle('I live in Pune'), 'Okay, your home is Pune.');
  eq('where live', m.handle('where do i live'), 'You live in Pune.');
  eq('remember note', m.handle('remember that I am vegetarian'), 'Okay, I will remember that.');
  eq('diet direct', m.handle("I'm vegan"), 'Okay, I will remember that.');
  eq('remember my is', m.handle('remember that my favourite colour is teal'), 'Okay, your favourite colour is teal.');
  eq('list', m.handle('what do you know about me').split('\n').slice(0, 1), ['Here is what you told me:']);
  eq('list has note', m.handle('what do you know about me').includes('You are vegetarian.'), true);
  eq('forget my', m.handle('forget my birthday'), 'Forgot your birthday.');
  eq('forgotten', m.handle('when is my birthday'), null);
  eq('forget that', m.handle('forget that I am vegetarian'), 'Forgot that.');
  eq('forget all', m.handle('forget everything about me'), 'Forgot all 5 things I knew about you.');
  eq('secret', new Memory().handle('remember that my wifi password is hunter2'), 'I will not store that.');
  eq('card', new Memory().handle('remember that my card number is 4111 1111 1111 1111'), 'I will not store that.');
  eq('remember to is not a fact', new Memory().handle('remember to call mom'), null);
  eq('ordinary chat ignored', new Memory().handle('I am bored'), null);
  eq('ordinary chat 2', new Memory().handle('my phone is dead'), null);
  eq('car vs card', (() => { const x = new Memory(); x.handle('my car is a swift'); return x.handle('what is my card limit'); })(), null);
  eq('shortcuts left to brain', new Memory().handle('forget all shortcuts'), null);
  eq('forget about it', new Memory().handle('forget about it'), null);
  eq('whats my battery', new Memory().handle('what is my battery level'), null);
  eq('work', new Memory().handle('I work at Infosys'), 'Okay, I will remember that.');
}

// reasoner
for (const [q, want] of [
  ['what is 15% of 2400', 'It is 360.'], ['(12+8)*3/4', 'It is 15.'], ['2500 + 18%', 'It is 2,950.'], ['100 - 20%', 'It is 80.'],
  ['square root of 144 times 3', 'It is 36.'], ['10 divided by 0', 'I cannot divide by zero.'], ['12 times 7', 'It is 84.'],
  ['2 to the power of 10', 'It is 1,024.'], ['what is 1,200 plus 300', 'It is 1,500.'], ['sqrt 144', 'It is 12.'], ['half of 90', 'It is 45.'],
  ['calculate 7 mod 3', 'It is 1.'], ['-2^2', 'It is -4.'], ['50% of 80 plus 10', 'It is 50.'], ['what is 3.5 x 2', 'It is 7.'],
  ['9876543210', null], ['13/11/2026', null], ['hello there', null], ['call 5 minutes', null], ['turn on wifi and bluetooth', null],
  ['what is pi', null], ['12 34', null], ['(2+3', null], ['2 +', null], ['square root of -4', 'There is no real square root of a negative number.'],
  ['pizza 2', null], ['model 3 plus 4', null], ['2^1000^1000', 'That does not work out to a number.'],
]) eq('calc ' + q, evaluate(q), want);

// commands taught to the model must be understood by the router
const doLines = [...PRO.matchAll(/^DO: (.+)$/gm)].map(m => m[1]);
const forms = [
  'turn on flashlight', 'turn off wifi', 'turn on bluetooth', 'turn on do not disturb', 'turn off airplane mode', 'turn on mobile data', 'turn on hotspot',
  'turn on location', 'turn on auto rotate', 'turn on dark mode', 'turn on battery saver', 'set brightness to 40%', 'increase brightness by 20%',
  'decrease volume by 10%', 'set volume to 60%', 'mute', 'unmute', 'silent mode', 'vibrate mode', 'play', 'pause', 'next song', 'previous song',
  'open spotify', 'open wifi settings', 'call mom', 'call 9876543210', 'text mom saying i am late', 'whatsapp priya saying running late',
  'email priya@example.com saying hello', 'set an alarm for 6:30 am', 'set a timer for 5 minutes', 'remind me to call mom at 5 pm',
  'remind me to buy milk in 30 minutes', 'remind me to pay rent tomorrow at 9 am', 'add event dentist tomorrow 5pm', 'what is on my calendar',
  'navigate to koramangala', 'weather', 'weather in pune', 'search for best biryani near me', 'take a photo', 'battery', 'add milk to shopping list',
  'show shopping list', 'what time is it', 'read my notifications', 'clear notifications', 'translate hello to hindi', 'go to youtube.com', 'play shape of you on youtube',
];
const known = c => { const r = router.routeAll(c); return r.length > 0 && r.every(x => x && x.action !== 'ask'); };
for (const c of [...new Set([...doLines, ...forms])]) eq('router understands "' + c + '"', known(c), true);
// and the prompt's list advertises every form we tested
for (const frag of ['turn on|off flashlight', 'set an alarm for H:MM am|pm', 'text <name or number> saying <message>', 'remind me to <task> at H pm', 'navigate to <place>'])
  eq('prompt lists ' + frag, PRO.includes(frag), true);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
