const fs = require('fs');
const SRC = require('path').join(__dirname, '..', 'app/src/main/java/in/yantra/assistant/router') + '/';
const unesc = s => s.replace(/\\\\/g, '\u0000').replace(/\\"/g, '"').replace(/\\u2018/g,'\u2018').replace(/\\u2019/g,'\u2019').replace(/\u0000/g, '\\');
const T = fs.readFileSync(SRC + 'Translator.kt', 'utf8');
const R = fs.readFileSync(SRC + 'Rewriter.kt', 'utf8');
const RT = fs.readFileSync(SRC + 'Router.kt', 'utf8');

// ---- named regexes from Translator
const N = {};
for (const m of T.matchAll(/private val (\w+) = Regex\("((?:[^"\\]|\\.)*)"\)/g)) N[m[1]] = new RegExp(unesc(m[2]));
const rulesIn = (txt) => [...txt.matchAll(/Rule\(\s*Regex\("((?:[^"\\]|\\.)*)"\),\s*"((?:[^"\\]|\\.)*)"\s*\)/g)].map(m => [new RegExp(unesc(m[1]), 'g'), unesc(m[2])]);
const REWRITE_RULES = rulesIn(R.slice(R.indexOf('RULES')));
const aliasTxt = T.slice(T.indexOf('val ALIASES'), T.indexOf('val TOGGLE_RULES'));
const ALIASES = rulesIn(aliasTxt);
const TOGGLES = rulesIn(T.slice(T.indexOf('val TOGGLE_RULES'), T.indexOf('// ----', T.indexOf('val TOGGLE_RULES'))));
console.log(`extracted: ${Object.keys(N).length} named regexes, ${REWRITE_RULES.length} rewriter rules, ${ALIASES.length} aliases, ${TOGGLES.length} toggle rules`);

const UNITS = {zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19};
const TENS = {twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90};

const g = re => new RegExp(re.source, 'g');
const tidyR = s => s.toLowerCase().replace(/[\u2018\u2019']/g,'').trim();
function rewrite(input){ // Rewriter.rewrite
  let out = tidyR(input); if(!out) return out;
  for (const [re,to] of REWRITE_RULES){ out = out.replace(g(re), to).trim(); if(!out) return out; }
  return out.replace(/\s+/g,' ').trim();
}
const tidy = s => s.toLowerCase().replace(/[\u2018\u2019']/g,'').replace(/[?!,;]+/g,' ').replace(/\.+\s*$/,'').replace(/\s+/g,' ').trim();
const kindOf = w => w==='zero'?5: w==='hundred'?4: (w in TENS)?3: (w in UNITS)?(UNITS[w]>=10?2:1):0;
const allowed = (p,k) => k===1?(p===0||p===3||p===4): (k===2||k===3)?(p===0||p===4): k===4?(p===0||p===1): k===5?p===0:false;
function digitize(s){
  const toks = s.replace(g(N.HYPHEN_NUM), '$1 $2').split(' '); const out=[]; let i=0;
  while(i<toks.length){
    const w=toks[i]; const aH = w==='a' && toks[i+1]==='hundred';
    if(!aH && kindOf(w)===0){ out.push(w); i++; continue; }
    let cur=0, prev=0, j=i; if(aH){cur=100;prev=4;j=i+2;}
    while(j<toks.length){ const x=toks[j]; const k=kindOf(x); if(k===0||!allowed(prev,k)) break;
      if(k===4) cur = cur===0?100:cur*100; else if(k!==5) cur += (UNITS[x] ?? TENS[x] ?? 0); prev=k; j++; }
    out.push((j-i===1 && w==='one') ? w : String(cur)); i=j;
  }
  return out.join(' ');
}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const num = t => { const m = t.match(N.NUM_PCT) || t.match(N.NUM_PREP) || t.match(N.NUM_ANY); return m? parseInt(m[1],10):null; };
const qual = t => N.SMALL.test(t)?10 : N.LARGE.test(t)?30 : null;
const absolute=(tg,p)=>`set ${tg} to ${clamp(p,0,100)}%`;
const delta=(tg,d,a)=>{const v=d>0?'increase':'decrease'; return a==null?`${v} ${tg}`:`${v} ${tg} by ${clamp(a,1,100)}%`;};
function adjustLevel(t){
  if (N.QUESTION.test(t) || N.UNRELATED.test(t)) return null;
  const bright = N.BRIGHT.test(t)||N.BRIGHT_IMPLICIT.test(t), vol = N.VOLUME.test(t)||N.VOLUME_IMPLICIT.test(t);
  if (bright===vol) return null; const tg = bright?'brightness':'volume';
  const up = t.search(N.DIR_UP), down = t.search(N.DIR_DOWN);
  const dir = (up>=0&&down>=0)?(up<down?1:-1): up>=0?1: down>=0?-1:0;
  const n = num(t), toAbs = N.TO_ABS.test(t); const nm = t.match(N.NOTCH); const notches = nm?parseInt(nm[1],10):null;
  if (N.BY_HALF.test(t)&&dir!==0) return delta(tg,dir,50);
  if (notches!=null&&dir!==0) return delta(tg,dir,notches*(bright?10:7));
  if (N.MAXW.test(t)) return absolute(tg,100);
  if (N.MINW.test(t)) return absolute(tg,bright?5:0);
  if (N.HALF.test(t)) return absolute(tg,50);
  if (n!=null&&(toAbs||dir===0)) return absolute(tg,n);
  if (n!=null) return delta(tg,dir,n);
  if (dir!==0) return delta(tg,dir,qual(t));
  return null;
}
function translate(raw){
  let t = tidy(raw); if(!t) return t;
  t = digitize(t);
  t = t.replace(g(N.PERCENT),'$1%').replace(g(N.SPACED_PCT),'$1%');
  t = rewrite(t); if(!t) return t;
  for (const [re,to] of ALIASES) t = t.replace(re,to);
  const lv = adjustLevel(t); if (lv) return lv;
  for (const [re,to] of TOGGLES){ const r = new RegExp(re.source); if (r.test(t)) return t.replace(r,to).trim(); }
  return t;
}

// ---- router's whole() patterns, in file order (for hijack + canonical checks)
const WHOLE = [...RT.matchAll(/whole\(t,\s*"((?:[^"\\]|\\.)*)"\)/g)].map(m => unesc(m[1]));
const normalize = s => s.toLowerCase().replace(/[\u2018\u2019']/g,'').replace(/(\d),(\d)/g,'$1$2').replace(/[?!,;]+/g,' ').replace(/\s+/g,' ').trim();
const wholeMatch = (t,p) => { const m = new RegExp('^(?:'+p+')$').exec(t); return m; };
const firstWhole = t => WHOLE.find(p => wholeMatch(t,p));

// what the Router would do with canonical text (only the level/toggle families)
function parse(t){
  let m;
  if ((m = wholeMatch(t,'(?:set )?brightness (?:to )?(\\d{1,3})\\s*%?'))) return {a:'brightness', pct:clamp(+m[1],1,100)};
  if ((m = wholeMatch(t,'(?:increase|raise|turn up|boost) (?:my |the )?(?:screen )?brightness(?: by (\\d{1,3})\\s*%?)?'))) return {a:'brightness-delta', n:clamp(m[1]?+m[1]:20,1,100)};
  if ((m = wholeMatch(t,'(?:decrease|lower|turn down|reduce) (?:my |the )?(?:screen )?brightness(?: by (\\d{1,3})\\s*%?)?'))) return {a:'brightness-delta', n:-clamp(m[1]?+m[1]:20,1,100)};
  if ((m = wholeMatch(t,'(?:set )?(?:the )?volume (?:to )?(\\d{1,3})\\s*%?'))) return {a:'volume', pct:clamp(+m[1],0,100)};
  if ((m = wholeMatch(t,'(?:increase|raise|turn up|boost) (?:my |the )?volume(?: by (\\d{1,3})\\s*%?)?'))) return {a:'volume-delta', n:clamp(m[1]?+m[1]:15,1,100)};
  if ((m = wholeMatch(t,'(?:decrease|lower|turn down|reduce) (?:my |the )?volume(?: by (\\d{1,3})\\s*%?)?'))) return {a:'volume-delta', n:-clamp(m[1]?+m[1]:15,1,100)};
  if ((m = wholeMatch(t,'(?:turn|switch) (on|off) (?:the )?(?:camera )?(?:flash|flashlight|torch)'))) return {a:'flashlight', on:m[1]==='on'};
  if ((m = wholeMatch(t,'(?:turn|switch) (on|off) (?:the )?wi-?fi'))) return {a:'wifi', on:m[1]==='on'};
  if ((m = wholeMatch(t,'(?:turn|switch) (on|off) (?:the )?bluetooth'))) return {a:'bluetooth', on:m[1]==='on'};
  if ((m = wholeMatch(t,'(?:turn|switch) (on|off) do not disturb'))) return {a:'dnd', on:m[1]==='on'};
  if ((m = wholeMatch(t,'(?:enable|disable|turn on|turn off) (?:the )?airplane mode'))) return {a:'airplane'};
  if ((m = wholeMatch(t,'(?:enable|disable|turn on|turn off) (?:the )?dark mode'))) return {a:'dark-mode'};
  if ((m = wholeMatch(t,'(?:turn|switch) (on|off) (?:the )?mobile data'))) return {a:'mobile-data'};
  if ((m = wholeMatch(t,'(?:mute|silence)(?: (?:the )?(?:audio|sound|volume|phone))?'))) return {a:'volume', pct:0};
  if ((m = wholeMatch(t,'(max|maximum) brightness'))) return {a:'brightness', pct:100};
  if ((m = wholeMatch(t,'(min|minimum|lowest) brightness'))) return {a:'brightness', pct:5};
  return null;
}
// route: direct first (approximated by "does any whole() pattern claim the raw text?"), then translator
function route(raw){
  const d = parse(normalize(raw)); if (d) return {...d, via:'direct'};
  const hijack = firstWhole(normalize(raw));
  if (hijack) return {a:'HIJACKED-BY-OTHER-PATTERN', pattern:hijack};
  const alt = translate(raw); const p = parse(alt);
  return p ? {...p, via:'translated', canon:alt} : {a:'unknown', canon:alt};
}
module.exports = {translate, digitize, route, parse, normalize, firstWhole, WHOLE};

if (require.main === module) {
  let pass=0, fail=0;
  const eq = (raw, expect) => {
    const r = route(raw); const ok = Object.entries(expect).every(([k,v]) => r[k]===v);
    if (ok) pass++; else { fail++; console.log('FAIL', JSON.stringify(raw), '->', JSON.stringify(r), 'expected', JSON.stringify(expect)); }
  };
  // ---- the one the user reported
  eq('Increase the brightness by 50%', {a:'brightness-delta', n:50});
  eq('set brightness to 30%', {a:'brightness', pct:30});
  // ---- brightness
  eq('increase brightness by 50 percent', {a:'brightness-delta', n:50});
  eq('increase the brightness by fifty percent', {a:'brightness-delta', n:50});
  eq('raise my screen brightness by 25%', {a:'brightness-delta', n:25});
  eq('lower the brightness by 30', {a:'brightness-delta', n:-30});
  eq('reduce the screen brightness by twenty five percent', {a:'brightness-delta', n:-25});
  eq('make the screen 20% brighter', {a:'brightness-delta', n:20});
  eq('make it 30 percent dimmer', {a:'brightness-delta', n:-30});
  eq('make the screen a bit dimmer', {a:'brightness-delta', n:-10});
  eq('can you please make the screen a lot brighter', {a:'brightness-delta', n:30});
  eq('brighten the screen by 40%', {a:'brightness-delta', n:40});
  eq('dim the screen by thirty percent', {a:'brightness-delta', n:-30});
  eq('dim the screen', {a:'brightness-delta', n:-20});
  eq('make it brighter', {a:'brightness-delta', n:20});
  eq('brightness up', {a:'brightness-delta', n:20});
  eq('turn the brightness down', {a:'brightness-delta', n:-20});
  eq('turn the brightness up a little', {a:'brightness-delta', n:10});
  eq('turn the brightness up to 80', {a:'brightness', pct:80});
  eq('increase brightness to 70%', {a:'brightness', pct:70});
  eq('set the brightness to fifty percent', {a:'brightness', pct:50});
  eq('put the brightness at seventy five', {a:'brightness', pct:75});
  eq('make the brightness 40%', {a:'brightness', pct:40});
  eq('set screen brightness to half', {a:'brightness', pct:50});
  eq('brightness to maximum', {a:'brightness', pct:100});
  eq('full brightness', {a:'brightness', pct:100});
  eq('lowest brightness', {a:'brightness', pct:5});
  eq('bring the screen up to 90 percent', {a:'brightness', pct:90});
  eq('increase brightness by half', {a:'brightness-delta', n:50});
  eq('brightness 100', {a:'brightness', pct:100});
  eq('hey yantra, could you set the brightness to twenty', {a:'brightness', pct:20});
  // ---- volume
  eq('increase the volume by 20%', {a:'volume-delta', n:20});
  eq('turn up the volume by ten', {a:'volume-delta', n:10});
  eq('lower the volume by 30 percent', {a:'volume-delta', n:-30});
  eq('make it louder', {a:'volume-delta', n:15});
  eq('make it quieter', {a:'volume-delta', n:-15});
  eq('a bit louder', {a:'volume-delta', n:10});
  eq('much quieter', {a:'volume-delta', n:-30});
  eq('turn the volume up', {a:'volume-delta', n:15});
  eq('turn the volume down', {a:'volume-delta', n:-15});
  eq('turn the volume up to forty', {a:'volume', pct:40});
  eq('set the volume to 30 percent', {a:'volume', pct:30});
  eq('volume to max', {a:'volume', pct:100});
  eq('volume at half', {a:'volume', pct:50});
  eq('bring the volume down by half', {a:'volume-delta', n:-50});
  eq('turn the sound down by 2 notches', {a:'volume-delta', n:-14});
  eq('drop the volume to 20', {a:'volume', pct:20});
  eq('make the volume 60%', {a:'volume', pct:60});
  eq('make the music 20% louder', {a:'volume-delta', n:20});
  eq('mute', {a:'volume', pct:0});
  // ---- toggles
  eq('turn the flashlight on', {a:'flashlight', on:true});
  eq('turn off the torch', {a:'flashlight', on:false});
  eq('flashlight on', {a:'flashlight', on:true});
  eq('wifi off', {a:'wifi', on:false});
  eq('enable bluetooth', {a:'bluetooth', on:true});
  eq('disable the wi-fi', {a:'wifi', on:false});
  eq('turn dnd on', {a:'dnd', on:true});
  eq('switch bt off', {a:'bluetooth', on:false});
  eq('please turn the bluetooth on', {a:'bluetooth', on:true});
  eq('hey yantra can you turn the flashlight on please', {a:'flashlight', on:true});
  // ---- must NOT be claimed by the level logic
  eq('how do i make the screen brighter', {a:'unknown'});
  eq('what is the volume of a sphere', {a:'unknown'});
  eq('remind me to turn the volume down', {a:'unknown'});
  eq('make me a sandwich', {a:'unknown'});
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}
