#!/usr/bin/env node
/*
 * Verifies the Translator and the Router's pattern ordering without a JDK.
 *
 * Every regex is extracted straight from the Kotlin source, so a typo in a
 * pattern fails here. Control flow (digitize, typo fixing, follow-ups, the
 * reminder time parser, compound splitting) is ported by hand and mirrors the
 * Kotlin line for line. Router patterns are replayed in file order, which is
 * what catches one pattern swallowing a phrase meant for another.
 *
 *   node tools/verify-translator.js
 */
const fs = require('fs');
const path = require('path');
const DIR = path.join(__dirname, '..', 'app/src/main/java/in/yantra/assistant/router') + '/';
const read = f => fs.readFileSync(DIR + f, 'utf8');
const unesc = s => s.replace(/\\\\/g, '\u0000').replace(/\\"/g, '"').replace(/\\u2018/g, '\u2018').replace(/\\u2019/g, '\u2019').replace(/\u0000/g, '\\');
const T = read('Translator.kt'), R = read('Rewriter.kt'), RT = read('Router.kt');

// ------------------------------------------------------------ extraction
const N = {};
for (const m of T.matchAll(/private val (\w+) = Regex\("((?:[^"\\]|\\.)*)"\)/g)) N[m[1]] = new RegExp(unesc(m[2]));
const rulesIn = txt => [...txt.matchAll(/Rule\(\s*Regex\("((?:[^"\\]|\\.)*)"\),\s*"((?:[^"\\]|\\.)*)"\s*\)/g)].map(m => [new RegExp(unesc(m[1])), unesc(m[2])]);
const between = (txt, a, b) => txt.slice(txt.indexOf(a), txt.indexOf(b, txt.indexOf(a) + 1));
const REWRITE = rulesIn(R.slice(R.indexOf('RULES')));
const ALIASES = rulesIn(between(T, 'val ALIASES', 'val VOICE_RULES'));
const VOICES = rulesIn(between(T, 'val VOICE_RULES', 'val PHRASE_RULES'));
const PHRASES = rulesIn(between(T, 'val PHRASE_RULES', 'val TOGGLE_RULES'));
const TOGGLES = rulesIn(between(T, 'val TOGGLE_RULES', '// ------------------------------------------------------------- public'));
const PROTECTED = new Set([...between(T, 'val PROTECTED', 'private val ALIASES').matchAll(/"([a-z]+)"/g)].map(m => m[1]));
const VOCAB = [...new Set([...between(T, 'val VOCAB = listOf(', 'val VOCAB_SET').matchAll(/"([a-z]+)"/g)].map(m => m[1]))];

const routerBody = RT.slice(RT.indexOf('private fun routeDirect'), RT.indexOf('private val JOKES'));
const PATTERNS = [...routerBody.matchAll(/\b(whole|has)\(t,\s*"((?:[^"\\]|\\.)*)"\)/g)].map(m => ({
  kind: m[1], src: unesc(m[2]),
  re: m[1] === 'whole' ? new RegExp('^(?:' + unesc(m[2]) + ')$') : new RegExp(unesc(m[2]))
}));
const rn = n => new RegExp(unesc(RT.match(new RegExp('private val ' + n + ' = Regex\\("((?:[^"\\\\]|\\\\.)*)"\\)'))[1]));
const AGAIN = rn('AGAIN'), WH = rn('WH'), SPLIT = new RegExp(rn('SPLIT').source, 'g'), VERB_PREFIX = rn('VERB_PREFIX');
const REL_WHEN = rn('REL_WHEN'), DAY_WORD = rn('DAY_WORD'), PART_WORD = rn('PART_WORD'), EXPLICIT_AMPM = rn('EXPLICIT_AMPM');
const TIME_BITS = [...between(RT, 'private val TIME_BITS', 'internal fun whenFrom').matchAll(/Regex\("((?:[^"\\]|\\.)*)"\)/g)].map(m => new RegExp(unesc(m[1]), 'g'));

// --------------------------------------------------- translator (ported)
const UNITS = {zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19};
const TENS = {twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90};
const G = re => new RegExp(re.source, 'g');
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const tidyR = s => s.toLowerCase().replace(/[\u2018\u2019']/g, '').trim();
function rewrite(input) {
  let out = tidyR(input); if (!out) return out;
  for (const [re, to] of REWRITE) { out = out.replace(G(re), to).trim(); if (!out) return out; }
  return out.replace(/\s+/g, ' ').trim();
}
const tidy = s => s.toLowerCase().replace(/[\u2018\u2019']/g, '').replace(/[?!,;]+/g, ' ').replace(/\.+\s*$/, '').replace(/\s+/g, ' ').trim();
const kindOf = w => w === 'zero' ? 5 : w === 'hundred' ? 4 : (w in TENS) ? 3 : (w in UNITS) ? (UNITS[w] >= 10 ? 2 : 1) : 0;
const allowed = (p, k) => k === 1 ? (p === 0 || p === 3 || p === 4) : (k === 2 || k === 3) ? (p === 0 || p === 4) : k === 4 ? (p === 0 || p === 1) : k === 5 ? p === 0 : false;
function digitize(s) {
  const toks = s.replace(G(N.HYPHEN_NUM), '$1 $2').split(' '); const out = []; let i = 0;
  while (i < toks.length) {
    const w = toks[i]; const aH = w === 'a' && toks[i + 1] === 'hundred';
    if (!aH && kindOf(w) === 0) { out.push(w); i++; continue; }
    let cur = 0, prev = 0, j = i; if (aH) { cur = 100; prev = 4; j = i + 2; }
    while (j < toks.length) { const x = toks[j]; const k = kindOf(x); if (k === 0 || !allowed(prev, k)) break;
      if (k === 4) cur = cur === 0 ? 100 : cur * 100; else if (k !== 5) cur += (UNITS[x] ?? TENS[x] ?? 0); prev = k; j++; }
    out.push((j - i === 1 && w === 'one') ? w : String(cur)); i = j;
  }
  return out.join(' ');
}
function distance(a, b) {
  const d = Array.from({length: a.length + 1}, () => new Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) d[i][0] = i; for (let j = 0; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) {
    const c = a[i-1] === b[j-1] ? 0 : 1; let v = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + c);
    if (i > 1 && j > 1 && a[i-1] === b[j-2] && a[i-2] === b[j-1]) v = Math.min(v, d[i-2][j-2] + 1);
    d[i][j] = v;
  } return d[a.length][b.length];
}
function fixTypos(t) {
  return t.split(' ').map(w => {
    if (w.length < 5 || !/^[a-z]+$/.test(w) || VOCAB.includes(w) || PROTECTED.has(w)) return w;
    const limit = w.length >= 8 ? 2 : 1; let best = null, bestD = Infinity, tie = false;
    for (const v of VOCAB) { if (v[0] !== w[0] || Math.abs(v.length - w.length) > limit) continue;
      const dd = distance(w, v); if (dd < bestD) { bestD = dd; best = v; tie = false; } else if (dd === bestD) tie = true; }
    return (best && bestD <= limit && !tie) ? best : w;
  }).join(' ');
}
function timeWords(s) {
  let t = s.replace(G(N.AMPM_DOTS), '$1 $2m').replace(G(N.HALF_PAST), '$1:30').replace(G(N.QUARTER_PAST), '$1:15')
    .replace(G(N.QUARTER_TO), (m, h) => `${+h <= 1 ? 12 : +h - 1}:45`).replace(G(N.NOON), '12 pm').replace(G(N.MIDNIGHT), '12 am')
    .replace(G(N.SPLIT_TIME), '$1:$2 $3').replace(G(N.THREE_QUARTERS), '75%').replace(G(N.QUARTER), '25%');
  return t;
}
const num = t => { const m = t.match(N.NUM_PCT) || t.match(N.NUM_PREP) || t.match(N.NUM_ANY); return m ? parseInt(m[1], 10) : null; };
const qual = t => N.SMALL.test(t) ? 10 : N.LARGE.test(t) ? 30 : null;
const absolute = (tg, p) => `set ${tg} to ${clamp(p, 0, 100)}%`;
const delta = (tg, d, a) => { const v = d > 0 ? 'increase' : 'decrease'; return a == null ? `${v} ${tg}` : `${v} ${tg} by ${clamp(a, 1, 100)}%`; };
function adjustLevel(t) {
  if (N.QUESTION.test(t) || N.UNRELATED.test(t)) return null;
  const bright = N.BRIGHT.test(t) || N.BRIGHT_IMPLICIT.test(t), vol = N.VOLUME.test(t) || N.VOLUME_IMPLICIT.test(t);
  if (bright === vol) return null; const tg = bright ? 'brightness' : 'volume';
  const up = t.search(N.DIR_UP), down = t.search(N.DIR_DOWN);
  const dir = (up >= 0 && down >= 0) ? (up < down ? 1 : -1) : up >= 0 ? 1 : down >= 0 ? -1 : 0;
  const n = num(t), toAbs = N.TO_ABS.test(t); const nm = t.match(N.NOTCH); const notches = nm ? parseInt(nm[1], 10) : null;
  if (N.BY_HALF.test(t) && dir !== 0) return delta(tg, dir, 50);
  if (notches != null && dir !== 0) return delta(tg, dir, notches * (bright ? 10 : 7));
  if (N.MAXW.test(t)) return absolute(tg, 100);
  if (N.MINW.test(t)) return absolute(tg, bright ? 5 : 0);
  if (N.HALF.test(t)) return absolute(tg, 50);
  if (n != null && (toAbs || dir === 0)) return absolute(tg, n);
  if (n != null) return delta(tg, dir, n);
  if (dir !== 0) return delta(tg, dir, qual(t));
  return null;
}
function indirect(t) {
  if (N.UNRELATED.test(t)) return null;
  const amount = N.SMALL.test(t) ? 10 : N.WAY_TOO.test(t) ? 30 : null;
  if (N.TOO_BRIGHT.test(t)) return delta('brightness', -1, amount);
  if (N.TOO_DARK.test(t)) return delta('brightness', 1, amount);
  if (N.TOO_LOUD.test(t)) return delta('volume', -1, amount);
  if (N.TOO_QUIET.test(t)) return delta('volume', 1, amount);
  return null;
}
function followUp(t, target) {
  let m = t.match(N.FOLLOW);
  if (m) { const w = m[1]; return delta(target, (w === 'more' || w === 'up' || w === 'higher') ? 1 : -1, qual(t)); }
  m = t.match(N.FOLLOW_NUM); if (m) return delta(target, (m[2] === 'more' || m[2] === 'higher') ? 1 : -1, parseInt(m[1], 10));
  m = t.match(N.SET_IT); if (m) return absolute(target, parseInt(m[1], 10));
  return null;
}
function translate(raw, lastTarget = null) {
  let t = tidy(raw); if (!t) return t;
  t = fixTypos(t); t = digitize(t);
  t = t.replace(G(N.PERCENT), '$1%').replace(G(N.SPACED_PCT), '$1%');
  t = timeWords(t);
  for (let i = 0; i < 2; i++) t = t.replace(G(N.DOT_COM), '$1.$2');
  if (lastTarget) { const f = followUp(t, lastTarget); if (f) return f; }
  t = rewrite(t); if (!t) return t;
  for (const [re, to] of ALIASES) t = t.replace(G(re), to);
  for (const [re, to] of VOICES) if (re.test(t)) return t.replace(re, to).trim();
  let r = indirect(t); if (r) return r;
  r = adjustLevel(t); if (r) return r;
  for (const [re, to] of PHRASES) if (re.test(t)) return t.replace(re, to).trim();
  for (const [re, to] of TOGGLES) if (re.test(t)) return t.replace(re, to).trim();
  return t;
}

// ------------------------------------------------------ router (ported)
const normalize = s => s.toLowerCase().replace(/[\u2018\u2019']/g, '').replace(/(\d),(\d)/g, '$1$2').replace(/[?!,;]+/g, ' ').replace(/\s+/g, ' ').trim();
function durationMs(s) {
  const words = {one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,fifteen:15,twenty:20,thirty:30,forty:40,'forty five':45,an:1,a:1};
  let text = s.replace(/\bhalf an? hour\b/g, '30 minutes');
  for (const [k, v] of Object.entries(words)) text = text.replace(new RegExp('\\b' + k + '\\b', 'g'), String(v));
  let total = 0; for (const m of text.matchAll(/(\d+(?:\.\d+)?)\s*(hours?|hrs?|hr|h|minutes?|mins?|min|m|seconds?|secs?|sec|s)\b/g)) {
    const n = parseFloat(m[1]), u = m[2]; total += u.startsWith('h') ? n * 3600000 : u.startsWith('m') ? n * 60000 : n * 1000; } return Math.floor(total);
}
function clockTime(s) {
  let m = s.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)/);
  if (m) { let h = +m[1]; const mi = +(m[2] || 0); if (m[3] === 'pm' && h < 12) h += 12; if (m[3] === 'am' && h === 12) h = 0; if (h <= 23 && mi <= 59) return [h, mi]; }
  m = s.match(/(\d{1,2}):(\d{2})/); if (m && +m[1] <= 23 && +m[2] <= 59) return [+m[1], +m[2]];
  m = s.match(/(\d{1,2})\s*o'?clock/); if (m && +m[1] <= 23) return [+m[1], 0];
  m = s.match(/\bat\s+(\d{1,2})\b/); if (m && +m[1] <= 23) return [+m[1], 0];
  m = s.match(/^\s*(\d{1,2})\s*$/); if (m && +m[1] <= 23) return [+m[1], 0];
  return null;
}
const tidyTask = s => s.replace(/\s+/g, ' ').trim().replace(/^to /, '').trim().replace(/\s+(?:at|by|on|in|for|this)$/, '');
function whenFrom(s, nowMs) {
  const text = ' ' + s.trim() + ' ';
  let m = text.match(REL_WHEN);
  if (m) { const ms = durationMs(m[1]); if (ms > 0) return [tidyTask(text.slice(0, m.index) + text.slice(m.index + m[0].length)), nowMs + ms]; }
  const dm = text.match(DAY_WORD), day = dm ? dm[1] : null, pm = text.match(PART_WORD), part = pm ? pm[1] : null, hm = clockTime(text);
  if (!day && !part && !hm) return [tidyTask(text), 0];
  let [h, mi] = hm || (day === 'tonight' ? [21, 0] : part === 'evening' ? [18, 0] : part === 'afternoon' ? [15, 0] : [9, 0]);
  const late = part === 'evening' || part === 'afternoon' || day === 'tonight';
  if (hm && !EXPLICIT_AMPM.test(text) && h < 12 && late) h += 12;
  const c = new Date(nowMs); c.setHours(h, mi, 0, 0);
  if (day === 'tomorrow') c.setDate(c.getDate() + 1); else if (day === 'day after tomorrow') c.setDate(c.getDate() + 2);
  else if (c.getTime() <= nowMs) c.setDate(c.getDate() + 1);
  let rest = text; const cut = (re) => { const x = rest.match(new RegExp(re.source)); if (x) rest = rest.slice(0, x.index) + rest.slice(x.index + x[0].length); };
  cut(DAY_WORD); cut(PART_WORD); for (const re of TIME_BITS) rest = rest.replace(re, ' ');
  return [tidyTask(rest), c.getTime()];
}
const KNOWN_UNITS = new Set('c celsius f fahrenheit k kelvin km kilometre kilometres kilometers m metre metres meter meters cm mm mile miles mi ft feet foot inch inches in kg kilo kilos g gram grams lb lbs pound pounds oz l litre litres liter liters ml gallon gallons pint pints cup cups tbsp tsp second seconds sec secs minute minutes min mins hour hours hr hrs day days week weeks b byte bytes kb mb gb tb kmh kph mph mps knots'.split(' '));
const LIST_NAMES_EXCLUDED = new Set(['notifications', 'messages', 'contacts', 'apps']);
const WHAT_ON_EXCLUDED = new Set(['calendar', 'schedule', 'agenda', 'screen', 'phone', 'clipboard']);
const NOW = new Date(2026, 10, 12, 14, 0, 0).getTime(); // Thu 12 Nov 2026, 2 pm

/** First router pattern that would claim this text, or null. Mirrors the conditional returns in routeDirect. */
function firstMatch(raw) {
  const t = normalize(raw); if (!t) return { src: 'empty' };
  for (const p of PATTERNS) {
    const m = p.re.exec(t); if (!m) continue;
    const s = p.src;
    if (s.startsWith('(?:set )?(?:an? )?alarm')) { const body = m[1]; const rel = durationMs(body);
      if (rel > 0 && (body.includes('from now') || body.includes('in '))) return { src: s, action: 'timer' };
      if (clockTime(body)) return { src: s, action: 'alarm' }; return { src: s, action: 'ask' }; }
    if (s.startsWith('wake me')) { if (clockTime(t)) return { src: s, action: 'alarm' }; continue; }
    if (s === 'remind me in (.+)') { if (durationMs(m[1]) > 0) return { src: s, action: 'timer' }; continue; }
    if (s === '(?:set )?(?:a )?timer (?:for )?(.+)') { if (durationMs(m[1]) > 0) return { src: s, action: 'timer' }; continue; }
    if (s.startsWith('remind me (?:to |about |that )?')) {
      const body = m[1]; const lead = body.match(/^((?:at|by|in|after|tomorrow|tonight|today|this (?:morning|afternoon|evening))\b.*?) to (.+)$/);
      const phrase = lead ? lead[2] + ' ' + lead[1] : body; const [text, at] = whenFrom(phrase, NOW);
      if (text) return at === 0 ? { src: s, action: 'ask' } : { src: s, action: 'remind', text, at: new Date(at) };
      continue; }
    if (s.startsWith('(?:set )?(?:the )?screen (?:timeout')) { if (durationMs(m[1] || m[2] || '') > 0) return { src: s, action: 'screen-timeout' }; continue; }
    if (s === '(?:show|read|list) (?:my |the )?(.+?)(?: list)?') { if (LIST_NAMES_EXCLUDED.has(m[1].trim())) continue; }
    if (s === '(?:whats|what is) (?:on|in) (?:my |the )?(.+?)(?: list)?') { if (WHAT_ON_EXCLUDED.has(m[1].trim())) continue; }
    if (s === '(?:convert )?([\\d.]+) (\\w+) (?:to|into|in) (\\w+)') { if (!(KNOWN_UNITS.has(m[2]) && KNOWN_UNITS.has(m[3]))) continue; }
    return { src: s, m };
  }
  return null;
}
function routeSingle(raw, lastTarget) {
  let d = firstMatch(raw); if (d && d.action !== 'ask') return d;
  const alt = translate(raw, lastTarget);
  if (alt && alt !== normalize(raw)) { const s = firstMatch(alt); if (s && s.action !== 'ask') return { ...s, via: 'translated', alt }; }
  return d;
}
function compound(raw, lastTarget) {
  const parts = raw.toLowerCase().split(SPLIT).map(x => x.trim()).filter(Boolean);
  if (parts.length < 2 || parts.length > 4) return null;
  const out = []; let verb = null;
  for (const p of parts) {
    let r = routeSingle(p, lastTarget);
    if (!r && verb) r = routeSingle(verb + ' ' + p, lastTarget);
    if (!r || r.action === 'ask') return null;
    out.push(r); const v = p.match(VERB_PREFIX); if (v) verb = v[1];
  }
  return out;
}
function routeAll(raw, lastTarget = null, lastUser = null) {
  if (AGAIN.test(normalize(raw)) && lastUser) return routeAll(lastUser, lastTarget, null);
  const s = routeSingle(raw, lastTarget);
  const greedy = s && (s.src.startsWith('open (?:the )?(.+?)') || s.action === 'alarm' || s.action === 'timer');
  if (greedy) { const c0 = compound(raw, lastTarget); if (c0) return c0; }
  if (s && s.action !== 'ask') return [s];
  const c = compound(raw, lastTarget); if (c) return c;
  if (!s) { const t = normalize(raw); if (WH.test(t) && t.split(' ').length >= 3) return [{ src: 'SEARCH' }]; return [null]; }
  return [s];
}
module.exports = { translate, digitize, fixTypos, routeAll, firstMatch, whenFrom, normalize, timeWords, PATTERNS };

// ----------------------------------------------------------------- tests
if (require.main === module) {
  let pass = 0, fail = 0;
  const show = r => r === null ? 'unknown' : r.src === 'SEARCH' ? 'SEARCH' : (r.action ? r.action + ':' : '') + r.src.slice(0, 60);
  const route = (raw, ctx = {}) => routeAll(raw, ctx.lastTarget || null, ctx.lastUser || null);
  // expectation: a substring of the winning pattern (or 'unknown' / 'SEARCH'); array = compound
  const hits = (raw, expect, ctx) => {
    const rs = route(raw, ctx); const want = Array.isArray(expect) ? expect : [expect];
    const ok = rs.length === want.length && rs.every((r, i) => want[i] === 'unknown' ? r === null : want[i] === 'SEARCH' ? (r && r.src === 'SEARCH') : (r && (r.src.includes(want[i]) || r.action === want[i])));
    if (ok) pass++; else { fail++; console.log('FAIL', JSON.stringify(raw), '->', JSON.stringify(rs.map(show)), 'expected', JSON.stringify(want)); }
  };
  const canon = (raw, expect, last) => { const got = translate(raw, last); if (got === expect) pass++; else { fail++; console.log('FAIL translate', JSON.stringify(raw), '->', JSON.stringify(got), 'expected', JSON.stringify(expect)); } };
  const remind = (raw, text, h, m, dayOffset = 0) => {
    const r = route(raw)[0]; const d = r && r.at; const ok = r && r.action === 'remind' && r.text === text && d && d.getHours() === h && d.getMinutes() === m &&
      Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(2026, 10, 12)) / 864e5) === dayOffset;
    if (ok) pass++; else { fail++; console.log('FAIL remind', JSON.stringify(raw), '->', r && r.action, r && r.text, r && r.at && r.at.toString()); }
  };

  console.log(`extracted: ${Object.keys(N).length} named regexes, ${REWRITE.length} rewriter, ${ALIASES.length} aliases, ${PHRASES.length} phrase rules, ${TOGGLES.length} toggles, ${PATTERNS.length} router patterns, ${VOCAB.length} typo words`);

  // ======== the original complaint and the whole level family (carried over)
  canon('increase the brightness by fifty percent', 'increase brightness by 50%');
  canon('make the screen a bit dimmer', 'decrease brightness by 10%');
  canon('turn the volume up to forty', 'set volume to 40%');
  canon('bring the volume down by half', 'decrease volume by 50%');
  canon('turn the sound down by 2 notches', 'decrease volume by 14%');
  canon('make the music a lot louder', 'increase volume by 30%');
  canon('set brightness to twenty-five percent', 'set brightness to 25%');
  canon('set the volume to a hundred', 'set volume to 100%');
  canon('hey yantra, can you turn the flashlight on please', 'turn on flashlight');
  hits('Increase the brightness by 50%', 'brightness(?: by');
  hits('make the screen 20% brighter', 'brightness');   // translated
  hits('how do i make the screen brighter', 'SEARCH');

  // ======== typos
  canon('brigtness to 40', 'set brightness to 40%');
  canon('increse the volum by 20', 'increase volume by 20%');
  canon('turn on blutooth', 'turn on bluetooth');
  canon('set a timmer for 5 minutes', 'set a timer for 5 minutes');
  canon('flashligt on', 'turn on flashlight');
  canon('decrase the volume by 10', 'decrease volume by 10%');
  canon('what is the wether', 'weather');
  canon('dwon', 'dwon');                                        // under five letters: never touched
  canon('what is 12 times 7', '12 * 7');                        // "times" is a word, not a typo of "timer"
  canon('open calender', 'open calendar');
  canon('text priyanka hello', 'text priyanka hello');         // names untouched
  canon('call mom', 'call mom');

  // ======== indirect asks
  canon("it's too loud", 'decrease volume');
  canon("it's a bit too loud", 'decrease volume by 10%');
  canon("way too bright in here", 'decrease brightness by 30%');
  canon("i can't see anything", 'increase brightness');
  canon("i can't hear it", 'increase volume');
  canon("it's so quiet", 'increase volume by 30%');
  canon("that hurts my eyes", 'decrease brightness');
  canon("the screen is too dark", 'increase brightness');

  // ======== follow-ups (need the last target)
  canon('a bit more', 'increase volume by 10%', 'volume');
  canon('a little less', 'decrease brightness by 10%', 'brightness');
  canon('more', 'increase brightness', 'brightness');
  canon('turn it up', 'increase volume', 'volume');
  canon('turn it down a lot', 'decrease brightness by 30%', 'brightness');
  canon('20 more', 'increase volume by 20%', 'volume');
  canon('set it to 40', 'set brightness to 40%', 'brightness');
  canon('even higher', 'increase volume', 'volume');
  canon('louder', 'increase volume', 'brightness');            // names its own target: ignores the context
  hits('a bit more', 'unknown');                                // no context: nothing to adjust
  hits('a bit more', 'volume', { lastTarget: 'volume' });
  hits('again', 'brightness', { lastUser: 'increase brightness by 10%' });

  // ======== spoken times
  canon('set an alarm for half past six', 'set an alarm for 6:30');
  canon('alarm at quarter to seven', 'alarm at 6:45');
  canon('alarm at quarter past 9', 'alarm at 9:15');
  canon('wake me up at noon', 'wake me up at 12 pm');
  canon('alarm for ten thirty pm', 'alarm for 10:30 pm');
  canon('alarm at 6:30 a.m.', 'alarm at 6:30 am');
  hits('set an alarm for half past six', 'alarm');
  hits('set alarm for 7', 'alarm');
  canon('go to youtube dot com', 'go to youtube.com');
  canon('open google dot co dot in', 'open google.co.in');

  // ======== phrase rules and verbs
  canon('set a 10 minute timer', 'set a timer for 10 minutes');
  canon('start a timer for 5 minutes', 'set a timer for 5 minutes');
  canon('time me for 20 seconds', 'set a timer for 20 seconds');
  canon('how much charge do i have', 'battery');
  canon('is my phone charging', 'battery');
  canon('how much space is left', 'storage');
  canon("what's the weather like outside", 'weather');
  hits("what's the weather like outside", 'weather');
  canon('weather forecast for pune', 'weather in pune');
  canon('do i need an umbrella', 'will it rain');
  canon('how do i get to the airport', 'navigate to the airport');
  canon('find a pharmacy near me', 'find nearest pharmacy');
  canon('launch spotify', 'open spotify');
  canon('fire up the camera', 'open camera');
  canon('ring mom', 'call mom');
  canon('ping rahul', 'message rahul');
  canon('click a selfie', 'take a selfie');
  canon('turn the light on', 'turn on flashlight');
  canon('flight mode on', 'turn on airplane mode');
  canon('night mode off', 'turn off dark mode');
  canon('wifi off', 'turn off wifi');
  canon('disable bluetooth', 'turn off bluetooth');
  canon('hotspot on', 'turn on hotspot');
  canon('rotation off', 'turn off rotation');
  canon('5 plus 3', '5 + 3');
  canon('9 squared', '9 ^ 2');
  canon('2 to the power of 10', '2 ^ 10');
  canon('how many minutes in 3 hours', '3 hours to minutes');
  canon('silent', 'silent mode');
  canon('put my phone on vibrate', 'vibrate mode');

  // ======== voice
  canon('you sound robotic', 'change voice');
  canon('make you sound more human', 'change voice');      // must not become "increase volume"
  canon('make it sound more natural', 'change voice');
  canon('your voice sounds robot-like', 'change voice');
  canon("i don't like this voice", 'change voice');
  canon('this voice is too robotic', 'change voice');
  canon('make the music louder', 'increase volume');        // still a volume request
  canon('turn the sound up', 'increase volume');
  hits('you sound robotic', 'change|switch|try');
  hits('change your voice', 'change|switch|try');
  hits('try another voice', 'change|switch|try');
  hits('use a different voice', 'change|switch|try');
  hits('give me a less robotic voice', 'change|switch|try');
  hits('next voice', 'next voice');
  hits('list voices', 'what voices');                        // not a list called "voices"
  hits('what voices do you have', 'what voices');
  hits('install a voice', '(?:install|download');
  hits('get more voices', '(?:install|download');
  hits('speak deeper', 'deeper|lower|higher');
  hits('use a higher voice', 'deeper|lower|higher');
  hits('reset your voice', 'reset');
  hits('show my shopping list', '(?:show|read|list) (?:my |the )?(.+?)');   // lists unaffected
  hits('speak slowly', 'slowly');

  // ======== router ordering: new commands must win over older, looser patterns
  hits('silent mode', 'silent|vibrate');
  hits('turn on vibrate mode', 'silent|vibrate');
  hits('put my phone on silent', 'phone (?:on|to|in)');
  hits('turn off auto rotate', 'rotat');
  hits('lock rotation', 'lock|unlock');
  hits('turn on auto brightness', 'auto|adaptive');
  hits('set screen timeout to 2 minutes', 'screen-timeout');
  hits('keep the screen on for 5 minutes', 'screen-timeout');
  hits('open wifi settings', 'settings');
  hits('open display settings', 'settings');
  hits('turn on location', 'location|gps');
  hits('turn on the hotspot', 'location|gps');
  hits('pause the music', 'pause');
  hits('pause the timer', 'timer');                  // timer wins over media
  hits('resume the timer', 'timer');
  hits('next song', 'next');
  hits('skip', 'next');
  hits('previous track', 'previous');
  hits('stop the music', 'stop');
  hits('resume', 'play');
  hits('play despacito', 'play (.+)');
  hits('play lofi on spotify', 'on (youtube|spotify)');
  hits('play some music', 'play|resume');
  hits('go to bbc.com', 'https?');
  hits('open nytimes.com', 'https?');
  hits('open youtube', 'open (?:the )?(.+?)');
  hits('uninstall twitter', 'uninstall');
  hits('app info for chrome', 'app info');
  hits('clear my notifications', 'notifications');
  hits('read my notifications', 'notifications');
  hits('read my clipboard', 'clipboard');
  hits('record a video', 'video');
  hits('take a photo', 'camera|take a');
  hits('email priya@example.com saying running late', 'email|mail');
  hits('send an email', 'email');
  hits('cancel my alarms', 'alarm');
  hits('cancel the timer', 'timer');
  hits('what day is it tomorrow', 'tomorrow|yesterday');
  hits('what day will it be in 10 days', 'what day|what date');
  hits('what time will it be in 3 hours', 'what time');
  hits('what time is it in london', 'what time is it in');
  hits('what time is it', 'what time is it');
  hits('tip on 840 at 15%', 'tip');
  hits('15% tip on 840', 'tip');
  hits('split 1200 between 4', 'split');
  hits('20% off 1500', 'off|discount');
  hits('what percent is 30 of 120', 'what percent');
  hits('cube root of 27', 'cube root');
  hits('2 ^ 10', '[+\\-*/x^]');
  hits('5 plus 3', '[+\\-*/x^]');
  hits('3 hours to minutes', '(?:convert )?');
  hits('flip a coin', 'coin');
  hits('roll a dice', 'dice');
  hits('roll 3 dice', 'dice');
  hits('roll a d20', 'd(');
  hits('pick a number between 1 and 50', 'number');
  hits('pick pizza or pasta', ' or ');
  hits('tell me a joke', 'joke');
  hits('how are you', 'how are you');
  hits('translate good morning to hindi', 'translate');
  hits('define serendipity', 'define');
  hits('what does ubiquitous mean', 'what does');
  hits('whats on my shopping list', 'whats|what is');
  hits('whats on my calendar', 'calendar');                      // agenda, not a list
  hits('add milk to shopping', 'add (.+?) to');
  hits('copy hello world', 'unknown');                          // copy is matched on raw text, not a whole() pattern
  hits('which wifi am i on', 'wi-?fi');
  hits('is it going to rain today', 'will it rain');             // reaches the weather pattern through the translator
  canon('is it going to rain today', 'will it rain');
  hits('who is the prime minister of india', 'SEARCH');
  hits('make me a sandwich', 'unknown');

  // ======== reminders (now = Thu 12 Nov 2026, 2 pm)
  remind('remind me to call mom at 5 pm', 'call mom', 17, 0);
  remind('remind me at 5 pm to call mom', 'call mom', 17, 0);
  remind('remind me to take medicine tomorrow at 8 am', 'take medicine', 8, 0, 1);
  remind('remind me to water the plants tomorrow morning', 'water the plants', 9, 0, 1);
  remind('remind me to call the bank tonight', 'call the bank', 21, 0);
  remind('remind me to pack at 7 tomorrow evening', 'pack', 19, 0, 1);
  remind('remind me to stretch in 10 minutes', 'stretch', 14, 10);
  remind('remind me in an hour to stretch', 'stretch', 15, 0);
  remind('remind me about the invoice at 3 pm', 'about the invoice'.replace('about ', ''), 15, 0);
  remind('remind me to call mom at 1 pm', 'call mom', 13, 0, 1);       // 1 pm already passed today
  hits('remind me in 10 minutes', 'timer');                             // no task: still a timer
  hits('remind me to call mom', 'ask');                                  // no time
  hits('cancel my reminders', 'alarms?');

  // ======== compound commands
  hits('turn on wifi and bluetooth', ['wi-?fi', 'bluetooth']);
  hits('turn off wifi and turn on bluetooth', ['wi-?fi', 'bluetooth']);
  hits('set brightness to 50% and volume to 30%', ['brightness', 'volume']);
  hits('turn the volume down and the brightness up', ['volume', 'brightness']);
  hits('open youtube and whatsapp', ['open (?:the )?(.+?)', 'open (?:the )?(.+?)']);
  hits('turn on the flashlight then open the camera', ['flash', 'camera']);
  hits('set an alarm for 6 am and a timer for 5 minutes', ['alarm', 'timer']);
  hits('add milk and eggs to shopping', 'add (.+?) to');              // stays one command
  hits('turn on wifi and fly to the moon', 'unknown');                // a part is not understood: nothing runs

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
}
