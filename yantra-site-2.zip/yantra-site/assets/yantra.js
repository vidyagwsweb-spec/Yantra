/* Yantra orb: a straight port of the app's BlobView (same maths, same palette). */
(function(){
var d=document,root=d.documentElement;
try{var t=localStorage.getItem("yantra-theme")||(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light");root.dataset.theme=t}catch(e){root.dataset.theme="light"}
var tb=d.getElementById("theme");if(tb)tb.addEventListener("click",function(){var n=root.dataset.theme==="dark"?"light":"dark";root.dataset.theme=n;try{localStorage.setItem("yantra-theme",n)}catch(e){}});
var cv=d.getElementById("orb");if(!cv)return;var x=cv.getContext("2d");
var CLOUDS=[[232,98,42],[246,185,85],[143,176,196],[92,42,34]],GROUND=[[255,241,214],[242,176,74]],GLOW=[232,98,42];
var reduce=matchMedia("(prefers-reduced-motion:reduce)").matches;
var listening=false,orbit=0,breath=0,level=0,last=0,on=true,PI=Math.PI;
function rgba(c,a){return"rgba("+c[0]+","+c[1]+","+c[2]+","+Math.max(0,Math.min(255,a))/255+")"}
function lerp(a,b,t){return a+(b-a)*t}
function size(){var r=cv.getBoundingClientRect(),k=Math.min(devicePixelRatio||1,2),n=Math.round((cv.offsetWidth||r.width||460)*k);cv.width=n;cv.height=n}
function paint(){
 var w=cv.width,h=cv.height,cx=w/2,cy=h/2,half=Math.min(w,h)/2;x.clearRect(0,0,w,h);
 var inhale=reduce?1:.5-.5*Math.cos(breath);
 var r=half*.8*(lerp(.88,.95,level)+lerp(.12,.05,level)*inhale);
 var a=(70+70*inhale)*(.7+.3*level),g=x.createRadialGradient(cx,cy,0,cx,cy,half);
 g.addColorStop(0,rgba(GLOW,a));g.addColorStop(Math.min(.99,Math.max(.05,r/half)),rgba(GLOW,a));g.addColorStop(1,rgba(GLOW,0));
 x.fillStyle=g;x.beginPath();x.arc(cx,cy,half,0,2*PI);x.fill();
 x.save();x.beginPath();x.arc(cx,cy,r,0,2*PI);x.clip();
 g=x.createRadialGradient(cx,cy,0,cx,cy,r*1.05);g.addColorStop(0,rgba(GROUND[0],255));g.addColorStop(1,rgba(GROUND[1],255));
 x.fillStyle=g;x.fillRect(0,0,w,h);
 var oR=r*lerp(.34,.40,level),cloud=.96+.08*inhale;
 for(var i=0;i<4;i++){
  var p=orbit+i*(2*PI/4),bx=cx+Math.cos(p)*oR,by=cy+Math.sin(p*1.27)*oR*.92,br=r*(.62+.14*Math.sin(p*2.1+i))*cloud,c=CLOUDS[i];
  g=x.createRadialGradient(bx,by,0,bx,by,br);g.addColorStop(0,rgba(c,250));g.addColorStop(.42,rgba(c,185));g.addColorStop(1,rgba(c,0));
  x.fillStyle=g;x.beginPath();x.arc(bx,by,br,0,2*PI);x.fill();
 }
 g=x.createRadialGradient(cx-r*.34,cy-r*.36,0,cx-r*.34,cy-r*.36,r*.62);
 g.addColorStop(0,rgba([255,255,255],70+30*inhale));g.addColorStop(1,"rgba(255,255,255,0)");
 x.fillStyle=g;x.beginPath();x.arc(cx,cy,r,0,2*PI);x.fill();x.restore();
}
function frame(now){
 if(!on)return;var dt=last?Math.min(100,Math.max(1,now-last)):16;last=now;
 level+=((listening?1:0)-level)*(1-Math.exp(-dt/140));
 orbit+=dt*(2*PI/7000)*(1+.9*level);breath+=dt*(2*PI/(4800-2600*level));
 paint();requestAnimationFrame(frame);
}
size();paint();addEventListener("resize",function(){size();paint()});if(window.ResizeObserver)new ResizeObserver(function(){size();paint()}).observe(cv);addEventListener("load",function(){size();paint()});
if(reduce){level=0;return}
new IntersectionObserver(function(e){var v=e[0].isIntersecting;if(v&&!on){on=true;last=0;requestAnimationFrame(frame)}else on=v},{threshold:0}).observe(cv);
requestAnimationFrame(frame);
cv.addEventListener("click",function(){listening=!listening;var h=d.getElementById("hint");if(h)h.textContent=listening?"Listening… tap again to rest":"Tap the orb to wake it"});
})();

(function(){var b=document.getElementById("menubtn"),m=document.getElementById("menu");if(!b||!m)return;
function set(o){m.hidden=!o;b.setAttribute("aria-expanded",o?"true":"false")}
b.addEventListener("click",function(e){e.stopPropagation();set(m.hidden)});
document.addEventListener("click",function(e){if(!m.hidden&&!m.contains(e.target))set(false)});
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!m.hidden){set(false);b.focus()}});
m.addEventListener("click",function(e){if(e.target.closest("a"))set(false)});
})();
