/* Reads apk.json (written by the GitHub Action whenever the APK changes) and keeps the
   download links, file name, size and SHA-256 on every page in sync with the real file. */
(function(){
var d=document;
function all(s){return Array.prototype.slice.call(d.querySelectorAll(s))}
function fmt(n){return n>=1048576?(n/1048576).toFixed(1)+" MB":Math.max(1,Math.round(n/1024))+" KB"}
var info=fetch("apk.json?"+Date.now(),{cache:"no-store"}).then(function(r){if(!r.ok)throw 0;return r.json()});
info.then(function(j){
 window.YANTRA_APK=j;
 all("[data-apk]").forEach(function(a){a.setAttribute("href",j.file)});
 all("[data-apk-name]").forEach(function(e){e.textContent=j.file});
 all("[data-apk-size]").forEach(function(e){e.textContent=fmt(j.size)});
 all("[data-apk-version]").forEach(function(e){e.textContent=j.version});
 all("[data-sha]").forEach(function(e){e.textContent=j.sha256});
 all("[data-repo]").forEach(function(a){if(j.repo){a.href=j.repo;a.hidden=false}});
 all("[data-issues]").forEach(function(a){if(j.issues){a.href=j.issues;a.hidden=false}});
}).catch(function(){all("[data-sha]").forEach(function(e){e.textContent="Unavailable. Reload the page."})});

/* copy buttons */
function copy(text,btn,done){
 var ok=function(){var o=btn.textContent;btn.textContent=done||"Copied";setTimeout(function(){btn.textContent=o},1600)};
 if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(ok,function(){});
 else{var t=d.createElement("textarea");t.value=text;d.body.appendChild(t);t.select();try{d.execCommand("copy");ok()}catch(e){}t.remove()}
}
var cs=d.getElementById("copysha");
if(cs)cs.addEventListener("click",function(){var s=d.querySelector("[data-sha]").textContent;if(/^[0-9a-f]{64}$/.test(s))copy(s,cs)});

/* verify a file the visitor already downloaded, entirely in their browser */
var vf=d.getElementById("verify"),vr=d.getElementById("verify-result");
if(vf&&vr)vf.addEventListener("change",function(){
 var f=vf.files&&vf.files[0];if(!f)return;
 vr.className="vres";vr.textContent="Checking "+f.name+"…";
 if(!(window.crypto&&crypto.subtle)){vr.textContent="This browser can’t hash files. Use sha256sum on your computer instead.";return}
 Promise.all([f.arrayBuffer(),info]).then(function(r){return Promise.all([crypto.subtle.digest("SHA-256",r[0]),r[1]])}).then(function(r){
  var hex=Array.prototype.map.call(new Uint8Array(r[0]),function(b){return("0"+b.toString(16)).slice(-2)}).join("");
  if(hex===r[1].sha256){vr.className="vres good";vr.textContent="Match. This file is identical to the one on this page."}
  else{vr.className="vres bad";vr.textContent="No match. Don’t install this file. Download it again from this page."}
 }).catch(function(){vr.className="vres bad";vr.textContent="Couldn’t check that file. Try again."});
});

/* bug report builder */
var bf=d.getElementById("bugform");
if(bf){
 var ver=d.getElementById("b-ver");
 info.then(function(j){if(ver&&!ver.value)ver.value="Yantra "+j.version}).catch(function(){});
 function build(){
  var g=function(id){return(d.getElementById(id).value||"").trim()||"—"};
  return{title:g("b-sum"),body:"**Device and Android version**\n"+g("b-dev")+"\n\n**Yantra version**\n"+g("b-ver")+"\n\n**Steps to reproduce**\n"+g("b-steps")+"\n\n**Expected behaviour**\n"+g("b-exp")+"\n\n**Actual behaviour**\n"+g("b-act")+"\n"};
 }
 var st=d.getElementById("bugstatus");
 d.getElementById("copybug").addEventListener("click",function(e){
  var b=build();copy(b.title+"\n\n"+b.body,e.currentTarget,"Copied");if(st)st.textContent="Report copied. Paste it into the issue tracker."});
 var oi=d.getElementById("openissue");
 oi.addEventListener("click",function(e){
  var b=build(),base=oi.getAttribute("href");
  if(!base||base==="#"){e.preventDefault();return}
  oi.href=base.split("/new")[0].replace(/\/$/,"")+"/new?title="+encodeURIComponent(b.title)+"&body="+encodeURIComponent(b.body);
 });
}
})();
