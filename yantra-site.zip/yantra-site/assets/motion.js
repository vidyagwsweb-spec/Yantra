/* Motion and small live bits: scroll reveals, progress bar, command marquee, typing demo,
   card spotlight and back-to-top. Reduced-motion visitors get a calm, static version. */
(function(){
  var d=document, rm=matchMedia("(prefers-reduced-motion:reduce)").matches, hasIO="IntersectionObserver" in window;

  /* 1. scroll reveals + progress bar + nav shadow */
  var nav=d.querySelector(".nav");
  if(!rm&&hasIO){
    var sel=".sec-t,.try-copy .lead,.try-copy .btn,.tryit,.mrow,.steps li,.sha,.fine,.closing,.tile,.card,.band,.page-hero + *";
    var els=[].slice.call(d.querySelectorAll(sel)).filter(function(e){return !e.closest(".nav")});
    var io=new IntersectionObserver(function(list){
      list.forEach(function(en){if(en.isIntersecting){en.target.classList.add("in");io.unobserve(en.target)}});
    },{threshold:.12,rootMargin:"0px 0px -6% 0px"});
    els.forEach(function(e){
      var sib=e.parentNode?[].slice.call(e.parentNode.children).filter(function(s){return s.matches&&s.matches(sel)}):[];
      e.style.setProperty("--d",Math.min(Math.max(0,sib.indexOf(e)),5)*90+"ms");
      e.classList.add("rv"); io.observe(e);
    });
    /* marquee: duplicate each track once so the loop is seamless */
    [].forEach.call(d.querySelectorAll(".mtrack"),function(t){
      var c=t.cloneNode(true); c.setAttribute("aria-hidden","true"); t.parentNode.appendChild(c);
    });
  }
  var bar=d.querySelector(".progress");
  if(!bar&&!rm){bar=d.createElement("div");bar.className="progress";bar.setAttribute("aria-hidden","true");d.body.appendChild(bar)}

  /* 2. back to top */
  var top=d.createElement("button");top.className="totop";top.type="button";top.setAttribute("aria-label","Back to top");
  top.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  top.addEventListener("click",function(){scrollTo({top:0,behavior:rm?"auto":"smooth"})});
  d.body.appendChild(top);

  var tick=false;
  function upd(){
    tick=false;
    var h=d.documentElement.scrollHeight-innerHeight,y=scrollY;
    if(bar)bar.style.transform="scaleX("+(h>0?Math.min(1,y/h):0)+")";
    if(nav)nav.classList.toggle("scrolled",y>8);
    top.classList.toggle("on",y>innerHeight*.9);
  }
  addEventListener("scroll",function(){if(!tick){tick=true;requestAnimationFrame(upd)}},{passive:true});
  upd();

  /* 3. card spotlight follows the pointer */
  [].forEach.call(d.querySelectorAll(".steps li"),function(li){
    li.addEventListener("pointermove",function(e){
      var r=li.getBoundingClientRect();
      li.style.setProperty("--mx",(e.clientX-r.left)+"px");li.style.setProperty("--my",(e.clientY-r.top)+"px");
    });
  });

  /* 4. typing demo */
  var demo=d.querySelector(".tryit"); if(!demo)return;
  var tEl=d.getElementById("dtype"),oEl=d.getElementById("dout"),rEl=d.getElementById("dres"),dots=demo.querySelectorAll(".demo-dots i");
  var cmds=[["turn on the flashlight","Flashlight on"],["it’s a bit too loud","Volume turned down"],["set an alarm for quarter to seven","Alarm set for 6:45 AM"],["call mom","Calling Mom"]];
  function setDots(i){[].forEach.call(dots,function(x,k){x.classList.toggle("on",k===i)})}
  setDots(0);
  if(rm||!hasIO)return;              /* static first example stays on screen */

  var gen=0,running=false,idx=0;
  function wait(ms,g){return new Promise(function(res){setTimeout(function(){res(g===gen)},ms)})}
  async function loop(g){
    while(g===gen){
      var c=cmds[idx];setDots(idx);
      oEl.classList.add("off");tEl.textContent="";
      if(!await wait(450,g))return;
      for(var i=1;i<=c[0].length;i++){tEl.textContent=c[0].slice(0,i);if(!await wait(38+Math.random()*50,g))return}
      if(!await wait(420,g))return;
      rEl.textContent=c[1];oEl.classList.remove("off");
      if(!await wait(2600,g))return;
      oEl.classList.add("off");
      for(var j=c[0].length-1;j>=0;j--){tEl.textContent=c[0].slice(0,j);if(!await wait(14,g))return}
      idx=(idx+1)%cmds.length;
    }
  }
  function start(){if(!running){running=true;gen++;loop(gen)}}
  function stop(){running=false;gen++}
  new IntersectionObserver(function(l){l[0].isIntersecting&&!d.hidden?start():stop()},{threshold:.3}).observe(demo);
  d.addEventListener("visibilitychange",function(){if(d.hidden)stop()});
})();
