/* Pro layer behaviour: aurora, counters, pointer glow, parallax, magnetic buttons, live toggles */
(function(){
var d=document,rm=matchMedia("(prefers-reduced-motion:reduce)").matches,fine=matchMedia("(hover:hover)").matches;
var main=d.querySelector("main");
if(main){var a=d.createElement("div");a.className="aurora";a.setAttribute("aria-hidden","true");a.innerHTML="<i></i><i></i><i></i>";main.prepend(a)}
/* count-up stats */
var cs=[].slice.call(d.querySelectorAll("[data-count]"));
function run(el){
 var end=parseFloat(el.dataset.count),dec=(el.dataset.count.split(".")[1]||"").length,suf=el.dataset.suf||"",t0=0;
 if(rm){el.textContent=end.toFixed(dec)+suf;return}
 (function f(t){t0=t0||t;var p=Math.min(1,(t-t0)/1400),e=1-Math.pow(1-p,4);el.textContent=(end*e).toFixed(dec)+suf;if(p<1)requestAnimationFrame(f)})(performance.now());
}
if("IntersectionObserver" in window){var io=new IntersectionObserver(function(l){l.forEach(function(x){if(x.isIntersecting){run(x.target);io.unobserve(x.target)}})},{threshold:.6});cs.forEach(function(e){io.observe(e)})}else cs.forEach(run);
/* pointer glow on cards */
if(fine)[].forEach.call(d.querySelectorAll(".bt,.card,.sha"),function(c){
 c.addEventListener("pointermove",function(e){var r=c.getBoundingClientRect();c.style.setProperty("--mx",(e.clientX-r.left)+"px");c.style.setProperty("--my",(e.clientY-r.top)+"px")});
});
/* orb stage parallax */
var os=d.querySelector(".orbstage");
if(os&&fine&&!rm)os.addEventListener("pointermove",function(e){var r=os.getBoundingClientRect();os.style.setProperty("--px",((e.clientX-r.left)/r.width*2-1).toFixed(3));os.style.setProperty("--py",((e.clientY-r.top)/r.height*2-1).toFixed(3))});
if(os)os.addEventListener("pointerleave",function(){os.style.setProperty("--px",0);os.style.setProperty("--py",0)});
/* magnetic buttons */
if(fine&&!rm)[].forEach.call(d.querySelectorAll(".cta-row .btn,.closing .btn,.nav .btn"),function(b){
 b.addEventListener("pointermove",function(e){var r=b.getBoundingClientRect();b.style.transform="translate("+((e.clientX-r.left-r.width/2)*.18)+"px,"+((e.clientY-r.top-r.height/2)*.28-2)+"px)"});
 b.addEventListener("pointerleave",function(){b.style.transform=""});
});
/* live toggles */
[].forEach.call(d.querySelectorAll(".tg button"),function(b){b.addEventListener("click",function(){b.setAttribute("aria-pressed",b.getAttribute("aria-pressed")==="true"?"false":"true")})});
})();
/* pass 2 */
(function(){
var d=document,rm=matchMedia("(prefers-reduced-motion:reduce)").matches,fine=matchMedia("(hover:hover)").matches;
if(fine&&!rm){var cl=d.createElement("div");cl.className="cursor-light";cl.setAttribute("aria-hidden","true");d.body.appendChild(cl);
 addEventListener("pointermove",function(e){cl.style.opacity=1;cl.style.transform="translate("+e.clientX+"px,"+e.clientY+"px)"},{passive:true});
 d.addEventListener("pointerleave",function(){cl.style.opacity=0})}
var f=d.getElementById("pform"),out=d.getElementById("pout");if(!f)return;
var inp=f.querySelector("input");
function num(s){var m=s.match(/(\d+)\s*(%|percent)?/);return m?m[1]:null}
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1)}
function one(s){var t=s.toLowerCase().trim(),m;
 if(/flash|torch/.test(t))return/off/.test(t)?"Flashlight off":"Flashlight on";
 if(/bright/.test(t))return num(t)?"Brightness set to "+num(t)+"%":/(down|less|decrease|lower|dim)/.test(t)?"Brightness turned down":"Brightness turned up";
 if(/loud|quiet|volume|louder|softer/.test(t))return/(loud|down|decrease|lower|quiet|less)/.test(t)?"Volume turned down":"Volume turned up";
 if(m=t.match(/^call\s+(.+)/))return"Calling "+cap(m[1]);
 if(/^(text|message|sms)\b/.test(t))return"Text ready to send";
 if(/alarm|wake me/.test(t))return(t.match(/\d{1,2}(:\d{2})?\s*(am|pm)?/)||[])[0]?"Alarm set for "+t.match(/\d{1,2}(:\d{2})?\s*(am|pm)?/)[0].toUpperCase():"Alarm set";
 if(/calendar|event|dentist|meeting/.test(t))return/what/.test(t)?"Here’s what’s on today":"Added to your calendar";
 if(/wi-?fi|bluetooth|hotspot|data/.test(t))return"Opening the panel for you";
 if(/dnd|disturb|silent/.test(t))return"Do Not Disturb on";
 if(m=t.match(/^open\s+(.+)/))return"Opening "+cap(m[1]);
 if(/music|pause|play|skip/.test(t))return"Done";
 return"Passed to the on-device brain";}
function go(v){v=v.trim();if(!v)return;out.innerHTML="";
 v.split(/,?\s+(?:and\s+)?then\s+|,\s*|\s+and\s+(?=(?:turn|open|set|call|text|play|pause))/i).forEach(function(p,i){
  var el=d.createElement("div");el.textContent=one(p);el.style.animationDelay=(i*220)+"ms";out.appendChild(el)})}
f.addEventListener("submit",function(e){e.preventDefault();go(inp.value)});
[].forEach.call(d.querySelectorAll(".sug button"),function(b){b.addEventListener("click",function(){inp.value=b.textContent;go(b.textContent)})});
})();
/* platform note + release line */
(function(){
var d=document,ua=navigator.userAgent||"",ios=/iPhone|iPad|iPod/.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>1),android=/Android/.test(ua);
var msg=ios?"<b>Yantra is Android only.</b> It won’t run on iPhone or iPad.":(!android?"<b>On a computer?</b> Download the APK and move it to your Android phone, or open this page on the phone.":"");
[].forEach.call(d.querySelectorAll(".pnote"),function(n){if(msg){n.innerHTML=msg;n.classList.add("on")}});
fetch("apk.json?"+Date.now(),{cache:"no-store"}).then(function(r){return r.json()}).then(function(j){
 [].forEach.call(d.querySelectorAll("[data-apk-date]"),function(e){try{e.textContent=new Date(j.updated+"T00:00:00").toLocaleDateString(undefined,{year:"numeric",month:"short",day:"numeric"})}catch(x){}});
}).catch(function(){});
})();
/* play demo videos only while visible */
(function(){
var vs=[].slice.call(document.querySelectorAll("video[data-demo]"));if(!vs.length)return;
if(matchMedia("(prefers-reduced-motion:reduce)").matches||!("IntersectionObserver" in window)){vs.forEach(function(v){v.controls=true});return}
var io=new IntersectionObserver(function(l){l.forEach(function(e){var v=e.target;if(e.isIntersecting){var p=v.play();if(p&&p.catch)p.catch(function(){v.controls=true})}else v.pause()})},{threshold:.35});
vs.forEach(function(v){io.observe(v)});
})();
